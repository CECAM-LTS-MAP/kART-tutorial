#!/bin/csh

################################ Main Input/Output files ##########################################

setenv INI_FILE_NAME          'kARTdata'      # The file name containing the intial configuration 
setenv CONFFILE             'allconf.xyz'      # Name of the file to store all the configurations visited (default:     allconf)
###################################### Simulation Details #########################################

setenv NBRE_KMC_STEPS                 500     # The max number of KMC steps to be executed
setenv TOTAL_TIME                     3600.0   # The maximum simulation time in seconds 
setenv TEMPERATURE                    300.0    # The simulated temperature in kelvin

setenv NUMBER_ATOMS                   1996     # The total number of atoms 
setenv SIMULATION_BOX                28.5530   # The size of the simulation box (x, y and z)
setenv NSPECIES                         1      # The number of different atom types (default: 2)
setenv ATOMIC_SYMBOLS			"Fe"
###################################### Restart options ############################################

setenv RESTART_KMC                   .true.    # IF true, restart from previous run
setenv RESTART_FILE                "this_conf" # The file name used to continue a simulation from where it was last stopped
setenv RESTART_IMPORT                .false.    # Start a NEW simulation but with the current KMC event catalogue (events.uft and topos.list)
setenv NEW_CATALOGUE                 .false.   # IF true, will continue simulation but will rebuild event catalogue from scratch


#################################### Basin parameters ############################################

setenv MIN_SIG_BARRIER                 0.1     # Max height of barrier and inv. barrier for an event to be considered inside a basin

#################################### Topology Params #############################################

setenv TOPO_RADIUS                    6.0      # radius for topology cluster 
#setenv MAX_TOPO_CUTOFF               "2.7 2.9 3.2"      # length-cutoff used by default to link two atoms 
#setenv MIN_TOPO_CUTOFF               "2.0 2.0 2.0"
setenv MAX_TOPO_CUTOFF               2.7       # length-cutoff used by default to link two atoms 
setenv MIN_TOPO_CUTOFF               2.0 
setenv CRYST_TOPOID                   746699   # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS              4.0      # radius for crystal-like topologies (default: 4.0 A) 

#################################### Force calculations ##########################################

setenv ENERGY_CALC                    LAM      # choose between EDP or SWP or SWA or LAM (Lammps)
setenv INPUT_LAMMPS_FILE          'in.lammps'  # Name of the input file for lammps (default name : in.lammps )

################# ART PARAMETERS ##################################################################

setenv RADIUS_INITIAL_DEFORMATION     3.0      # Cutoff for local-move (in angstroems)
setenv EXIT_FORCE_THRESHOLD           0.01     # Threshold for convergence at saddle point
setenv FINE_EXIT_FORCE_THRESHOLD      0.01     # finner Threshold for convergence at saddle point 

setenv EIGENVALUE_THRESHOLD          -1.0      # Eigenvalue threshold for leaving basin
setenv MAX_PERP_MOVES_BASIN           2        # Maximum number of perpendicular steps leaving basin
setenv MIN_NUMBER_KSTEPS              2        # Min. number of ksteps before calling lanczos
setenv FORCE_THRESHOLD_PERP_REL       0.01      # Threshold for perpendicular relaxation


setenv INITIAL_STEP_SIZE          1.00    # Size of initial displacement, in A
setenv BASIN_FACTOR               3.00
setenv MIN_NUMBER_KSTEPS          3       # Min. number of ksteps before calling lanczos
setenv MAX_PERP_MOVES_BASIN       6       # Maximum number of perpendicular steps leaving basin
setenv MAX_PERP_MOVES_ACTIV       20       # Maximum number of perpendicular steps during activation
setenv MAX_ITER_BASIN             40      # Maximum number of iteraction for leaving the basin (kter)
setenv DTMAX_FIRE           0.25        # default value


setenv NUMBER_LANCZOS_VECTORS         15       # Number of vectors included in lanczos procedure
setenv LANCZOS_STEP                   1e-7     # Size of the step for the numerical derivative (def: 0.001)
#setenv CHECK_LANCZOS_STAB            .true.    # check lanczos stability over 200 steps, each iteration uses previous lanczos 

#################################### GENERIC events parameters ########################
setenv SEARCH_FREQUENCY      10           # Minimum number of attempts to find a GENERIC event per new topology encountered
setenv THRES_INCREASE_FREQ   25           # Number of failed attempts encountered because increasing the EIGEN_THRESH
setenv TYPE_EVENT_UPDATE     SPEC         # choose between SPEC or GENE 
setenv USE_LOG_SEARCH       .false.       # Search frequency is multiplied by logarithmic increasing function (default .true.)
setenv CHECK_INI_SAD_CONNECTIVITY .true.


############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC   	     .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful

 

############### Run the simulation ################################################################

unlimit stacksize
# mpirun -np 12 ~/bin/KMCART_correctmap_briareelammps
#~/bin/KMCART_correctmap_briareelammps
#~/bin/KMCART_briareelammps_v1449
/home/mijan/kart_final/src/KMCART_cedarlammps_v89499df
#../../src/KMCART_briareelammps_v1655

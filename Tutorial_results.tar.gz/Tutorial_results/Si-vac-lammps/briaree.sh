#!/bin/bash

#PBS -l walltime=01:00:00
#PBS -l nodes=1:ppn=4
#PBS -t 0-1%1

module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3

restart_array=(false true)

# Si-vac-lammps

dir=$HOME/kART/trunk
cd $dir/EXAMPLES/Si-vac-lammps

if [ $PBS_ARRAYID == 0 ]; then 
    rm EVLIST_DIR/event_list*
fi
mpiexec KMC.bash --restart=${restart_array[$PBS_ARRAYID]} --nsteps=2 --exe=$dir/src/KMCART_exec ;
cd -

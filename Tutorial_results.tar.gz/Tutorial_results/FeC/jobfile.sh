#!/bin/bash
#SBATCH --account=rrg-mousseau-ac
#SBATCH --ntasks=12               # number of MPI processes
#SBATCH --mem-per-cpu=2000M      # memory; default unit is megabytes
#SBATCH --time=00-01:00           # time (DD-HH:MM

srun ./KMC.sh 


#!/bin/sh

RESTART=.false.
NSTEPS=5
EXE=../../src/KMCART_exec
for i in "$@"
do
    case $i in
	-r=*|--restart=*)
	    RESTART=".${i#*=}."
	    ;;
	-ns=*|--nsteps=*)
	    NSTEPS="${i#*=}"
	    ;;
	-exe=*|--exe=*)
	    EXE="${i#*=}"
	    ;;
	-h|--help)
	    echo "options: -r   ; true or false to restart or not from previous run"
	    echo "         -ns  ; number of steps"
	    echo "         -exe ; name of kart program to execute"
	    echo "         -h   ; help"
	    exit
	    ;;
	*)
	    ;;
    esac
done


###################################### Main Input/Output files ##################################################

export INI_FILE_NAME='511.conf'        # The file name containing the intial configuration

###################################### Simulation Details #######################################################

export NBRE_KMC_STEPS=$NSTEPS          # The max number of KMC steps to be executed
export TEMPERATURE=500.0               # The simulated temperature in kelvin

export NUMBER_ATOMS=511                # The total number of atoms
export SIMULATION_BOX=21.72            # The size of the simulation box (x, y and z)
export NSPECIES=1                      # The number of different atom types (default: 2)
export ATOMIC_SYMBOLS="Si"
#export NTRAVAILLEUR=3                 # The number of cores associated with forces calculations per ARTnouveau search (default:1)

###################################### Restart options ##########################################################

export RESTART_KMC=$RESTART            # IF true, restart from previous run
export RESTART_FILE="this_conf"        # The file name used to continue a simulation from where it was last stopped
export RESTART_IMPORT=.false.          # Start a NEW simulation but with the current KMC event catalogue (events.uft and topos.list)
export NEW_CATALOGUE=.false.           # IF true, will continue simulation but will rebuild event catalogue from scratch


###################################### Basin parameters ##########################################################
export OSCILL_TREAT=BMRM               # choose between BMRM, TABU or NONE
export MIN_SIG_BARRIER=0.1             # Max height of barrier and inv. barrier for an event to be considered inside a basin

###################################### Topology Params ###########################################################

export TOPO_RADIUS=6.15                 # radius for topology cluster
export MAX_TOPO_CUTOFF=2.7             # length-cutoff used by default to link two atoms
export MIN_TOPO_CUTOFF=2.2             # minimal length cutoff used when looking at secondary topologies
export CRYST_TOPOID=973883             # topo id of the crystalline-like topologies
export CRYST_TOPO_RADIUS=4.0           # radius for crystal-like topologies (default: 4.0 A)


###################################### Force calculations ########################################################

export ENERGY_CALC=LAM                 # choose between EDP or SWP or SWA or LAM (Lammps)
export FORCE_CALC=TTL                  # choose TTL for total force calculation and PAR for partial force

export INPUT_LAMMPS_FILE='in.lammps'   # LAMMPS input file when using ENERGY_TYPE = LAM to calculate the forces

export UNITS_CONVERSION='metal'        # Converts the energy and distance units provided by the force code
# into a desired value for ART - affects only the parameters in ART and kART
# units available are real , electron and si
# be very careful when choosing other units, you must change parameters of energy
# and distance (if it's not in Angstrom) in input files for LAMMPS

export UPDATE_VER_NEIB=TTL             # choose TTL for total force calculation and PAR for partial force
export NEIB_CALC=ALL                   # choose ALL or VER
export UPDATE_TOPO=TTL                 # choose TTL or PAR
export PAR_DISP_THRESH2=0.00001        # max displacement squared which triggers an update of the neighbor
# list when using VER lists (default: 0.00001)


##################################### FIRE MINIMIZATION ##########################################################
export DTMAX_FIRE=0.15                 # default value
export DTMAX_FIRE_MIN=0.05             # default value=DTMAX_FIRE

###################################### ART PARAMETERS ############################################################
export SADDLE_PUSH_PARAM=0.1           # The fraction of the initial-saddle distance used to push saddle config. away from initial minimum (default: 0.1)
export TYPE_OF_EVENTS=local            # Initial move for events - global or local
export RADIUS_INITIAL_DEFORMATION=2.5  # Cutoff for local-move (in angstroems)
export EIGENVALUE_THRESHOLD=-1.0       # Eigenvalue threshold for leaving basin
export EXIT_FORCE_THRESHOLD=0.1        # Threshold for convergence at saddle point
export FORCE_THRESHOLD_PERP_REL=0.05   # Threshold for perpendicular relaxation
export FINE_EXIT_FORCE_THRESHOLD=0.05  # finner Threshold for convergence at saddle point
export FINE_FORCE_THRESHOLD_PERP_REL=0.01 # finner Threshold for perpendicular relaxation

export MAX_PERP_MOVES_BASIN=2          # Maximum number of perpendicular steps leaving basin
export MIN_NUMBER_KSTEPS=2             # Min. number of ksteps before calling lanczos
export INCREMENT_SIZE=0.1              # Overall scale for the increment moves in activation
export INITIAL_STEP_SIZE=0.01          # Size of initial displacement, in A
export MAX_PERP_MOVES_ACTIV=6          # Maximum number of perpendicular steps during activation
export MAX_ITER_BASIN=15               # Maximum number of iteraction for leaving the basin (kter)
export MAX_ITER_ACTIVATION=30          # Maximum number of iteraction during activation (iter)
export NUMBER_LANCZOS_VECTORS=15       # Number of vectors included in lanczos procedure
export LANCZOS_STEP=1e-2               #1e-2    # Size of the step for the numerical derivative (def: 0.001)
#export CHECK_LANCZOS_STAB=.true.      # Check lanczos stability over 200 steps, each iteration uses previous lanczos vector


###################################### GENERIC events parameters #################################################
export SEARCH_FREQUENCY=10             # Minimum number of attempts to find a GENERIC event per new topology encountered
export THRES_INCREASE_FREQ=25          # Number of failed attempts encountered because increasing the EIGEN_THRESH
export TYPE_EVENT_UPDATE=SPEC          # choose between SPEC or GENE
export USE_LOG_SEARCH=.true.           # Search frequency is multiplied by logarithmic increasing function (default .true.)
export CHECK_INI_SAD_CONNECTIVITY=.true. # When GENERIC saddle is found, pushes the system towards the initial minimum

###################################### Printing details ##########################################################

export ALLCONF_WITH_SADDLE=.true.
export PRINT_DETAILS=.true.            # Prints the details of activation and minimization
export MINSAD_DETAILS=.false.          # Prints the details of activation and minimization
export USE_TXT_EVENTFILE=.true.
export STATISTICS=.true.               # Write statistics about force and event calculation
export OUTPUT_CONFIG_EVENTS=.true.     # IF true, will create a txt file with the list of all the topologies and events after each KMC step
export OUTPUT_SPECIFIC=.true.
#export OUTPUT_NEB_GEN_EVENT=.true.    # Can be useful


###################################### Run the simulation ########################################################
ulimit -s unlimited

${EXE}

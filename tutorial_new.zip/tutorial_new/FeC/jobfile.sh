#!/bin/bash

#PBS -l nodes=1:ppn=4
#PBS -l walltime=00:10:00  
#PBS -N Mk_Fe1C_600K_test

module load lammps/14May16

#module load intel-compilers/12.0.4.191
#module load MPI/Intel/openmpi/1.6.5
#module load FFTW/3.3


cd $PBS_O_WORKDIR

mpiexec ./KMC.sh

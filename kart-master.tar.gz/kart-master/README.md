Click here to access the documentation: https://kart-doc.readthedocs.io/en/latest/

## Updated December 21 2023

There was an issue with refining too many events, many with a very low rate of occurence. This has been corrected, which should increase the speed of kART. Make sure to download the latest version of the code.

Modifications:  Normand Mousseau
                normand.mousseau@umontreal.ca


*******************************************************

## Updated March 22 2022

**IMPORTANT**

Wrappers interfacing with LAMMPS have now been updated. 

You must now use a lamps version of September 2020 or newer

See manual (version markdown) for details

Mdification by Eugène Sanscartier
               eugene.sanscartier@umontreal.ca

*******************************************************

## Updated May 14 2021 (initially April 30th 2021)

The way KART uses tags in mpi commuications was changed. The previous implementaion sometimes caused fatal MPI errors.

We recommend that you update your version of kART to the latest one.

Carl Lévesque
carl.levesque@umontreal.ca



January 27th, 2021

The most recent version of lammps has modified the fortran interface. This new interface is, for the moment, incompatible with kART.

We recommend that you use a version of lammps that predates September 2020. 

We are working to correct this issue.



October 8th, 2020

A series of bugs regarding boundary conditions were corrected by Mijanur Rahman. 

There are still problems with the triclining box, but all seems correct for orthorhombic boxes. 

Problems regarding boundary conditions led to crashes when events taking place near the box were strored or reconstructed. 

Because of that, we advise you to update your version as soon as possible to the latest code.

Normand Mousseau
normand.mousseau@umontreal.ca

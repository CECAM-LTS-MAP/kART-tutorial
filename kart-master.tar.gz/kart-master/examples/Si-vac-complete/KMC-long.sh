#!/bin/csh
# IMPORTANT: By convention variables must be defined in uppercase, if one is in lowercase you will have Errors at 
#            the moment executing the script.
# To execute and test this script, put your executable at the end of this file, and type in the simulation dir: 
#        mpirun -np 2 KMC.sh      (using ls -l be sure that KMS.sh has right permitions to execute: -rwxr-xr-x )
# if you are in a cluster, use the stardar procedure to summit jobs.
 
###################################### Random number generator ###################################################

#setenv RANDOM_SEED	     -1103            # Random seed used to generate random numbers (use only when debugging)

####################################### Simulation Details ##################################################

setenv NBRE_KMC_STEPS        		   5  # The max number of KMC steps to be executed
#setenv TOTAL_TIME          		 1.0  # The maximum simulation time in seconds 
#setenv ELAPSED_TIME          		 0.0  # The elapsed time before first KMC step (will be added to the sim. time) 
#setenv STEP_KMC_MEASURE     		   1  # Number of steps before each KMC  measurement (i.e. writing to the .dat files) 
setenv TEMPERATURE       	       500.0  # The simulated temperature in kelvin

###################################### System size and types ######################################

setenv NUMBER_ATOMS          		 511  # The total number of atoms 
setenv NSPECIES            		       1  # The number of different atom types (default: 2)
setenv ATOMIC_SYMBOLS               "Si"  # List of atom types separed by space, the order must be the same of the potential (max allowed 13 element)
#setenv ATOMIC_TYPE_FILE  'Atomic_types'  # Input file contaning list of atomic types (default: Atomic_types) and to ative/inactive
                                          # atom types. If you want only to define atom names, better use  ATOMIC_SYMBOLS. 
setenv SIMULATION_BOX       21.7200       # The size of the simulation box (x, y and z). If lammps this var is not needed.
#setenv X_BOX                 	          # the size of the simulation box in the x dimension. If lammps this var is not needed
#setenv Y_BOX                   	      # the size of the simulation box in the y dimension. If lammps this var is not needed
#setenv Z_BOX                   	      # the size of the simulation box in the z dimension. If lammps this var is not needed

###################################### Force field / Verlet neighbor list #######################

setenv ENERGY_CALC              SWP       # choose between EDP or SWP or SWA or AFE or LAM  (Lammps)
# If AFE potential is used one need to declare the LATTICE_CONSTANT variable.
# setenv LATTICE_CONSTANT     2.8665      # real variable iron lattice parameter


setenv FORCE_CALC           	 TTL      # choose TTL for total force calculation and PAR for partial force

setenv INPUT_LAMMPS_FILE     'in.lammps'  # LAMMPS input file when using ENERGY_TYPE = LAM to calculate the forces

UNITS_CONVERSION                real      # Converts the energy and distance units provided by the force code                                                                                                                                                             
                                     	  # into a desired value for ART - affects only the parameters in ART and kART
                                     	  # units available are real , electron and si
                                          # be very careful when choosing other units, you must change parameters of energy
                                          # and distance (if it's not in Angstrom) in input files for LAMMPS 

#setenv UPDATE_VER_NEIB          TTL      # choose TTL for total force calculation and PAR for partial force
#setenv NEIB_CALC           	 ALL      # choose ALL or VER
#setenv UPDATE_TOPO           	 TTL      # choose TTL or PAR
#setenv PAR_DISP_THRESH2     	 0.00001  # max displacement squared which triggers an update of the neighbor 
                                          # list when using VER lists (default: 0.00001)

###################################### Main Output options/files ########################################################

#setenv KLOGFILE           'log_KMC.txt'  # The file name containing a list of the parameters used
setenv STATISTICS                .true.   # Write statistics about force and event calculation  
# need to use the MPI version of the code for the varaible MPI_EFF_FILE 
#setenv MPI_EFF_FILE  'MPI_efficiency.dat' # If STATISTICS true, Name of the ARTnouveau efficiency file 

setenv OUTPUT_CONFIG_EVENTS     .false.   # Create file with list of all the topologies and events after each KMC step
#setenv EVLIST_DIR          'EVLIST_DIR'  # The name of the directory where the event list per KMC step files are stored (default: EVLIST_DIR)

#setenv SAVE_FULL_EVENTS          .false. # Save full events during catalog and after - one file per node (events.node_number)

setenv INI_FILE_NAME           '511.conf' # The file name containing the intial configuration 
#setenv DISPL_FILE        'Diffusion.dat' # The file name used to store the squared displacement (default: Diffusion)
#setenv CONFFILE                'allconf' # Name of the file to store all the configurations visited (default: allconf)
#setenv EV_FILE            'selec_ev.dat' # File name for statistics about the selected events
#setenv GENERIC_EV_STAT      'Gen_ev.dat' # File name for statistics about the GEN events
#setenv SPECIFIC_EV_STAT    'Spec_ev.dat' # File name for statistics about the SPEC events
#setenv ENERGY_STAT        'Energies.dat' # File name for statistics about the Energy 
#setenv LOWEST_BARRIER      'MinBarr.dat' # File name for statistics about the minimum barrier in the tree
#setenv BASIN_GRAPH      'basin_graph.gv' # File name for storing statistics about basins
#setenv TOPO_FILE         'topo_stat.dat' # File name for statistics about topologies

####################################### Restart options #####################################################

setenv RESTART_KMC              .false.   # IF true, restart from previous run
setenv RESTART_FILE         "this_conf"   # The file name used to continue a simulation from where it was last stopped
setenv RESTART_IMPORT           .false.   # Start NEW simulation with current KMC event catalogue
                                          #  (events.uft and topos.list)
setenv NEW_CATALOGUE            .false.   # Ccontinue simulation but will rebuild event catalogue from scratch
#setenv RESTART_MERGE           .false.   # Read multiple EVENT_DIR event files and combine them into a single catalogue
#setenv SIMINFO          'siminfo.list'   # List of directories to read for the RESTART_MERGE option

################################# Basin parameters #################################

setenv OSCILL_TREAT              BMRM     # choose between BMRM, TABU or NON
setenv MIN_SIG_BARRIER            0.1     # Max height of barrier and inv. barrier for an event to be considered
                                          # inside a basin
#setenv BASIN_LOCAL           .false.     # If true, local basins are used (default: false)
#setenv BASIN_RADIUS             10.0     # If using local basin, what is the radius of a local move 
#setenv BASIN_FACTOR              1.0     # Factor mult. INCREMENT_SIZE for leaving basin (default: 1.0d0)
#setenv FLICKER_DIR        'FLICKERS'     # The name of the directory where the TABU event files are stored
#setenv EVENTS_MEMORY             100     # Number of event to keep in memory for TABU (default: 100)
#setenv BASIN_MEMORY               10     # Number of basins to keep in memory for TABU (default: 10)

##################################### Topology Params ##################################

setenv TOPO_RADIUS                   6.0  # radius for topology cluster 
setenv MAX_TOPO_CUTOFF               2.7  # length-cutoff used by default to link two atoms 
setenv MIN_TOPO_CUTOFF               2.2  # minimal length cutoff used when looking at secondary topologies
setenv CRYST_TOPOID               973883  # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS             4.0  # radius for crystal-like topologies (default: 4.0 A) 
#setenv TOPO_IGNORE_FILE   'Topo_ignore'  # Topo ids to ignore (read at start of sim) (default: Topo_ignore)

#setenv TOPOLOGY_FILE       'Topologies'  # Info about topologies (not used for restarts) (default: Topologies)
#setenv TOPO_STAT_FILE      'topos.list'  # Statistics about topologies found (default: topos.list)
#setenv EVENT_IGNORE_FILE 'Event_ignore'  # File storing event ids to ignore (read at start of sim) (default: Event_ignore)
#setenv MAX_NODES_GRAPH               45  # maximum of nodes for the graphs, superseeds TOPO_RADIUS, default, natoms

##################################### GENERIC events parameters ########################

setenv SEARCH_FREQUENCY              10   # Minimum number of attempts to find a GENERIC event per new topology encountered
setenv THRES_INCREASE_FREQ           25   # Number of failed attempts encountered because increasing the EIGEN_THRESH
setenv TYPE_EVENT_UPDATE           SPEC   # choose between SPEC or GENE 
setenv USE_LOG_SEARCH            .false.   # Search frequency is multiplied by logarithmic increasing function (default .true.)

##################################### STOP FILE #######################################

#setenv STOP_FILE              "stop_now" # Name of the file that if present in the simulation dir at the end 
                                          # of a KMC step will cause the program to stop.
#setenv STOP_AFTER_BASIN           .true. # Program will wait to exit a basin before stopping the sim when a stopfile is present

#################################### DEBUG EVENT SEARCH parameters ####################

#setenv OUTPUT_NEB_GEN_EVENT       .false. # Creates 3 files per generic event in format used by the lammps 
                                          # implementation of NEB
                                          # use to check if initial-saddle-final configurations are well defined
#setenv NEB_DIR                     "NEB_DIR" # folder names for NEB output files.

#setenv CHECK_INI_SAD_CONNECTIVITY .false. # When GENERIC saddle is found, pushes the system towards the initial minimum
                                          #  and minimizes.
                                          # If minimized config. not the same as the initial one, the saddle is rejected.

#################################### Event analysis parameters #########################

#setenv BARRIER_CRITERIUM        5.0      # Max barrier (eV) to consider an event otherwise considered useless (default: 5.0 eV)
#setenv BARRIER_CHECK            0.2      # Minimum change in barrier needed to launch a scalar product during analysis (default: 0.1 eV)
#setenv DISPLACEMENT_THRESHOLD   0.15     # minimum distance (A) for considering an atom displaced. Used to calculate npart  (0.1 A by default)
#setenv INV_BARRIER_CRITERIUM             # Min inverse  barrier to consider and analyse an event (eV) (default: 0.5d0* Bconst*temperature)
#setenv DEL_E_EVENT              0.1      # Min energy difference between the final states of an event to decide in they are different (eV) (default 0.1 A) 
#setenv PARALLEL_CHECK           0.95     # Criterium for stating if two vectors are parallel from their scalar product (default: 0.95)
#setenv DISP_CHECK               0.15     # Criterium for comparing the displacement between two events (default: 0.15 A)
#setenv DELR_THRESH              1.0      # criterium used to check if displacement associated with an event is large enough (used if barrier and inv. barrier smaller than min_sig_barr) (default: 1.0 A)

##################################### Specific event parameters ########################

#setenv MAX_HISTO                 20       # The number of histogram bins (default: 100)
setenv REFINE_PUSH               0.1       # The ratio of the saddle-final distance pushed before minimizing a SPEC event
#setenv OUTPUT_SPECIFIC           .false.  # IF true, will create a SPEC_EVENT_DIR and output two txt files for each SPEC event found
#setenv SPEC_EVENTS_DIR  'SPEC_EVENTS_DIR' # Name of the SPEC_EVENT_DIR directory
#setenv MAX_SPEC_EV_NBRE          40       # The min number of spec events per atom in memory (if more, array is doubled, tripled, etc.)
#setenv REFINE_ATTEMPTS            2       # The number of attempts to refine a generic event (default: 2)
#setenv MIN_REFINE_BARRIER                 # minimal barrier to be refined, all barriers lower are cloned (default: 0.25d0 * Bconst*temperature)
#setenv BARRIER_CHANGE_THRESH              # Maximum acceptable change in barrier (in %) for refined events comp. to original GEN event (default: not used)
#setenv BARRIER_CHANGE_MIN                 # Minimum barrier needed to use BARRIER_CHANGE_THRESH in eV (default: 0.1 eV)

###################################### Mapping parameters ###############################

#setenv MAX_COM_DEVIATION      0.08       # maximum change in the displacement of CoM when mapping (default: 0.08 A) 
#setenv MAPPING_E_CUT          5.0E-1     # maximum difference in change in energy (default: 0.5 eV)
#setenv MAPPING_DELR           1.0        # maximum change in displacement when mapping (default: 1.0)

############## Statistics file names ###############################

############### STEEPEST DESCENT MINIMIZATION #######################

# setenv MAX_ITER_SD         2000         # default value
# setenv FTHRESHOLD_SD       1.0d-1       # default value 
# setenv STEPSIZE            1.0d-4       # default value

################ FIRE MINIMIZATION ###############
# setenv DTMAX_FIRE           0.15        # default value
# setenv DTMAX_FIRE_MIN       0.15        # default value=DTMAX_FIRE
# setenv MAX_ITER_FIRE        1500        # default value
# setenv NORM_CRITERIUM       0.0005      # default value
# setenv FMAX_CRITERIUM       0.0005      # default value

################ FIRE PERP. HYPERPLANE MINIMIZATION ############
# setenv MAX_ITER_FIRE_PERP    15          # default value
# setenv FOR_LEAVING_BASIN_USE_FIRE .true. # When relaxing perp for leaving harmonic basin if .true. choose FIRE algorithm else SD

####################################### Event catalogue file ########################################

#setenv UFT_EVENTFILENAME   'events.uft'   # The name of the uft event file (default: events.uft)
setenv USE_TXT_EVENTFILE   .false.         # IF true, will create a directory containing event files (txt format)
#setenv EVENTS_DIR          'EVENTS_DIR'   # The name of the directory where the event txt files are stored (default: EVENT_DIR)
#setenv CONVERT_TO_UFT      .false.        # IF true, the program will read the txt event files and create a new uft file
#setenv CONVERT_TO_TXT      .false.        # IF true, the program will read the uft file and copy the catalogue to txt files (use for vizualization) 

################## ART PARAMETERS ######################################################

################### Direction inversion in iterative subspace ###########################

#setenv USE_DIIS                 .false.   # Use DIIS for the final convergence to saddle
#setenv DIIS_FORCE_THRESHOLD      0.2      # Force threshold for convergence
#setenv DIIS_MEMORY                6       # Number of vectors kepts in memory for algorithm
#setenv DIIS_MAXITER              150      # Maximum number of iteractions for the DIIS scheme
#setenv DIIS_CHECK_EIGENVECTOR   .true.    # Check that the final state is indeed a saddle
#setenv DIIS_STEP_SIZE           0.005     # Step size for the position
#
####################################### ART options ####################################################### 

setenv SADDLE_PUSH_PARAM          0.1     # The fraction of the initial-saddle distance used to push saddle config. away from initial minimum (default: 0.1)
#setenv TYPE_OF_EVENTS             local   # Initial move for events - global or local
setenv RADIUS_INITIAL_DEFORMATION 2.5     # Cutoff for local-move (in angstroems)
setenv EIGENVALUE_THRESHOLD      -1.0     # Eigenvalue threshold for leaving basin
#setenv MAX_EIGEN_THRESH          -5.0    # 5*EIGENVALUE_THRESHOLD by default 
setenv EXIT_FORCE_THRESHOLD       0.05    # Threshold for convergence at saddle point
#setenv FINE_EXIT_FORCE_THRESHOLD  0.05    # finner Threshold for convergence at saddle point 
setenv MAX_PERP_MOVES_BASIN       2       # Maximum number of perpendicular steps leaving basin
setenv MIN_NUMBER_KSTEPS          2       # Min. number of ksteps before calling lanczos
#setenv INCREMENT_SIZE             0.1     # Overall scale for the increment moves in activation
setenv INITIAL_STEP_SIZE          0.01    # Size of initial displacement, in A
#setenv FORCE_THRESHOLD_PERP_REL   0.1     # Threshold for perpendicular relaxation
setenv MAX_ITER_BASIN             15      # Maximum number of iteraction for leaving the basin (kter)
setenv MAX_ITER_ACTIVATION        50      # Maximum number of iteraction during activation (iter)
setenv NUMBER_LANCZOS_VECTORS     15      # Number of vectors included in lanczos procedure
setenv LANCZOS_STEP               0.01    # Size of the step for the numerical derivative (def: 0.001)
# setenv MAX_TRIAL_TO_CONVERGE     10     # Number of attempts to converge to a SADDLE point (default: 10).

# CHECK_LANCZOS_STAB overwrite LANCZOS_STEP and loop for 1e-1 to 1e-7 to check stability and then stop the code. 
#setenv CHECK_LANCZOS_STAB  .false.         # Check lanczos stability over 200 steps, each iteration uses previous lanczos vector
setenv NBRE_POINTS_LANCZOS        1       # number of extra points for numerical derivative in lanczos default 1 supported 1 or 2 for now.
############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC           .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful


############### Run the simulation ######################################################################
unlimit stacksize
#../../src/KMCART_gnu2_briaree_v1458    # On briaree BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_mac_gfortran_v1458    # On mac     BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_ubuntu_gfortran_v1458 # On linux   BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_briareelammps_v1458   # On briaree (linux)   BECAREFUL THIS IS A PARALLEL VERSION OF THE CODE     
#../../src/KMCART_briaree_v1496   # On briaree (linux)   BECAREFUL THIS IS A PARALLEL VERSION OF THE CODE    
../../src/KMCART_exec             #executable pointig to the last version compiled

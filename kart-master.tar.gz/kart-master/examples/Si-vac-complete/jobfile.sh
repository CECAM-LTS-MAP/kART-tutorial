#!/bin/sh

#PBS -l walltime=00:50:00
#PBS -l nodes=1:ppn=4
#PBS -N Mk_test_briaree
#PBS -m abe
#PBS -M mickaeltrochet@yahoo.fr

cd $PBS_O_WORKDIR

module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3

#mkdir -p "EVENTS_DIR" # THIS FILE IS USED 
#mkdir -p "MINSAD_DIR" # ONLY ON THE SUPERCLUSTER BRIAREE FROM CALCULQUEBEC
#mkdir -p "EVLIST_DIR"  

#mpiexec ./KMC-long.sh 
mpiexec ./KMC-medium.sh 

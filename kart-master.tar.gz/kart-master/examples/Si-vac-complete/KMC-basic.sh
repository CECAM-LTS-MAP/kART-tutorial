#!/bin/csh
# IMPORTANT: By convention variables must be defined in uppercase, if one is in lowercase you will have Errors at 
#            the moment executing the script.
# To execute and test this script, put your executable at the end of this file, and type in the simulation dir: 
#        mpirun -np 2 KMC.sh      (using ls -l be sure that KMS.sh has right permitions to execute: -rwxr-xr-x )
# if you are in a cluster, use the stardar procedure to summit jobs.
 
####################################### System size and types ######################################
setenv INI_FILE_NAME    	 '511.conf'       # The file name containing the intial configuration 
setenv SIMULATION_BOX     	   21.7200        # The size of the simulation box (x, y and z)
setenv NUMBER_ATOMS    		       511        # The total number of atoms 
setenv NSPECIES        		         1        # The number of different atom types (default: 2)
setenv TEMPERATURE     		     500.0        # The simulated temperature in kelvin
setenv NBRE_KMC_STEPS        		 2        # The max number of KMC steps to be executed


####################################### Force field / Verlet neighbor list #######################

setenv ENERGY_CALC                     SWP        # choose between EDP or SWP or SWA or AFE or LAM  (Lammps)
setenv FORCE_CALC                      TTL        # choose TTL for total force calculation and PAR for partial force
setenv INPUT_LAMMPS_FILE       'in.lammps'        # LAMMPS input file when using ENERGY_TYPE = LAM to calculate the forces
#setenv UNITS_CONVERSION               real        # Converts the energy and distance units provided by the force code

####################################### Main Output options/files ########################################################
setenv STATISTICS                  .true.        # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS        .true.        # Create file with list of all the topologies and events after each KMC step
####################################### Restart options #####################################################

setenv RESTART_KMC                 .false.        # IF true, restart from previous run
setenv RESTART_FILE            "this_conf"        # The file name used to continue a simulation from where it was last stopped
setenv NEW_CATALOGUE               .false.        # Ccontinue simulation but will rebuild event catalogue from scratch
setenv RESTART_IMPORT              .false.        # Start NEW simulation with current KMC event catalogue (events.uft and topos.list)

####################################### Basin parameters #################################
setenv OSCILL_TREAT                  BMRM         # choose between BMRM, TABU or NON
setenv MIN_SIG_BARRIER                0.1         # Max height of barrier and inv. barrier for an event to be considered inside a basin

####################################### Topology Params ##################################
setenv TOPO_RADIUS                    6.0         # radius for topology cluster 
setenv MAX_TOPO_CUTOFF                2.7         # length-cutoff used by default to link two atoms 
setenv MIN_TOPO_CUTOFF                2.2         # minimal length cutoff used when looking at secondary topologies
setenv CRYST_TOPOID                973883         # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS              4.0         # radius for crystal-like topologies (default: 4.0 A) 

####################################### GENERIC events parameters ########################
setenv SEARCH_FREQUENCY                10         # Minimum number of attempts to find a GENERIC event per new topology encountered
setenv THRES_INCREASE_FREQ             25         # Number of failed attempts encountered because increasing the EIGEN_THRESH
setenv TYPE_EVENT_UPDATE             SPEC         # choose between SPEC or GENE 
setenv USE_LOG_SEARCH              .true.         # Search frequency is multiplied by logarithmic increasing function (default .true.)

####################################### Specific event parameters ########################
setenv REFINE_PUSH                    0.1         # The ratio of the saddle-final distance pushed before minimizing a SPEC event

####################################### Event catalogue file ########################################
setenv USE_TXT_EVENTFILE          .false.         # IF true, will create a directory containing event files (txt format)

####################################### ART PARAMETERS ######################################################

####################################### ART options ####################################################### 

setenv SADDLE_PUSH_PARAM              0.1         # Fraction of the ini-sad distance used to push sad. config. away from ini. min. (default: 0.1)
setenv RADIUS_INITIAL_DEFORMATION     2.5         # Cutoff for local-move (in angstroems)
setenv EIGENVALUE_THRESHOLD          -1.0         # Eigenvalue threshold for leaving basin
setenv EXIT_FORCE_THRESHOLD          0.05         # Threshold for convergence at saddle point
setenv MAX_PERP_MOVES_BASIN             2         # Maximum number of perpendicular steps leaving basin
setenv MIN_NUMBER_KSTEPS                2         # Min. number of ksteps before calling lanczos
setenv INITIAL_STEP_SIZE             0.01         # Size of initial displacement, in A
setenv MAX_PERP_MOVES_ACTIV             6         # Maximum number of perpendicular steps during activation
setenv MAX_ITER_BASIN                  15         # Maximum number of iteraction for leaving the basin (kter)
setenv MAX_ITER_ACTIVATION             50         # Maximum number of iteraction during activation (iter)
setenv NUMBER_LANCZOS_VECTORS          15         # Number of vectors included in lanczos procedure
setenv LANCZOS_STEP                  0.01         # Size of the step for the numerical derivative (def: 0.001)

############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC           .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful


############### Run the simulation ######################################################################
unlimit stacksize
#../../src/KMCART_gnu2_briaree_v1458              # On briaree BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_mac_gfortran_v1458              # On mac     BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_ubuntu_gfortran_v1458           # On linux   BECAREFUL THIS IS A SERIAL VERSION OF THE CODE
#../../src/KMCART_briareelammps_v1458             # On briaree (linux)   BECAREFUL THIS IS A PARALLEL VERSION OF THE CODE     
#../../src/KMCART_briaree_v1496                   # On briaree (linux)   BECAREFUL THIS IS A PARALLEL VERSION OF THE CODE    
../../src/KMCART_exec

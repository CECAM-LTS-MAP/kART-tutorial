#!/bin/sh                                                                                                                                                                                                         

#PBS -l walltime=00:50:00
#PBS -l nodes=1:ppn=4
#PBS -N Ni_1vac_eam
#PBS -m abe
cd $PBS_O_WORKDIR

module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3

time mpiexec ./KMC.sh

#!/bin/bash

where=$1

if [[ $where == "" ]]; then
    echo "missing location: briaree"
    exit
else
    for which in {Si-vac-lammps,FeC}; do
	cd $which
	qsub -N $which $where.sh
	cd -
    done
fi

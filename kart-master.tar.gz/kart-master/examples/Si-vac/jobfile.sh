#!/bin/sh

#PBS -l walltime=01:00:00
#PBS -l nodes=1:ppn=4
#PBS -N Mk_Si-vac_briaree
#PBS -m abe

cd $PBS_O_WORKDIR
module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3

#mkdir -p "EVENTS_DIR" # THIS FILE IS USED 
#mkdir -p "MINSAD_DIR" # ONLY ON THE SUPERCLUSTER BRIAREE FROM CALCULQUEBEC
#mkdir -p "EVLIST_DIR"  

mpiexec ./KMC.sh 

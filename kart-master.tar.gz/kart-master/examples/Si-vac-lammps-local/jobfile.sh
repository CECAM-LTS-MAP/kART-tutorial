#!/bin/sh

#PBS -l walltime=00:10:00
#PBS -l nodes=1:ppn=4
#PBS -N Mk_trunk_test
#PBS -m abe

cd $PBS_O_WORKDIR
# With Intel compiler
#module load intel-compilers/12.0.4.191
#module load MPI/Intel/openmpi/1.6.5
#module load FFTW/3.3
# With GNU compiler
#module purge
#module load MPI/Gnu/gcc4.9.2/openmpi/1.10.2
# With BL architecture
module load lammps/14May16 

mkdir -p "EVENTS_DIR" # THIS FILE IS USED 
mkdir -p "SPEC_EVENTS_DIR" # ONLY ON THE SUPERCLUSTER BRIAREE FROM CALCULQUEBEC
mkdir -p "EVLIST_DIR"  

time mpiexec ./KMC.sh 

#!/bin/sh

#PBS -l walltime=48:00:00
#PBS -l nodes=6:ppn=12
#PBS -N Mk_trunk_briaree
#PBS -m abe

cd $PBS_O_WORKDIR
module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3


mkdir EVLIST_DIR
mkdir SPEC_EVENTS_DIR
mkdir EVENTS_DIR


time mpiexec ./KMC.sh 

#!/bin/csh

###################################### Main Input/Output files ########################################################

setenv INI_FILE_NAME             'Si_irradiated'   # The file name containing the intial configuration 
 
###################################### Simulation Details ##################################################

setenv NBRE_KMC_STEPS                 100      # The max number of KMC steps to be executed
setenv TEMPERATURE                    500.0   # The simulated temperature in kelvin

setenv NUMBER_ATOMS                  117936   # The total number of atoms 
# setenv SIMULATION_BOX                 21.72   # The size of the simulation box (x, y and z)
setenv X_BOX                         141.203 
setenv Y_BOX                         146.634 
setenv Z_BOX                         114.049
setenv ATOMIC_SYMBOLS			"Si"
setenv NSPECIES                         1     # The number of different atom types (default: 2)

###################################### Restart options #####################################################

setenv RESTART_KMC                   .false.  # IF true, restart from previous run
setenv RESTART_FILE               "this_conf" # The file name used to continue a simulation from where it was last stopped
setenv RESTART_IMPORT                .false.  # Start a NEW simulation but with the current KMC event catalogue (events.uft and topos.list)
setenv NEW_CATALOGUE                 .false.  # IF true, will continue simulation but will rebuild event catalogue from scratch


#################################### Basin parameters #################################
setenv OSCILL_TREAT            BMRM       # choose between BMRM, TABU or NON
setenv MIN_SIG_BARRIER                 0.1    # Max height of barrier and inv. barrier for an event to be considered inside a basin

#################################### Topology Params ##################################

setenv TOPO_RADIUS                    6.0     # radius for topology cluster 
setenv MAX_TOPO_CUTOFF                2.7     # length-cutoff used by default to link two atoms
setenv MIN_TOPO_CUTOFF                2.2     # minimal length cutoff used when looking at secondary topologies 
setenv CRYST_TOPOID                   973883  # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS              4.0     # radius for crystal-like topologies (default: 4.0 A) 


#################################### Force calculations ###############################

setenv ENERGY_CALC                LAM      # choose between EDP or SWP or SWA or LAM (Lammps)
setenv FORCE_CALC                 TTL      # choose TTL for total force calculation and PAR for partial force
 
setenv LOCAL_LANCZOS             .true.   # Use a local displacement as initial random vector for lanczos (default: .false.)
setenv LOCAL_FORCE               .true.   # Use local forces for generic events (default: .false.)
setenv CELL_LENGTH                5.5     # Side (in Ang) of local cells for local-force - (default: TOPO_RADIUS) 
setenv REGION_WIDTH                2      # How many cells on each side of the central cell for defining a region (default: 2)

setenv INPUT_LAMMPS_FILE   'in.lammps'    # LAMMPS input file when using ENERGY_TYPE = LAM to calculate the forces
  
#UNITS_CONVERSION                 real      # Converts the energy and distance units provided by the force code
                                          # into a desired value for ART - affects only the parameters in ART and kART
                                          # units available are real , electron and si
                                          # be very careful when choosing other units, you must change parameters of energy 
                                          # and distance (if it's not in Angstrom) in input files for LAMMPS 
 
 setenv UPDATE_VER_NEIB           TTL      # choose TTL for total force calculation and PAR for partial force
 setenv NEIB_CALC                 ALL      # choose ALL or VER
 setenv UPDATE_TOPO               TTL       # choose TTL or PAR
 setenv PAR_DISP_THRESH2       0.00001     # max displacement squared which triggers an update of the neighbor 
                                           # list when using VER lists (default: 0.00001)                                                              
                                            
################# ART PARAMETERS ######################################################
setenv SADDLE_PUSH_PARAM          0.1     # The fraction of the initial-saddle distance used to push saddle config. away from initial minimum (default: 0.1)
setenv TYPE_OF_EVENTS             local   # Initial move for events - global or local
setenv RADIUS_INITIAL_DEFORMATION 2.5     # Cutoff for local-move (in angstroems)
setenv EIGENVALUE_THRESHOLD      -1.0     # Eigenvalue threshold for leaving basin
setenv EXIT_FORCE_THRESHOLD       0.05    # Threshold for convergence at saddle point
setenv FINE_EXIT_FORCE_THRESHOLD  0.05    # finner Threshold for convergence at saddle point 


setenv INCREMENT_SIZE             0.1     # Overall scale for the increment moves in activation
setenv FORCE_THRESHOLD_PERP_REL   0.1     # Threshold for perpendicular relaxation
setenv MAX_ITER_ACTIVATION        50      # Maximum number of iteraction during activation (iter)
setenv NUMBER_LANCZOS_VECTORS     15      # Number of vectors included in lanczos procedure
setenv LANCZOS_STEP               0.01    # Size of the step for the numerical derivative (def: 0.001)
# setenv CHECK_L$ANCZOS_STAB  .true.      # Check lanczos stability over 200 steps, each iteration uses previous lanczos vector

# setenv INITIAL_STEP_SIZE          0.01    # Size of initial displacement, in A
# setenv BASIN_FACTOR               1.5     # Multiplier for displacement (INCREMENT_SIZE) in the basin
# setenv MAX_PERP_MOVES_BASIN       2       # Maximum number of perpendicular steps leaving basin
# setenv MIN_NUMBER_KSTEPS          5       # Min. number of ksteps before calling lanczos
# setenv MAX_PERP_MOVES_ACTIV       8      # Maximum number of perpendicular steps during activation
# setenv MAX_ITER_BASIN             15      # Maximum number of iteraction for leaving the basin (kter)

setenv INITIAL_STEP_SIZE          1.00    # Size of initial displacement, in A
setenv BASIN_FACTOR               3.00
setenv MIN_NUMBER_KSTEPS          3       # Min. number of ksteps before calling lanczos
setenv MAX_PERP_MOVES_BASIN       6       # Maximum number of perpendicular steps leaving basin
setenv MAX_PERP_MOVES_ACTIV       20       # Maximum number of perpendicular steps during activation
setenv MAX_ITER_BASIN             40      # Maximum number of iteraction for leaving the basin (kter)




#################################### GENERIC events parameters ########################
setenv SEARCH_FREQUENCY      10           # Minimum number of attempts to find a GENERIC event per new topology encountered
setenv THRES_INCREASE_FREQ   25           # Number of failed attempts encountered because increasing the EIGEN_THRESH
setenv TYPE_EVENT_UPDATE     SPEC         # choose between SPEC or GENE 
setenv USE_LOG_SEARCH       .false.       # Search frequency is multiplied by logarithmic increasing function (default .true.)


############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC           .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful


############### Run the simulation ######################################################################
unlimit stacksize
# /Users/mousseau/Library/Mobile\ Documents/M6HJR9W95L~com~textasticapp~textastic/Documents/kART/src/KMCART_macgnu_lammps_mpi_v
#../../../kART_2016-01-04/src/KMCART_macgnu_lammps_mpi_v1547
#../../src/KMCART_briareelammps_v1586
../../src/KMCART_exec

#!/bin/csh

###################################### Main Input/Output files ########################################################

setenv INI_FILE_NAME       'initial.conf'   # The file name containing the intial configuration 

###################################### Simulation Details ##################################################

setenv NBRE_KMC_STEPS            5        # The max number of KMC steps to be executed
setenv TOTAL_TIME                1.0        # The maximum simulation time in seconds 
setenv TEMPERATURE               600.0      # The simulated temperature in kelvin

setenv NUMBER_ATOMS              1004       # The total number of atoms 
setenv SIMULATION_BOX           27.940638   # The size of the simulation box (x, y and z)
setenv NSPECIES                    2        # The number of different atom types (default: 2)

###################################### Restart options #####################################################

setenv RESTART_KMC             .false.      # IF true, restart from previous run
setenv RESTART_FILE          "this_conf"    # The file name used to continue a simulation from where it was last stopped
setenv RESTART_IMPORT          .false.      # Start a NEW simulation but with the current KMC event catalogue (events.uft and topos.list)
setenv NEW_CATALOGUE           .false.      # IF true, will continue simulation but will rebuild event catalogue from scratch


#################################### Basin parameters #################################

setenv MIN_SIG_BARRIER               0.1    # Max height of barrier and inv. barrier for an event to be considered inside a basin

#################################### Topology Params ##################################

setenv TOPO_RADIUS                  6.0      # radius for topology cluster 
setenv MAX_TOPO_CUTOFF              2.7      # length-cutoff used by default to link two atoms 
setenv CRYST_TOPOID                 973883   # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS            4.0      # radius for crystal-like topologies (default: 4.0 A) 


#################################### Force calculations ###############################

setenv ENERGY_CALC                   SIH     # choose between SIH, EDP or SWP or SWA or LAM (Lammps)

################# ART PARAMETERS ######################################################

setenv RADIUS_INITIAL_DEFORMATION   3.5      # Cutoff for local-move (in angstroems)
setenv EXIT_FORCE_THRESHOLD         0.05     # Threshold for convergence at saddle point
setenv FINE_EXIT_FORCE_THRESHOLD    0.05     # finner Threshold for convergence at saddle point 

setenv EIGENVALUE_THRESHOLD        -1.0      # Eigenvalue threshold for leaving basin
setenv MAX_PERP_MOVES_BASIN         2        # Maximum number of perpendicular steps leaving basin
setenv MIN_NUMBER_KSTEPS            2        # Min. number of ksteps before calling lanczos
setenv FORCE_THRESHOLD_PERP_REL     0.1      # Threshold for perpendicular relaxation

############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC           .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful


############### Run the simulation ######################################################################

../../src/KMCART_exec

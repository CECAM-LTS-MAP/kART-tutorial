#!/bin/sh

#PBS -l walltime=1:00:00
#PBS -l nodes=1:ppn=12
#PBS -N Mk_125000_box
#PBS -m abe
#PBS -M mickaeltrochet@yahoo.fr

cd $PBS_O_WORKDIR
module load intel-compilers/12.0.4.191
module load MPI/Intel/openmpi/1.6.5
module load FFTW/3.3


mpiexec ./KMC.sh 

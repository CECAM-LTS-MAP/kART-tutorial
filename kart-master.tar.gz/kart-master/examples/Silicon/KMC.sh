#!/bin/csh
###################################### Random number generator ###################################################

#setenv Random_seed         -1103       # Random seed used to generate random numbers (use only when debugging)

###################################### Main Input/Output files ########################################################

setenv INI_FILE_NAME       '511.conf'   # The file name containing the initial configuration 
setenv KLOGFILE           'KMC_log.txt' # The file name containing a list of the parameters used
setenv STATISTICS              .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS    .false.  # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv SAVE_FULL_EVENTS    .false.      # This allows to save all generic event for each node
setenv DISPL_FILE       'Diffusion.dat' # The file name used to store the squared displacement (default: Diffusion)
setenv CONFFILE         'allconf'       # Name of the file to store all the configurations visited (default: allconf)
setenv ATOMIC_TYPE_FILE 'Atomic_types'  # Name of input file contaning list of atomic types (read at start of sim) (default: Atomic_types)
setenv INPUT_LAMMPS_FILE    'in.lammps' # Name of the LAMMPS input file when using ENERGY_TYPE = LAM to calculate the forces

###################################### Simulation Details ##################################################

setenv NBRE_KMC_STEPS        100        # The max number of KMC steps to be executed
setenv TOTAL_TIME            1.0        # The maximum simulation time in seconds 
setenv ELAPSED_TIME          0.0        # The elapsed time before first KMC step (will be added to the sim. time) 
setenv STEP_KMC_MEASURE      1          # The  number of steps before each KMC  measurement (i.e. writing to the .dat files) 
setenv TEMPERATURE           600.0      # The simulated temperature in kelvin

###################################### Restart options #####################################################

setenv RESTART_KMC       .false.        # IF true, restart from previous run
setenv RESTART_FILE    "this_conf"      # The file name used to continue a simulation from where it was last stopped
setenv RESTART_IMPORT    .false.        # IF true, will start a NEW simulation but with the current KMC event catalogue (events.uft and topos.list)
setenv NEW_CATALOGUE     .false.        # IF true, will continue simulation but will rebuild event catalogue from scratch
setenv RESTART_MERGE     .false.        # IF true, will read multiple EVENT_DIR event files and combine them into a single catalogue
setenv SIMINFO         'siminfo.list'   # The file name containing the list of directories to read for the RESTART_MERGE option

##################################### System size and types ######################################

setenv NUMBER_ATOMS         511         # The total number of atoms 
setenv SIMULATION_BOX       21.72       # The size of the simulation box (x, y and z)
   #setenv X_BOX                        # the size of the simulation box in the x dimension
   #setenv Y_BOX                        # the size of the simulation box in the y dimension
   #setenv Z_BOX                        # the size of the simulation box in the z dimension
setenv NSPECIES               2         # The number of different atom types (default: 2)

#################################### Cell lists #######################################

setenv LATTICE_CONSTANT  5.43             # the lattice constant 
setenv NBRE_CELLS        6                # The number of smaller cell in each side of the box
#setenv NBRE_CELLSX
#setenv NBRE_CELLSY
#setenv NBRE_CELLSZ

#################################### Basin parameters #################################

setenv OSCILL_TREAT            BMRM       # choose between BMRM, TABU or NON
setenv MIN_SIG_BARRIER          0.1       # Max height of barrier and inv. barrier for an event to be considered inside a basin
setenv BASIN_LOCAL             .false.    # If true, local basins are used (default: false)
setenv BASIN_RADIUS            10.0       # If using local basin, what is the radius of a local move 
#setenv FLICKER_DIR           'FLICKERS'  # The name of the directory where the TABU event files are stored
#setenv EVENTS_MEMORY           100       # Number of event to keep in memory for TABU (default: 100)
#setenv BASIN_MEMORY            10        # Number of basins to keep in memory for TABU (default: 10)

#################################### Topology Params ##################################

setenv TOPOLOGY_FILE        'Topologies'   # Name of file to store info about topologies (not used for restarts) (default: Topologies)
setenv TOPO_STAT_FILE       'topos.list'   # Name of file to store statistics about topologies found (default: topos.list)
setenv TOPO_RADIUS          6.0            # radius for topology cluster 
setenv MAX_TOPO_CUTOFF      2.7            # length-cutoff used by default to link two atoms 
setenv MIN_TOPO_CUTOFF      2.2            # minimal length cutoff used when looking at secondary topologies
setenv CRYST_TOPOID         973883         # topo id of the crystalline-like topologies
setenv CRYST_TOPO_RADIUS    4.0            # radius for crystal-like topologies (default: 4.0 A) 
setenv TOPO_IGNORE_FILE    'Topo_ignore'   # Name of file where topo ids to ignore are stored (read at start of sim) (default: Topo_ignore)

#################################### GENERIC events parameters ########################

setenv SEARCH_FREQUENCY         15         # Minimum number of attempts to find a GENERIC event per new topology encountered
setenv THRES_INCREASE_FREQ      25         # Number of failed attempts encountered because increasing the EIGEN_THRESH
setenv TYPE_EVENT_UPDATE       SPEC        # choose between SPEC or GENE 
setenv USE_LOG_SEARCH         .true.       # IF true, the search frequency is multiplied by logarithmic increasing function (default .true.)
setenv EVENT_IGNORE_FILE    'Event_ignore' # Name of file where event ids to ignore are stored (read at start of sim) (default: Event_ignore)
setenv SADDLE_PUSH_PARAM       0.1         # The fraction of the initial-saddle distance used to push saddle config. away from initial minimum (default: 0.1)

#################################### Force calculations ###############################

setenv FORCE_CALC                  TTL      # choose TTL for total force calculation and PAR for partial force
setenv ENERGY_CALC                 SWP      # choose between EDP or SWP or SWA or LAM (Lammps)

#################################### Verlet neighbor lists params #######################

#setenv PAR_DISP_THRESH2       0.00001      #max displacement squared which triggers an update of the neighbor list when using VER lists (default: 0.00001)
setenv UPDATE_VER_NEIB              TTL      # choose TTL for total force calculation and PAR for partial force
setenv NEIB_CALC                    ALL      # choose ALL or VER
setenv UPDATE_TOPO                  TTL      # choose TTL or PAR

#################################### STOP FILE #######################################

setenv STOP_FILE                 "stop_now"  # Name of the file that if present in the simulation dir at the end of a KMC step will cause the program to stop.
setenv STOP_AFTER_BASIN           .true.     # IF true, the program will wait to exit a basin before stopping the sim when a stopfile is present

################################### DEBUG EVENT SEARCH parameters ####################

setenv OUTPUT_NEB_GEN_EVENT           .false. # IF true, creates 3 text files per generic event in format used by the lammps implementation of NEB
                                              # use to check if initial-saddle-final configurations are well defined
setenv CHECK_INI_SAD_CONNECTIVITY     .false. # IF true, when GENERIC saddle is found, pushes the system towards the initial minimum and minimizes.
                                              # If minimized config. not the same as the initial one, the saddle is rejected.

################################### Event analysis parameters #########################

#setenv BARRIER_CRITERIUM              5.0    # Max barrier (eV) to consider an event otherwise considered useless (default: 5.0 eV)
#setenv BARRIER_CHECK                  0.2    # Minimum change in barrier needed to launch a scalar product during analysis (default: 0.1 eV)
#setenv DISPLACEMENT_THRESHOLD         0.15   # minimum distance (A) for considering an atom displaced. Used to calculate npart  (0.1 A by default)
#setenv INV_BARRIER_CRITERIUM                 # Min inverse  barrier to consider and analyse an event (eV) (default: 0.5d0* Bconst*temperature)
#setenv DEL_E_EVENT                    0.1    # Min energy difference between the final states of an event to decide in they are different (eV) (default 0.1 A) 
#setenv PARALLEL_CHECK                 0.95   # Criterium for stating if two vectors are parallel from their scalar product (default: 0.95)
#setenv DISP_CHECK                     0.15   # Criterium for comparing the displacement between two events (default: 0.15 A)
#setenv DELR_THRESH                    1.0    # criterium used to check if displacement associated with an event is large enough (used if barrier and inv. barrier smaller
                                              # than min_sig_barr) (default: 1.0 A)

#################################### Specific event parameters ########################

setenv MAX_HISTO                       20     # The number of histogram bins (default: 100)
setenv REFINE_PUSH                     0.1    # The ratio of the saddle-final distance pushed before minimizing a SPEC event
setenv OUTPUT_SPECIFIC                .false. # IF true, will create a SPEC_EVENT_DIR and output two txt files for each SPEC event found
setenv MAX_SPEC_EV_NBRE                40     # The min number of spec events per atom in memory (if more, array is doubled, tripled, etc.)
setenv REFINE_ATTEMPTS                  2     # The number of attempts to refine a generic event (default: 2)
#setenv MIN_REFINE_BARRIER                    # minimal barrier to be refined, all barriers lower are cloned (default: 0.25d0 * Bconst*temperature)
#setenv BARRIER_CHANGE_THRESH                 # Maximum acceptable change in barrier (in %) for refined events comp. to original GEN event (default: not used)
#setenv BARRIER_CHANGE_MIN                    # Minimum barrier needed to use BARRIER_CHANGE_THRESH in eV (default: 0.1 eV)

##################################### Mapping parameters ###############################

#setenv MAX_CoM_DEVIATION             0.08    # maximum change in the displacement of CoM when mapping (default: 0.08 A) 
#setenv MAPPING_E_CUT                 5.0E-1  # maximum difference in change in energy (default: 0.5 eV)
#setenv MAPPING_DELR                  1.0     # maximum change in displacement when mapping (default: 1.0)

############## Statistics file names ###############################

#setenv EV_FILE              'selec_ev.dat'   # File name for statistics about the selected events
#setenv GENERIC_EV_STAT      'Gen_ev.dat'     # File name for statistics about the GEN events
#setenv SPECIFIC_EV_STAT     'Spec_ev.dat'    # File name for statistics about the SPEC events
#setenv ENERGY_STAT          'Energies.dat'   # File name for statistics about the Energy 
#setenv LOWEST_BARRIER       'MinBarr.dat'    # File name for statistics about the minimum barrier in the tree
#setenv BASIN_GRAPH          'basin_graph.gv' # File name for storing statistics about basins

############### STEEPEST DESCENT MINIMIZATION #######################

# setenv MAX_ITER_SD                          # default value = 2000
# setenv FTHRESHOLD_SD                        # default value = 1.0d-1 
# setenv STEPSIZE                             # default value = 1.0d-4

############### FIRE MINIMIZATION ###############

# setenv DTMAX_FIRE                    #default value = 0.15
# setenv MAX_ITER_FIRE                 #default value = 1500
# setenv NORM_CRITERIUM                #default value = 0.0005
# setenv FMAX_CRITERIUM                #default value = 0.0005

############### FIRE PERP. HYPERPLANE MINIMIZATION ############

# setenv MAX_ITER_FIRE_PERP            #default value = 15

###################################### Event catalogue file ########################################

setenv UFT_EVENTFILENAME       'events.uft'   # The name of the uft event file (default: events.uft)
setenv USE_TXT_EVENTFILE       .false.        # IF true, will create a directory containing event files (txt format)
setenv CONVERT_TO_UFT          .false.        # IF true, the program will read the txt event files and create a new uft file
setenv CONVERT_TO_TXT          .false.        # IF true, the program will read the uft file and copy the catalogue to txt files (use for vizualization) 
setenv EVENTS_DIR               'EVENT_DIR'   # The name of the directory where the event txt files are stored (default: EVENT_DIR)

################# ART PARAMETERS ######################################################

################## Direction inversion in iterative subspace ###########################

setenv USE_DIIS                   .false.     # Use DIIS for the final convergence to saddle
setenv DIIS_FORCE_THRESHOLD        0.2        # Force threshold for convergence
setenv DIIS_MEMORY                  6         # Number of vectors kepts in memory for algorithm
setenv DIIS_MAXITER                150        # Maximum number of iteractions for the DIIS scheme
setenv DIIS_CHECK_EIGENVECTOR     .true.      # Check that the final state is indeed a saddle
setenv DIIS_STEP_SIZE             0.005       # Step size for the position


###################################### ART options ####################################################### 

 setenv ART_TEMPERATURE              0.0      #
 setenv CENTRAL_ATOM                  1       # the defaut value for the preferred atom for local move
 setenv EVENT_TYPE                   NEW      # either 'new' or 'refine_saddle' when further converging a saddle point
 setenv TYPE_OF_EVENTS               local    # Initial move for events - global or local
 setenv RADIUS_INITIAL_DEFORMATION   2.5      # Cutoff for local-move (in angstroems)
 setenv EIGENVALUE_THRESHOLD        -1.0      # Eigenvalue threshold for leaving basin
 setenv EXIT_FORCE_THRESHOLD         0.05     # Threshold for convergence at saddle point
 setenv FINE_EXIT_FORCE_THRESHOLD    0.05     # finner Threshold for convergence at saddle point 
 setenv MAX_PERP_MOVES_BASIN         2        # Maximum number of perpendicular steps leaving basin
 setenv MIN_NUMBER_KSTEPS            2        # Min. number of ksteps before calling lanczos
 setenv INCREMENT_SIZE               0.1      # Overall scale for the increment moves in activation
 setenv INITIAL_STEP_SIZE            0.01     # Size of initial displacement, in A
 setenv MAX_PERP_MOVES_ACTIV         6        # Maximum number of perpendicular steps during activation
 setenv FORCE_THRESHOLD_PERP_REL     0.1      # Threshold for perpendicular relaxation
 setenv MAX_ITER_BASIN               15       # Maximum number of iteraction for leaving the basin (kter)
 setenv MAX_ITER_ACTIVATION          50       # Maximum number of iteraction during activation (iter)
 setenv NUMBER_LANCZOS_VECTORS       15       # Number of vectors included in lanczos procedure
 setenv LANCZOS_STEP                 0.01     # Size of the step for the numerical derivative (def: 0.001)


############### Printing details ######################################################################

setenv ALLCONF_WITH_SADDLE           .true.
setenv PRINT_DETAILS                 .true.  # Prints the details of activation and minimization 
setenv MINSAD_DETAILS                .false.  # Prints the details of activation and minimization 
setenv USE_TXT_EVENTFILE             .true.
setenv STATISTICS                    .true.   # Write statistics about force and event calculation  
setenv OUTPUT_CONFIG_EVENTS          .true.   # IF true, will create a txt file with the list of all the topologies and events after each KMC step
setenv OUTPUT_SPECIFIC           .true.
#setenv OUTPUT_NEB_GEN_EVENT        .true.    # Can be useful


############### Input #######################################################################
 setenv FILECOUNTER             filecounter   # File tracking  the file (event) number - facultative 
 setenv REFCONFIG               refconfig.dat # initial configuration file 


############### Run the simulation ######################################################################
../../src/KMCART_exec

#!/bin/sh

#PBS -l walltime=00:50:00
#PBS -l nodes=1:ppn=3
#PBS -A knp-440-ae 
#PBS -N SM_test_guillimin
#PBS -m abe
#PBS -M samimahmoud@live.com

cd $PBS_O_WORKDIR
module load ifort_icc/15.0           
module load openmpi/1.8.3-intel      
module load FFTW/3.3-openmpi-intel   
module load MKL/11.2

#mkdir -p "EVENTS_DIR" # THIS FILE IS USED 
#mkdir -p "MINSAD_DIR" # ONLY ON THE SUPERCLUSTER BRIAREE FROM CALCULQUEBEC
#mkdir -p "EVLIST_DIR"  

mpiexec ./KMC.sh 

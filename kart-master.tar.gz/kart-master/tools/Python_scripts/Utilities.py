

# Python module with general definitions :                                               # 
# OurParams():                                                                           # 
# own set of rcParams for kART output plotting                                           #
#                                                                                        #
# movingaverage(interval, window_size):                                                  #
# performing a rolling average                                                           #
#                                                                                        #
#                                                                                        #
# scalingdata(scaleTimeby):                                                              #
#                                                                                        #
# Avail_vs_select(data1x,data1y,data2x,data2y,data3):                                    #
#    """ Parameters                                                                      #
#    ---------------                                                                     #   
#                                                                                        #
#    data1x : Array                                                                      #
#        The x column from array of data (Matrice) Array_data                            #
#    data1y : Array                                                                      #
#        The y column from array of data (Matrice) Array_data                            #
#                                                                                        #
#    data2x : Array                                                                      #
#        The x column from array of data (Matrice ) Select                               #
#    data2y : Array                                                                      #
#        The y column from array of data (Matrice ) Select                               #
#                                                                                        #
#    data3 : Array                                                                       #
#        The vector of data AvailBarrierPerStep                                          #
#    """                                                                                 #
# Script tested in Mac and Linux OSs 2017, with python 3.4                               #
# Written By: Mickael Trochet                                                            #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------# #




import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
from cycler import cycler


def OurParams():
    print("Call of OurParams function.")
    tmp_params = {'figure.figsize'       : [10,7],
        'figure.subplot.left'  : 0.15,# control distance of left-axis to plot 
        'figure.subplot.right' : 0.88,# control distance of right-axis to plot 
        'figure.subplot.bottom': 0.14,# control distance of bottom-axis to plot  
        #'figure.subplot.top'  : 0.89,# control distance of top-axis to plot 
        #'savefig.dpi'         : 100, # figure dots per inch (not for eps or pdf as those are vector format)
        'savefig.transparent'  : True,# setting that controls whether figures are saved with a
        'axes.labelsize'  : 26, 
        'axes.titlesize'  : 26,
        'axes.linewidth'  : 1.5,
        # Choose pallete color for histograms in fig 9, here 10 different colors (you can add more or change order):
        'axes.prop_cycle' : ( cycler('color', ['b', 'r', 'g', 'y','c','violet','orange','m','brown','k']) ),
        #'lines.linewidth': 2,
        'xtick.labelsize' : 22, 
        'ytick.labelsize' : 22,
        'xtick.major.pad' : 8,
        'ytick.major.pad' : 8,
        'legend.labelspacing': 0.1, # the vertical space between the legend entries in fraction of fontsize
        'legend.framealpha'  : 0.5,# transparency of the label box
        'legend.numpoints': 1,
        'legend.fancybox': True,
        'legend.scatterpoints': 1,
        #'legend.fontsize'    : 22, # size of the legend when plot, you can chage olso using legend(prop={'size':22})
        #'legend.frameon'     : True,# put/remove frame of the label box
        'font.family' : 'sans-serif',
        'font.serif' : 'Arial'
            }    
    plt.rcParams.update(tmp_params) 
    print("rcParams has been updated")
    return tmp_params

def movingaverage(interval, window_size):
    window= np.ones(int(window_size))/float(window_size)
    return np.convolve(interval, window, 'same')


def scalingdata(scaleTimeby):
    # changing to proper time units:
    if (scaleTimeby=='day'):
        scaleTime = 3600.*24.
        unitsScale = "d"
    elif (scaleTimeby=='hour'):
        scaleTime = 3600.
        unitsScale = "h"
    elif (scaleTimeby=='minute'):
        scaleTime = 60. 
        unitsScale = "min"
    elif (scaleTimeby=='milli'):
        scaleTime = 1e-3
        unitsScale = "ms"
    elif (scaleTimeby=='micro'):
        scaleTime = 1e-6
        unitsScale = "$\mu$s"
    elif (scaleTimeby=='nano'):
        scaleTime = 1e-9
        unitsScale = "ns"
    elif (scaleTimeby=='pico'):
        scaleTime = 1e-12
        unitsScale = "ps"
    elif (scaleTimeby=='femto'):
        scaleTime = 1e-15
        unitsScale = "fs"
    else:
        scaleTime = 1
        unitsScale = "s"

    return scaleTime,unitsScale


def Avail_vs_select(data1x,data1y,data2x,data2y,data3):
    """ Parameters
    ---------------
    
    data1x : Array
        The x column from array of data (Matrice) Array_data
    data1y : Array
        The y column from array of data (Matrice) Array_data
        
    data2x : Array
        The x column from array of data (Matrice ) Select
    data2y : Array
        The y column from array of data (Matrice ) Select
      
    data3 : Array
        The vector of data AvailBarrierPerStep
    """
    fig = plt.figure()
    fig.patch.set_alpha(1.0)
    ax1 = fig.add_subplot(111)
    ax1.patch.set_alpha(0.5)

    plt.xlabel("KMC step")
    plt.ylabel("Activation energy (eV)")

    # set secondary x axis 
    ax2 = ax1.twinx()
    plt.ylabel("# of available events")
    ax2.patch.set_alpha(1.0)
    
    ax2.yaxis.label.set_color('blue')
    ax2.spines["right"].set_edgecolor('blue')
    ax2.tick_params(axis='y', colors='blue')

    #ax2.set_xticks(data2x[::Nlocator])
    #ax2.set_xticks(data2x)

    #ax2.set_xticklabels(map(str,data3[::Nlocator]),rotation =60,color ="blue")
    #ax2.set_xticklabels(map(str,data3),rotation =60,color ="blue")
    


    ax1.set_xlim(xmin = 0 ,xmax=np.max(data1x)+1)
    ax2.set_xlim(xmin = 0 ,xmax=np.max(data1x)+1)
    ax2.set_ylim(ymin = 0 ,ymax=np.max(data3)+10)


    # plot for density of point x axis 
    ax2.plot(data2x,data3, "b.",label="Number of Events",alpha=0.5 , rasterized=True)
    
    ax2.yaxis.set_major_locator(MaxNLocator(integer=True))
    #data3_av = movingaverage(data3,10)
    #ax2.plot(data2x,data3_av, "k",alpha=0.5 , rasterized=True)
    # Plot real data.
    #ax1.plot(data1x,data1y, "go",label="Available Barrier", alpha=0.5,ms=5, rasterized=True)
    ax1.plot(data1x,data1y, "g.",label="Available Events", alpha=0.5, rasterized=True)
    #ax1.plot(data2x,data2y,"rx",label="Selected Barrier, mean value : %6.2g  eV" %moy,rasterized = True)

    ax1.plot(data2x,data2y,"r.",label="Selected Event " %np.mean(data2y),rasterized = True)

    plt.axvline(data2x[150],color='b',linestyle='--')
    plt.axvline(data2x[200],color='b',linestyle='--')
    plt.axvspan(data2x[150],data2x[200],alpha=0.2,color='b')

    plt.axvline(data2x[1],color='k',linestyle='--')
    plt.axvline(data2x[150],color='k',linestyle='--')
    plt.axvspan(data2x[1],data2x[150],alpha=0.2,color='k')

    plt.xlim(xmax=np.max(data1x)+1)
    ax1.set_ylim(ymin=0,ymax=max(data1y)+1.0)

    ax2.set_zorder(-1)
    h1,l1 = ax1.get_legend_handles_labels()
    h2,l2 = ax2.get_legend_handles_labels()
    l= ax1.legend(h1+h2,l1+l2,loc="best")
    l.draggable(True)
    fig.tight_layout()    
    #if (yes == 'y'):
    #   lab.savefig(Plots_dir+'/AvailVsSelect.'+fileFormat, format=fileFormat) #, transparent=True)
    return fig      


def Avail_AtomFiltration(data1,data2,data3):
	#    """
	#	Parameters
	#	---------------
    #
	#	data1 : Array
    #    The array of data (Matrice) Array_data
	#	
	#	data2x : Array
    #    The array of data (Matrice ) Select
    #  
	#	data3 : Array
    #    The vector of data AvailBarrierPerStep

	#	"""
        fig = plt.figure()
        fig.patch.set_alpha(0.0)
        ax1 = fig.add_subplot(111)
        ax1.patch.set_alpha(0.0)
        plt.xlabel("KMCsteps")
        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylabel("Barrier (eV)")

        listsetAtomtype = list(set(map(int,data1[:,1])))
        for enum,i in enumerate(listsetAtomtype):
            filter_array = np.asarray(list(filter(lambda x: x[1] == i, data1)))
            plt.scatter(filter_array[:,0],filter_array[:,6],c=colorscater[enum],s= 10*10,alpha = 0, rasterized = True)

        ax2 = ax1.twiny()
        ax2.patch.set_alpha(0.0)
        ax2.set_xticks(data2[0:nconf:Nlocator,2])
        ax2.set_xticklabels(map(str,data3[::Nlocator]),rotation =60,color ="blue")
        ax2.set_xlim(xmax=nconf-1)

        for enum,i in enumerate(listsetAtomtype):
            filter_array = np.asarray(list(filter(lambda x: x[1] == i, data1)))
            plt.scatter(filter_array[:,0],filter_array[:,6],c=colorscater[enum],s= 10*10,alpha = 1, rasterized = True,label="Available Barrier center on %3s" %Atomtype[enum])
            print("atom type", i, " number of atom type", enum)
     
        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylim(ymin=0,ymax=max(data1[:,6])+0.5)
        plt.tight_layout()             
        l = plt.legend(loc='best')
        l.draggable(True)
        return fig      


def Avail_with_thirdAxes(data1,data2,data3,labeldata3):
        fig= plt.figure()
        fig.patch.set_alpha(0.0)
        ax1 = fig.add_subplot(111)
        ax1.patch.set_alpha(0.0)
        
        plt.xlabel("KMCsteps")

        sca=plt.scatter(data1,data2,c=data3,s=10*10,alpha= 1)
        cbar = fig.colorbar(sca)
        cbar.set_label(labeldata3)
        plt.ylabel("Barrier (eV)")

        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylim(ymin=0,ymax=max(data2)+0.5)
    
        plt.tight_layout()      
        return fig





# Python module to read and create dataFrame with pandas module                          # 
# form k-ART output files.                                                               #
#                                                                                        #
# Script tested in Mac and Linux OSs (2017), with python 3.4                             #
# Written By: Mickael Trochet                                                            #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------# #



from builtins import input
import os 
import numpy as np
import pandas as pd


# Generic definition to get a DataFrame for a file.
def readdatfile(filename,liststr_column_name,linebegin,lineend,columnbegin,columnend):
    variablename = np.loadtxt(filename)
    df = pd.DataFrame(variablename[linebegin:lineend,columnbegin:columnend],columns=liststr_column_name)
    return df 
    
def Energiesfile():
    print("\n Reading Energies.dat file ")
    Energies = np.loadtxt('Energies.dat')
    columnname = list(['KMCs','CPU time','Old energy','New energy','barrier','Total rate','time step','Sim time','Selec Ev','Init Topo','Sad Topo','Fin Topo'])
    df = pd.DataFrame(Energies[1:,:],columns=columnname)
    print("Energies.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    
    return df
    
def Diffusionfile(numofspecies):
    print("\n Reading Diffusion.dat file ")    
    Diffusion = np.loadtxt('Diffusion.dat')
    if (numofspecies == 1):
        columnname = list(['Elapsed Time','Total Sqr displ','KMC step','Event delr'])
    elif (numofspecies == 2):
        columnname = list(['Elapsed Time','Total Sqr displ','Type 1 Sqr displ','Type 2 Sqr displ','KMC step','Event delr'])
    elif (numofspecies == 3):
        columnname = list(['Elapsed Time','Total Sqr displ','Type 1 Sqr displ','Type 2 Sqr displ','Type 3 Sqr displ','KMC step','Event delr'])
        
    df = pd.DataFrame(Diffusion[1:,:],columns=columnname)
    print("Diffusion.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    return df

def selec_evfile():
    print("\n Reading selec_ev.dat file ")        
    selec_ev = np.loadtxt('selec_ev.dat')
    columnname = list(['CPU time','selcBarrier','KMC','EVENT','SPEC_EVENT','SELEC_ATOM','timestep','SimulT','Basin ID','Basin thresh'])
    df = pd.DataFrame(selec_ev[1:,:],columns=columnname)
    print("selec_ev.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    return df

def topo_statfile():
    print("\n Reading topo_stat.dat file ")    
    topo_stat = np.loadtxt('topo_stat.dat')
    columnname = list(['CPU time','currTOPO','activeTOPO','newTOPO','Cumul searched','CumulTOPO','diffTOPO','KMC','SimulT'])
    df = pd.DataFrame(topo_stat,columns=columnname)
    print("topo_stat.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    return df

def Gen_evfile():
    print("\n Reading Gen_ev.dat file ")    
    Gen_ev = np.loadtxt('Gen_ev.dat')
    columnname = list(['KMC step','Artn search','Saddle trials','Saddle found','GenEv excl','GenEv incl','NewGenEv excl','NewGenEv Incl','Tot GenEv Incl','Force eval'])
    df = pd.DataFrame(Gen_ev,columns=columnname)
    print("Gen_ev.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    return df

def Spec_evfile():
    print("\n Reading Spec_ev.dat file ")    
    Spec_ev = np.loadtxt('Spec_ev.dat')
    columnname = list(['KMC step','num of GenEv','To Refine','To Reconverge','To Cloned','SpecEv found','NewSpecEv found','Tot SpecEv','Thresh cloning','Ev cloned','Tot Ev'])
    df = pd.DataFrame(Spec_ev,columns=columnname)
    print("Spec_ev.dat file successfully read return a data Frame")
    print("Column names are :")
    print(columnname)
    return df





def readFolderEVLIST(oldornew,numberofKMCstep,numofcolumn):
    print("\n Reading event_listconf.* files from EVLIST_DIR ")   
    tmp_availBarrierPerStep = list()
    tmp_data= list()
    if (numofcolumn == 12):
        strcolumns = ["KMC step"]+["TypeId","AtomId","Init Topo","Sad Topo","Fin Topo","eventId","Spec_id","barrier","inv_bar","asy_ener","inisad_dr","inifin_dr"]
    elif (numofcolumn == 10):
        strcolumns = ["KMC step"]+["TypeId","AtomId","Init Topo","eventId","Spec_id","barrier","inv_bar","asy_ener","inisad_dr","inifin_dr"]
    else:
        print("Problem with the number of column to read in event_list_conf files.")
    if (oldornew == "old"):
        init = 0
        final = numberofKMCstep
    elif (oldornew == "new"):
        init = 1
        final =numberofKMCstep+1
 
    for i in range(init,final):
 
           Evlistconf = np.loadtxt('EVLIST_DIR/event_list_conf_'+str(i),usecols=range(numofcolumn))
           #Evlistconf = np.loadtxt('EVLIST2_DIR/event_list_conf_'+str(i),usecols=range(numofcolumn))
           if (np.shape(Evlistconf)==(numofcolumn,)):  # this means that there is only one event and Evlistconf is a vector not a matrix
               tmp_availBarrierPerStep.append(1)
               tmp_data.append([i]+list(Evlistconf))
           else:
              tmp_availBarrierPerStep.append(np.size(Evlistconf[:,5]))
              for j in range(np.size(Evlistconf[:,5])):
                   tmp_data.append([i]+list(Evlistconf[j,:]))
           if (i % 10 == 0):
                print(str(i)+'event_list_conf files read')
    df = pd.DataFrame(tmp_data,columns=strcolumns)
    print("event_listconf.* files from EVLIST_DIR successfully read return a data Frame and a list")
    print("Column names are for the Data Frame :")
    print(strcolumns)
    print("the list contain the number of available barriers for each KMCsteps. \n")
    return df,tmp_availBarrierPerStep
    
    
def readFolderEVLIST(numberofKMCstep):
    print("\n Reading event_listconf.* files from EVLIST_DIR ")   
    tmp_availBarrierPerStep = list()
    tmp_data= list()
    strcolumns = ["KMC step"]+["TypeId","AtomId","Init Topo","Sad Topo","Fin Topo","eventId","Spec_id","barrier","inv_bar","asy_ener","inisad_dr","inifin_dr"]
    init = 1
    final =numberofKMCstep+1
 
    for i in range(init,final):
 
           Evlistconf = np.loadtxt('EVLIST_DIR/event_list_conf_'+str(i),usecols=range(12))
           if (np.shape(Evlistconf)==(12,)):  # this means that there is only one event and Evlistconf is a vector not a matrix
               tmp_availBarrierPerStep.append(1)
               tmp_data.append([i]+list(Evlistconf))
           else:
              tmp_availBarrierPerStep.append(np.size(Evlistconf[:,5]))
              for j in range(np.size(Evlistconf[:,5])):
                   tmp_data.append([i]+list(Evlistconf[j,:]))
           if (i % 10 == 0):
                print(str(i)+'event_list_conf files read')
    df = pd.DataFrame(tmp_data,columns=strcolumns)
    print("event_listconf.* files from EVLIST_DIR successfully read return a data Frame and a list")
    print("Column names are for the Data Frame :")
    print(strcolumns)
    print("the list contain the number of available barriers for each KMCsteps. \n")
    return df,tmp_availBarrierPerStep
    
    

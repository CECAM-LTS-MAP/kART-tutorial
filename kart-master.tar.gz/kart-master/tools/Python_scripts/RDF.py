"""
Example: Radial distribution function g(r)
==========================================
Calculating *g(r)* (radial distribution function) of water, taking
into account periodic boundaries.
Contains a few speed-ups over the most naive implementation
 - use self_distance_array() instead of distance_array() and pre-allocate
   dist array
 - use numpy in-place operations where possible
 - use 1D histogram function (instead of e.g. histogramdd())

Profiling shows that the computational bottleneck is the
:func:`numpy.histogram` function.
"""


import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mat 
import sys
#----------------- choose version function input acording to python version ------------#
def INPUT(x): 
    #if (sys.version_info[0]==2):# If using python 2.x
    #   return raw_input(x)
    #else:                       # If using python 3.x 
    #return input(x)
    return ( raw_input(x) if(sys.version_info[0]==2) else input(x) )

def EVAL_INPUT(x):
    return ( input(x) if(sys.version_info[0]==2) else eval(input(x)))  
    
inputuser=INPUT("please enter the exact name of your input file (Default Silicium.xyz):")
if (inputuser == ''):
    inputFiles='Silicium.xyz'
else:
    inputFiles=inputuser

print inputuser , inputFiles

Position=np.loadtxt(inputFiles)
dummy = Position[:,0]
POSX  = Position[:,1]
POSY  = Position[:,2]
POSZ  = Position[:,3]

inputlat = INPUT('please enter the lattice parameter in Angstroem (Default value 5.43e0 for Si):')
if (inputlat == ''):
    lat = 5.43e0
else:
    lat = inputlat
inputcells = INPUT('please entre in the form (xx,xx,xx) the number of x,y and z cells (Default value (4,4,4)):')
if (inputcells == ''):
    xcell = 4
    ycell = 4
    zcell = 4
else:
    xcell = inputcells[0]
    ycell = inputcells[1]
    zcell = inputcells[2]

sizeBox = [xcell*lat , ycell*lat , zcell*lat]
#init variable 
delx = 0.0e0
dely = 0.0e0
delz = 0.0e0
dist = 0.0e0
num_bins = 0
num_bins2 = 0
k    = 0
dist_list = [ ]

def distancePBC(xa,xb,ya,yb,za,zb,sizeBox, dist_list):
    delx = min(np.abs(xb-xa) ,np.abs(xb-xa+sizeBox[0]) , np.abs(xb-xa-sizeBox[0]))
    dely = min(np.abs(yb-ya) ,np.abs(yb-ya+sizeBox[1]) , np.abs(yb-ya-sizeBox[1]))
    delz = min(np.abs(zb-za) ,np.abs(zb-za+sizeBox[2]) , np.abs(zb-za-sizeBox[2])) 
    dist = np.sqrt(delx**2 + dely**2 +delz**2)
    dist_list.append(dist)


for j in range(1,POSX.size):
    k=k+1
    #print k
    distancePBC(POSX[0] ,POSX[j] ,POSY[0] ,POSY[j] ,POSZ[0] ,POSZ[j] ,sizeBox , dist_list)

        
dist_array = np.array(dist_list)
num_bins= int(np.size(dist_array))
num_bins2= int(np.size(dist_array[0:1000]/10))


#plt.hist(dist_array,num_bins, normed=True)
plt.hist(dist_array,num_bins, normed=False)
plt.xticks(fontsize=40)
plt.yticks(fontsize=40)
plt.xlabel('histogram of the radial distribution in Angstroem ',fontsize=40)

plt.show()

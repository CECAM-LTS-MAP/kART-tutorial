# -*- coding: utf-8 -*-

# Copyright (c) Norwegian University of Science and Technology (NTNU) and SINTEF Materials and Chemistry, 2017
# By Jesper Friis
# Edition by Simen Nut Hansen Eliassen and Mickael Trochet 
"""
Module for setting up kART input.

If the kart python package is installed system-wise (and not just with a
symlink from a directory in your PYTHONPATH to the TOOLS/python/ in the
sources), you should set the KMC_ROOT_DIR environment variable to the root
directory of the svn sources before importing this directory.
"""
import os
import re
import itertools
import shlex
from string import Template

import numpy as np
import ase
import ase.io.formats

import lammps # import ase.io.lammps as lammps


# The root directory for kART
if 'KMC_ROOT_DIR' in os.environ:
    KMC_ROOT_DIR = os.environ['KMC_ROOT_DIR']
else:
    KMC_ROOT_DIR = os.path.normpath(os.path.join(
            os.path.realpath(os.path.dirname(__file__)), '..', '..'))


class KMCInputError(Exception):
    """Raised on error when reading input."""
    pass


class KMC(object):
    """Class for reading results from kART.
    """
    def __init__(self, kmcfile='KMC.sh'):
        self.inputpar = {}      # Input parameters in KMC.sh
        self.read_kmcpar(kmcfile)
        self.energies = None
        self._energies_mtime = None

    def read_kmcpar(self, kmcfile='KMC.sh', clear=True):
        """Reads input parameters from `kmcfile`.  If `clear` is true, the
        `inputpar` dict is cleared first."""
        if clear:
            self.inputpar.clear()
        with open(kmcfile) as f:
            for line in f:
                line = line.strip()
                if line.startswith('setenv'):
                    name, value = shlex.split(line)[1:3]
                elif line.startswith('export'):
                    name, value = shlex.split(line)[1].split('=', 1)
                else:
                    continue
                self.inputpar[name] = value

    def get_atom_types(self, try_lammps=True):
        """Returns atom types.  If `try_lammps` is true, we try to read the
        atom types from LAMMPS if they cannot be determined from the KMC
        input."""
        if 'ATOMIC_SPECIES' in self.inputpar:
            atom_types = self.inputpar['ATOMIC_SPECIES'].split()
        elif 'ATOMIC_TYPE_FILE' in self.inputpar:
            atom_types = []
            for line in open(values['ATOMIC_TYPES_FILE']):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                atom_types.append(line.split()[0])
        elif 'INPUT_LAMMPS_FILE' in self.inputpar:
            atom_types = lammps.get_atom_types_from_input(
                self.inputpar['INPUT_LAMMPS_FILE'])
        else:
            raise KMCInputError('Cannot get atom_types.  Define ATOMIC_SYMBOLS '
                               'in your KMC.sh file.')
        if 'NSPECIES' in self.inputpar:
            nspecies = int(self.inputpar['NSPECIES'])
            if len(atom_types) != nspecies:
                raise KMCInputError(
                    'NSPECIES=%d does not correspond to number '
                    'of atom types=%d' % (nspecies, len(atom_types)))
        return atom_types
        
    def get_cellpar(self):
        """Returns kART cell parameters (array of 3 floats)."""
        cellpar = [None] * 3
        if 'SIMULATION_BOX' in self.inputpar:
            cellpar = [float(self.inputpar['SIMULATION_BOX'])] * 3
        if 'X_BOX' in self.inputpar:
            cellpar[0] = float(self.inputpar['X_BOX'])
        if 'Y_BOX' in self.inputpar:
            cellpar[1] = float(self.inputpar['Y_BOX'])
        if 'Z_BOX' in self.inputpar:
            cellpar[2] = float(self.inputpar['Z_BOX'])
        if None not in cellpar:
            return np.array(cellpar)

        if  'INPUT_LAMMPS_FILE' in self.inputpar:
            try:
                atom_types = self.get_atom_types(try_lammps=False)
            except KMCInputError:
                atom_types = None
            lmp = lammps.LammpsInput(self.inputpar['INPUT_LAMMPS_FILE'])
            return diag(lmp.get_atoms().cell)

    def get_initial(self):
        """Returns initial structure as an Atoms object."""
        return read_initial(self.inputpar['INI_FILE_NAME'], 
                            atom_types=self.get_atom_types(),
                            cellpar=self.get_cellpar())

    def get_energies(self, filename='Energies.dat'):
        """
        """
        if self._energies_mtime != os.path.getmtime(filename):
            self._energies_mtime = os.path.getmtime(filename)
            self.energies = np.recfromtxt(
                filename, skip_header=2,
                names='KMCstep,CPUtime,old_energy,new_energy,barrier,total_rate,'
                'time_step,sim_time,event,init_topo,saddle_topo,final_topo')
        return self.energies

    





def read_kmc(filename='KMC.sh'):
    """Reads a kART KMC.sh input file and return an Atoms object.

    Note - this function is depricated. Use the KMC class instead.
    """
    # Read values of selected variables from KMC.sh
    names = (
        'INI_FILE_NAME',
        'SIMULATION_BOX',
        'X_BOX',
        'Y_BOX',
        'Z_BOX',
        'NUMBER_ATOMS',
        'NSPECIES',
        'ATOMIC_TYPE_FILE',
        'INPUT_LAMMPS_FILE',
        )
    values = dict((name, None) for name in names)
    with open(filename) as f:
        for line in f:
            for name in names:
                m = re.search(name + r'(\s+|=)(\S+)', line)
                if m:
                    values[name] = m.groups()[1].strip('\'"')

    atom_types = None
    if values['ATOMIC_TYPE_FILE']:
        atom_types = []
        for line in open(values['ATOMIC_TYPES_FILE']):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            atom_types.append(line.split()[0])
        if int(value['NSPECIES']) != len(atom_types):
            raise ValueError(
                'NSPECIES should be %d in "%s" according to "%s"' % (
                    len(atom_types), filename, value['ATOMIC_TYPE_FILE']))
    elif values['INPUT_LAMMPS_FILE']:
        atom_types = lammps.get_atom_types_from_input(
            values['INPUT_LAMMPS_FILE'])

    cellpar = None
    if values['SIMULATION_BOX']:
        cellpar = [float(values['SIMULATION_BOX'])] * 3
    elif values['X_BOX']:
        cellpar = [float(values['X_BOX']), 
                   float(values['Y_BOX']), 
                   float(values['Z_BOX'])]

    atoms = read_initial(values['INI_FILE_NAME'], atom_types=atom_types,
                         cellpar=cellpar)
    if int(values['NUMBER_ATOMS']) != len(atoms):
        raise ValueError(
            'NUMBER_ATOMS in "%s" should be %d according to "%s"' % (
                filename, len(atoms), values['INI_FILE_NAME']))
    return atoms

           

def read_initial(filename='initial.conf', atom_types=None, cellpar=None, 
                 lammps=False, triclinic=False):
    """Reads a kART/LAMMPS atom configuration input file and return an 
    Atoms object.

    Parameters
    ----------
    filename : string
        Output file name.
    atom_types : None | string | sequence of strings
        The atom species as a comma-separated string or sequence of chemical
        symbols.  
        The default is to try reading them from the first line in `filename`.
    cellpar : None | 3 floats
        The length of the sides of the simulation cell. Note that kART 
        currently only supports orthorombic systems.
        The default is to try reading them from `filename`.  If `lammps` is
        false, the 3rd line is used.
    lammps : bool
        Whether to read a LAMMPS configuration file instead of a kART
        "initial.conf" file.
    """
    lines = open(filename, 'r').readlines(1024)  # we just want the first lines

    # Get atom_types
    if atom_types is None:
        comment = lines[0].strip()
        if comment.startswith('#'):
            comment = comment[1:].lstrip()
        atom_types = comment.split()
    elif isinstance(atom_types, str):
        atom_types = atom_types.split(',')
    for s in atom_types:
        if not s in ase.data.atomic_numbers:
            raise ValueError('%r is not a valid chemical symbol. Check the '
                             'first line of "%s"' % (s, filename))
    
    # Get cellpar
    if cellpar is None:
        if lammps:
            cellpar = [float(lines[4 + i].split()[1]) for i in range(3)]
        elif (triclinic):
            print('I am here (Triclinic)')
            s1 = lines[2].strip().split()
            s2 = lines[3].strip().split()
            s3 = lines[4].strip().split()
            cellpar = [np.array(s1), np.array(s2), np.array(s3)]
            print(cellpar)
        else:
            s = lines[2].strip()
            if s.startswith('#'):
                s = s[1:].lstrip()
            sizes = s.split()
            print(sizes)
            if len(sizes) != 3:
                raise ValueError('Third line of "%s" is expedted to hold the'
                                 'size of the simulation cell (3 floats)' % 
                                 filename)
            cellpar = [float(x) for x in sizes]
    
    # Read symbols and positions
    if lammps:
        skiplines = 10
        dtype = [('no', 'i8'), ('typeno', 'i8'), 
                 ('x', 'f8'), ('y', 'f8'), ('z', 'f8')]
    elif (triclinic):
        print('I am here (Triclinic)')
        skiplines = 5
        dtype = [('typeno', 'i8'), ('x', 'f8'), ('y', 'f8'), ('z', 'f8')]
    else:
        skiplines = 3
        dtype = [('typeno', 'i8'), ('x', 'f8'), ('y', 'f8'), ('z', 'f8')]

    rec = np.recfromtxt(filename, skip_header=skiplines, dtype=dtype)
    #symbols = np.array(atom_types)[rec.typeno - 1]
    atomic_numbers=rec[['typeno']].view('i8').reshape(-1,1)
    positions = rec[['x', 'y', 'z']].view('f8').reshape(-1, 3)
    atoms = ase.Atoms(
        #symbols=symbols,
        positions=positions,
        cell=cellpar,
        pbc=True,
        )
    return atoms, atomic_numbers


def read_allconf(filename='allconf', atom_types=None, index=None):
    """Reads a kART "allconf" output input file and return a list of
    Atoms objects.

    Parameters
    ----------
    filename : string
        kART "allconf" output file name.
    atom_types : None | string | sequence of strings
        If given, this argument provides a fix for (old version of) kART
        denoting the first element Si, the second element O, etc. It should be
        a comma-separated string or a sequence of chemical symbols with the
        correct atomic types (in the correct order).
    index : None | int | slice | str
        What configuration to return.  The default is to return all 
        configurations.

    Note
    ----
    This function may be somewhat slow (125 images with 10000 atoms may take
    about 16 s to read and process), but is efficient with respect to the
    number of atoms.
    """
    indexslice = index2slice(index)

    dtype = [('symbol', 'S6'), ('x', 'f8'), ('y', 'f8'), ('z', 'f8'), 
             ('id', 'i8')]
    if atom_types:
        # FIXME - continue the kART order list
        kART_order = 'Si,O,C,Fe,Ni,Ga,Cu,H,Li,Al,Pt,Bi'.split(',')
        atmap = dict(z for z in zip(kART_order, atom_types))
    allatoms = []
    with open(filename, 'r') as f:
        n = 0  # XXX
        while True:
            header = itertools.islice(f, 2)
            try:
                natoms = int(header.next())
            except StopIteration:
                break
            #cellpar = [float(token) for token in header.next().split()][1:4]             '''Problem with split, changes is on the next three lines''
            cellpar_list = header.next().split()[1:10] 
            cellpar_list = cellpar_list[0:3],cellpar_list[3:6],cellpar_list[6:9]
            cellpar = np.array(cellpar_list)
            data = np.loadtxt(itertools.islice(f, natoms), dtype=dtype)
            symbols = data['symbol']
            if atom_types:
                symbols = [atmap[s] for s in symbols]
            pos = data[['x', 'y', 'z']].view(np.float).reshape(natoms, 3)
            allatoms.append(ase.Atoms(symbols=symbols, 
                                      positions=pos,
                                      cell=cellpar,
                                      pbc=True))
    return allatoms
                            

# Constants for default KMC.sh templates
KMC_BASIC   = 0  # KMC-basic.sh from the Si-vac-complete example
KMC_MEDIUM  = 1  # KMC-medium.sh from the Si-vac-complete example
KMC_LONG    = 2  # KMC-long.sh from the Si-vac-complete example
KMC_DEFAULT = 3  # KMC.sh.default in SRC dir

def write_kmc(atoms, order_or_lammpsfile=None, kmcfile='KMC.sh', 
              template=KMC_MEDIUM, lammpsdata=None,
              insert_new_kwargs=False, **kwargs):
    """Sets up an kART calculation by creating default "KMC.sh",
    "initial.conf" and "in.lammps" files based on `atoms`.  

    Note that the created "KMC.sh" file should be edited before running the
    simulation.

    Parameters
    ----------
    atoms : Atoms instance
        The structure you want to set up the calculation for.
    order_or_lammpsfile : None | string | sequence of strings
        The order of species as a sequence of chemical symbols.
        The default is to sort the chemical symbols alphabetically.
        If a string is provided, it is interpreated as the name of a 
        LAMMPS input file defining the order of species.
    kmcfile : None | string
        Name of output KMC.sh file.
    template : string | KMC_BASIC | KMC_MEDIUM | KMC_LONG | KMC_DEFAULT
        A template KMC.sh file that `kmcfile` should be based on.  The 
        values KMC_BASIC, KMC_MEDIUM, KMC_LONG, KMC_DEFAULT may be used
        for different defaults in the kART distribution.
    lammpsdata : None | string
        Name of LAMMPS data file to create.  The default is to not create
        this file.  Note, you have to uncomment the "read_data" command in 
        `INPUT_LAMMPS_FILE` in order to actually use it.
    insert_new_kwargs : bool
        Wheter to insert `kwargs` that are not defined in `template`.
        If false, an exception is raised if `kwargs` contains variables not
        defined in `template`.
    **kwargs
        Name and new value of any variable you want to change in `template`.
    """
    check_for_diagonal_cell(atoms)
    atoms = lammps.sortatoms(atoms, order_or_lammpsfile)
    symbols = np.array(atoms.get_chemical_symbols())
    idx = np.unique(symbols, True, True)[1]
    atom_types = symbols[idx].tolist()
    if template == KMC_BASIC:
        template = os.path.join(
            KMC_ROOT_DIR, 'EXAMPLES', 'Si-vac-complete', 'KMC-basic.sh')
    elif template == KMC_MEDIUM:
        template = os.path.join(
            KMC_ROOT_DIR, 'EXAMPLES', 'Si-vac-complete', 'KMC-medium.sh')
    elif template == KMC_LONG:
        template = os.path.join(
            KMC_ROOT_DIR, 'EXAMPLES', 'Si-vac-complete', 'KMC-long.sh')
    elif template == KMC_DEFAULT:
        template = os.path.join(KMC_ROOT_DIR, 'SRC', 'KMC.sh.default')

    # Check that all kwargs are uppercase
    for k in kwargs:
        if k.upper() != k:
            raise ValueError('KMC variable %r should be upper case' % k)

    # Set defaults
    defaultkeys = ['NUMBER_ATOMS', 'NSPECIES', 'ATOMIC_SYMBOLS', 
                   'SIMULATION_BOX', 'ENERGY_CALC']
    kwargs.setdefault('NUMBER_ATOMS', len(atoms))
    kwargs.setdefault('NSPECIES', len(atom_types))
    kwargs.setdefault('ATOMIC_SYMBOLS', ' '.join(atom_types))
    kwargs.setdefault('SIMULATION_BOX', None)
    #kwargs.setdefault('X_BOX', atoms.cell[0, 0])  # not needed any more...
    #kwargs.setdefault('Y_BOX', atoms.cell[1, 1])
    #kwargs.setdefault('Z_BOX', atoms.cell[2, 2])
    if kwargs.get('INPUT_LAMMPS_FILE'):
        kwargs.setdefault('ENERGY_CALC', 'LAM')

    # Read template and update setenv statements
    defaults = {}  # variables set in `template`
    lines = open(template).readlines()
    for i, line in enumerate(lines):
        # Extract ``comment, var, value, doc`` from setenv lines
        m = re.match(r'(#\s*)?setenv\s+(\S+)(\s+(' +
                     r'(([^"\'\s#]+)|("[^"]+")|(\'[^"\']+\'))?' +
                     r'(\s*(#.*))?)?)?', line)
        if not m:
            continue
        groups = m.groups()
        comment = groups[0] if groups[0] else ''
        var = groups[1]
        value = groups[4] if groups[4] else ''
        doc = groups[-1] if groups[-1] else ''
        # Update lines
        defaults[var] = value
        if var in kwargs:
            comment = '#' if kwargs[var] is None else ''
            if kwargs[var] is not None:
                value = repr(kwargs[var])
        lines[i] = '%ssetenv %-26s %-14s %s\n' % (comment, var, value, doc)

    # Insert new variables at beginning of KMC.sh
    extra_lines = []
    for k, v in sorted(kwargs.items()):
        if k not in defaults:
            if not insert_new_kwargs and k not in defaultkeys:
                raise RuntimeError('Keyword argument %r is not defined in '
                                   'template file "%s"' % (k, template))
            comment = '#' if v is None else ''
            extra_lines.append('%ssetenv %-26s %-14r\n' % (comment, k, v))
    if extra_lines:
        n = 0
        while lines[n].startswith('#'):
            n += 1
        lines = lines[:n] + extra_lines + lines[n:]

    # Write output files
    kw = dict((k, v[1:-1] if v and v[0] in '"\'' else v) 
        for k, v in defaults.items())
    kw.update(kwargs)
    if kmcfile:  # KMC.sh
        with open(kmcfile, 'w') as f:
            f.write(''.join(lines))
    if kw.get('INI_FILE_NAME'):  # initial.conf
        write_conf(atoms, kw['INI_FILE_NAME'])
    if kw.get('INPUT_LAMMPS_FILE'):  # in.lammps
        if isinstance(order_or_lammpsfile, str):
            order = None
        else:
            order = order_or_lammpsfile
        write_lammps_input(atoms, kw['INPUT_LAMMPS_FILE'], order=order, 
                           lammpsdata=lammpsdata)


def write_conf(atoms, atno, filename='initial.conf', order_or_lammpsfile=None, 
               comment=None,triclinic=False):
    """Write kART atom configuration input file.

    Parameters
    ----------
    atoms : Atoms instance
        Atoms instance to write. 
    filename : string
        Output file name.
    order_or_lammpsfile : None | string | sequence of strings
        The order of species as a sequence of chemical symbols.
        The default is to sort the chemical symbols alphabetically.
        If a string is provided, it is interpreated as the name of a 
        LAMMPS input file defining the order of species.
    comment : None | string
        Optional comment at the first line. Defaults to atom types.
    """
    #check_for_diagonal_cell(atoms)
    atoms = lammps.sortatoms(atoms, order_or_lammpsfile)

    # Make a ordered list of atom types
    symbols = atoms.get_chemical_symbols()
    '''
    atno = {}
    n = 0
    for s in symbols:
        if s not in atno:
            n += 1
            atno[s] = n
    atom_types = [s for s, i in sorted(atno.items(), key=lambda t: t[1])]
    assert len(atom_types) == n

    # Default comment
    if comment is None:
        comment = ' '.join(atom_types)
    '''
    # Create a list with file content
    s = []
    s.append('  %s' % comment)
    s.append('  %d' % len(atoms))
    if (triclinic):
        s.append('  %12.6f  %12.6f  %.6f ' % tuple(atoms.cell[0,:]))
        s.append('  %12.6f  %12.6f  %.6f ' % tuple(atoms.cell[1,:]))
        s.append('  %12.6f  %12.6f  %.6f ' % tuple(atoms.cell[2,:]))
    else:
        s.append('  %12.6f  %12.6f  %.6f' % tuple(np.diag(atoms.cell)))

    for i, p in enumerate(atoms.positions):
        s.append('  %2d  %12.6f  %12.6f  %12.6f' % (
                atno[i], p[0], p[1], p[2]))

    # Write to filename
    with open(filename, 'w') as f:
        f.write('\n'.join(s) + '\n')




def write_lammps_input(atoms, filename='in.lammps', order=None, 
                       lammpsdata=None):
    """Writes a default LAMMPS input file for kART.  You have to review it
    and set correct potentials.
    
    Parameters
    ----------
    atoms : Atoms instance
        Atoms instance to write. 
    filename : string
        Output file name.
    order : sequence of strings
        The order of species as a sequence of chemical symbols.
        The default is to sort the chemical symbols alphabetically.
    lammpsdata : None | string
        If not None, write also a data file for LAMMPS named `lammpsdata`.
    """
    check_for_diagonal_cell(atoms)
    atoms = lammps.sortatoms(atoms, order)

    # Make a ordered list of atom types
    symbols = atoms.get_chemical_symbols()
    typeno = {}
    for i, s in enumerate(symbols):
        if s not in typeno:
            typeno[s] = i + 1
    atom_types = [s for s, i in sorted(typeno.items(), key=lambda t: t[1])]

    # Define parameters
    xhi, yhi, zhi = np.diag(atoms.cell)
    atlist = ['create_atoms     %-4d    random %-6d  %-6d  Box' % (
            typeno[s], symbols.count(s), 123455 + typeno[s]) for s in atom_types]
    masslist = ['mass             %-4d   %9.5f    # %s' % (
            typeno[s], ase.data.atomic_masses[ase.data.atomic_numbers[s]], s)
                for s in atom_types]

    # Update template
    template = Template(open(os.path.join(os.path.dirname(__file__), 
                                          'in.lammps.template'), 'rt').read())
    s = template.substitute(
        xhi='%.6f' % xhi, 
        yhi='%.6f' % yhi, 
        zhi='%.6f' % zhi, 
        ntypes=len(atom_types),
        create_atoms='\n'.join(atlist), 
        masses='\n'.join(masslist),
        lammpsdata=lammpsdata if lammpsdata else 'conf.lmp',
        )
    with open(filename, 'w') as f:
        f.write(s)

    if lammpsdata:
        lammps.write_data(lammpsdata, atoms, order)



def check_for_diagonal_cell(atoms):
    """Raises an exception if atoms does not have an orthorombic cell."""
    cell = atoms.cell
    if (cell[0, 1] > 1e-5 or
        cell[0, 2] > 1e-5 or
        cell[1, 0] > 1e-5 or
        cell[1, 2] > 1e-5 or
        cell[2, 0] > 1e-5 or
        cell[2, 1] > 1e-5):
        raise TypeError('The cell must be diagonal')


def index2slice(index, default=None):
    """Return index as a slice.  Accepts int (ex. 0, -1), str (ex. ':',
    '-3:'), slice, or None.  If `index` is None, `default` is used.
    ``default=None`` is equivalent to ``slice(None`` (all).
    """
    if index is None:
        index = default
    if isinstance(index, str):
        index = ase.io.formats.string2index(index)

    if index is None:
        s = slice(None)
    elif isinstance(index, slice):
        s = index
    elif isinstance(index, int):
        s = slice(index, index + 1)
    else:
        raise TypeError('`index` must be int, str, slice or None')
    return s

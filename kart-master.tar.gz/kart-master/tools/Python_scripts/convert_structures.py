#!/usr/bin/env python
# -*- coding: utf-8 -*-   

# Copyright (c) Norwegian University of Science and Technology (NTNU) 2017
# By Simen Nut Hansen Eliassen


from __future__ import print_function                                                                                             
from __future__ import division

import sys
import os
import numpy as np
import ase
import kart
from ase.visualize import view
import lammps 
import argparse                                                                                                                                              
#from write_lmp_data_QUICK_FIX import write_lammps

### Parse arguments
parser = argparse.ArgumentParser(description='Convert structure files between k-ART and LAMMPS simulations. Edit variable atom_types if needed, or provide it when prompted. \n \ Choose -inconf or inlmp to read input structure from kART or LAMMPS. -outconf and -outlmp can be set to specify filename of output files. !!NB!! Does not support to read triclinic box from *.conf. Also it cannot write triclinic box to *lmp !!NB!! ')

parser.add_argument("-i", "--infile_structure", action='store', required=True,
                    help="Input structure from k-ART or LAMMPS. Supported extensions: .conf, .lmp, .data")
parser.add_argument("-outconf", "--outfile_kart_structure", action='store', default='initial.conf',
                    help="Output structure for k-ART (*.conf). Default: initial.conf (OPTIONAL)")
parser.add_argument("-outlmp", "--outfile_lammps_structure", action='store', default='initial.lmp',
                    help="Output structure for LAMMPS (*.lmp, *.data) Default: initial.lmp (OPTIONAL)")
parser.add_argument("-tric", "--triclinic", action='store_true',
                    help="If box is triclinic. Default: Orthorhombic box")

if len(sys.argv)==1:
    parser.print_help()
    sys.exit(1)
args=parser.parse_args()

### Variables
user_atom_types= input('\n Please enter the atomic symbols as a string list \
                        \n (be sure to provide an list length equal to the \
                        \n number of species if .data or .lmp is given as input):')

if (user_atom_types == " "):
    print("Set default atomic type, Si Si Si")
    atom_types =['Si', 'Si', 'Si']
else:
    atom_types = user_atom_types
    print(len(atom_types))

## Determine atomic style:
user_atom_style= input('\n Please enter the atomic style from lammps configuration file \
                        \n (default value is "atomic" for now only atomic and charge are available):')

if (user_atom_style == " "):
    print("Set default atomic style, atomic")
    atom_style ="atomic"
else:
    atom_style = user_atom_style

## Read structure
lammps_extension = ['.data','.lmp']

for extension in lammps_extension:
    if args.infile_structure.endswith(extension):
        f = lammps.read_data(args.infile_structure, atom_types=atom_types,atom_style=atom_style)
        at = f[0]
        if (len(atom_types) == 1):
            print("Hey atomic symbols is 1")
            atno = f[1]
        elif (len(atom_types) >= 2):
            print("Hey atomic symbols is more than 1")
            atno = f[1][len(atom_types):]

if args.infile_structure.endswith('.conf'):
    if (args.triclinic):
        f = kart.read_initial(args.infile_structure, atom_types=atom_types, triclinic=True)
    else:
        f = kart.read_initial(args.infile_structure, atom_types=atom_types, triclinic=True)
    at = f[0]
    if (len(atom_types) == 1):
        print("Hey atomic symbols is 1")
        atno = f[1]
    elif (len(atom_types) >= 2):
        print("Hey atomic symbols is more than 1")
        atno = f[1]
        

print('Length of atomic number:',len(atno))
print('Number of different atomic numbers:', len(np.unique(atno)))


### Write structure
write_structure = input('\n Write k-ART structure or lammps structure or both. \
                         \n Type 1 for kART, type 2 for LAMMPS or type 3 for both:')

if (args.triclinic):
    if write_structure == 1:
        print('Creating structure file for kART:', args.outfile_kart_structure)
        kart.write_conf(at, atno, args.outfile_kart_structure, triclinic=True)
    elif write_structure == 2:
        print('Creating structure file for LAMMPS:', args.outfile_lammps_structure)
        lammps.write_data(args.outfile_lammps_structure, at, atomic_numbers=atno)
    elif write_structure == 3:
        print('Creating structure file for kART:', args.outfile_kart_structure)
        kart.write_conf(at, atno, args.outfile_kart_structure, triclinic=True)
        print('Creating structure file for LAMMPS:', args.outfile_lammps_structure)
        lammps.write_data(args.outfile_lammps_structure, at, atomic_numbers=atno)
else:
    if write_structure == 1:
        print('Creating structure file for kART:', args.outfile_kart_structure)
        kart.write_conf(at, atno, args.outfile_kart_structure, triclinic=False)
    elif write_structure == 2:
        print('Creating structure file for LAMMPS:', args.outfile_lammps_structure)
        lammps.write_data(args.outfile_lammps_structure, at, atomic_numbers=atno)
    elif write_structure == 3:
        print('Creating structure file for kART:', args.outfile_kart_structure)
        kart.write_conf(at, atno, args.outfile_kart_structure, triclinic=False)
        print('Creating structure file for LAMMPS:', args.outfile_lammps_structure)
        lammps.write_data(args.outfile_lammps_structure, at, atomic_numbers=atno)


# coding: utf-8
from __future__ import absolute_import,print_function

# Python program to create a csv pivot table with                                        #
# the column are all the different Init Topo visited,                                    #  
# the raw are all the different Fin Topo visited,                                        # 
# the subraw are the different Sad Topo,                                                 # 
# and the data print in the pivot                                                        #
# table are the energy barrier with respect to Init,Fin                                  #
# and Sad Topo.                                                                          #
# More the second row is representing the energy associated                              #
# to the Init Topo and the second column is representing the                             #
# associated to the Fin Topo. The energies are in eV and                                 #
# represents the binding energy by default.                                              #
# the pivot table is easily readable by Excel and Numbers"                               #
#
# How to use it:                                                                         #
# First one need to have the Energies.dat file in the current working directory.         #
# and then type : python(2 or 3) tableautransTrue.py 
# Script tested in Mac and Linux OSs, with python versions 2.7 and 3.5                   #
# Written By: Mickael Trochet, In fall 2016                                              #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------#

#----------------------- IMPUT PARAMETERS FOR PLOTTING k-ART DATA -----------------------#
CluterMachine='briaree'     # Cluster connect to.
SCRACSH='/RQexec/trochetm/' # Main dir in the remote machine to look for the files.dat.SCRACSH='/RQexec/trochetm/March2016/localforce/' # Main dir in the remote machine to look for the files.dat.
DIRHOME='./'             # Main dir at Home where subdirectories with simulations are stored.
SRC_SCRIPT = '~/Documents/python_exe/' 

from builtins import input
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
# import packages needed
def instruction():
   print("*************************************************************")
   print("This python script generates a csv pivot table with          ")
   print("the column are all the different Init Topo visited,          ")
   print("the raw are all the Fin Topo visited,                        ")
   print("the subraw are the Sad Topo, and the data print in the pivot ")
   print("table are the energy barrier with respect to Init,Fin        ") 
   print("and Sad Topo.                                                ")
   print("More the second row is representing the energy associated    ")
   print("to the Init Topo and the second column is representing the energy")
   print("associated to the Fin Topo. The energies are in eV and       ")
   print("represents the binding energy by default.                    ")
   print("the pivot table is easily readable by Excel and Numbers      ")
   print("")
   print("To run this script one will need to have in                  ")
   print("the working directory the following files:                   ")
   print("- the Energies.dat file produce by kART code                 ")
   print("Then the following command will execute the script.          ")
   print("$ python "+sys.argv[0]+"                                     ")
   print("this command will guide you throughout the script and ask    ")
   print("you to input a series of information regarding you simulation")
   print("*************************************************************")
   sys.exit(1)
   return

if (len(sys.argv) == 1):
   print("For more help please type : python "+sys.argv[0]+" help")
elif (len(sys.argv) == 2):
   instruction()


# Set Path to file 
#PATH = "/Network/Servers/sirois.pmc.umontreal.ca/Users/mickael/Documents/Analyse/AnalyseLiSi/August2016/SiLi3/run2"
# load file with numpy loadtxt
#data = np.loadtxt(PATH+"/Energies.dat")
data = np.loadtxt("Energies.dat")
# set a list with name of columns in Energies.dat
strcolumn = ["KMC steps","CPU time", "Old energy","New energy","barrier","Total rate","time step","Sim time","Selec Ev","Init Topo","Sad Topo","Fin Topo"]
# Creating the DataFrame with Pandas without the KMCsteps 0.
df= pd.DataFrame(data[1:,:],columns=strcolumn)


# The next part is an addition to calculate the binding or the formation energy of your system.
# cohesive Energy of diamond silicon and bcc lithium are already calculated
# thanks to kART simulation with a REAXFF potential for Li and Si atoms. 
###############################################################################################
kB_eV = 8.6173303*10**(-5)

convert_eV_to_kcalPerMol = 23.060541945410456
conv = convert_eV_to_kcalPerMol


def cohesiveEnergy(Esim,N1,kcal_moltoEv):
      if (kcal_moltoEv == True):
          ecoh = Esim/(N1*conv)
      else:
          ecoh = Esim/N1
      return ecoh  

def FormationEnergy(Esim,Nsim,Ecoh):
        E = (Esim - Nsim*Ecoh)
        return E
        
def BindingEnergy(Esim,Nsim1,Nsim2,Ecoh1,Ecoh2):
        E = (Esim - Nsim1*Ecoh1-Nsim2*Ecoh2)
        return E


############   Si ##########
#For a temperature of 301.18 K 
NSi = 4096.0
ESiK =  -19481.3105 # Energy of the perfect c-Si calculated with kART in eV
SicohEkART= cohesiveEnergy(ESiK,NSi,False) 
############   Li ###########
#For a temperature of 301.74 K 
NLi = 1024.0
ELiK =  -1672.6327 # Energy of the perfect c-Li calculated with kART in eV
LicohEkART= cohesiveEnergy(ELiK,NLi,False) 
###################### BINDING ENERGY AS REFERENCE ###############################
# default system is 1 Li atoms in a 4096 c-Si atoms crystal.
E = df[["New energy","Old energy"]].min().min() # minimum of each column and between the min of the two.
print(E)
print("By default this script treats Li interstitial in c-Si: ")

NSi  = input("Please enter the number of atom type 1 (default c-Si 4096):")
if (NSi == ""):
    NSi =4096

NLi  = input("Please enter the number of atom type 2 (default Li interstitial 1):")
if (NLi == ""):
    NLi = 1

N = NSi+NLi

#ref = BindingEnergy(df["Old energy"],N-NLi,NLi,SicohEkART,LicohEkART) 

#print(SicohEkART,LicohEkART)

# If you want to choose a new energy reference, you can do it like this : 
#ref = 19500 # eV 
#df["Old energy"] = df["Old energy"] + ref
#df["New energy"] = df["New energy"] + ref
# HERE WE USED THE BINDING ENERGY AS A REFERENCE
df["Old energy"] = BindingEnergy(df["Old energy"],N-NLi,NLi,SicohEkART,LicohEkART)
df["New energy"] = BindingEnergy(df["New energy"],N-NLi,NLi,SicohEkART,LicohEkART)
#
# the reference can be for example: 
# the minimum energy visited during the simulation 
# Or 
# the formation energy or the binding energy. 

# Creating a preliminary Data Frame with average Old energy over the same Init Topo 
df2_avg = pd.pivot_table(df,values=["Old energy"],columns=["Init Topo"]) # aggfunc = np.mean by default
df2_std = pd.pivot_table(df,values=["Old energy"],columns=["Init Topo"],aggfunc=np.std)

# Creating a preliminary Data Frame with average New energy over the same Final Topo 
df3_avg = pd.pivot_table(df,values=["New energy"],columns=["Fin Topo"]) # aggfunc = np.mean by default
df3_std = pd.pivot_table(df,values=["New energy"],columns=["Fin Topo"],aggfunc=np.std)

# Creating new columns named "ave Old energy"
for index, row in df.iterrows(): # loop over the data frame from Energies.dat
    for i in range(np.size(df2_avg.keys())):
        if (row["Init Topo"] == df2_avg.keys()[i]): # if Init Topo values is equal to the Init topo in the pivot table then
            df.loc[index,("ave Old energy")] = df2_avg.get_values()[0,i]
# Creating new columns named "ave New energy"
for index, row in df.iterrows(): # loop over the data frame from Energies.dat
    for i in range(np.size(df3_avg.keys())):
        if (row["Fin Topo"] == df3_avg.keys()[i]): # if Init Topo values is equal to the Init topo in the pivot table then
            df.loc[index,("ave New energy")] = df3_avg.get_values()[0,i]
# Creating THE pivot table with energy barrier values.

table = pd.pivot_table(df,values=["barrier"], index=["Fin Topo","ave New energy","Sad Topo"], columns=["Init Topo","ave Old energy"],aggfunc=np.mean)
# user may notice that aggfunc = np.mean is the default aggfunc
# Save the table into a csv readable (at least by Microsoft Excel)
#table.to_csv(PATH+"/table_selecEv.csv", sep=';', encoding='utf-8')
#table.to_csv(PATH+"/table_selecEvmac.csv", sep='.', encoding='utf-8')
table.to_csv("table_selecEv.csv", sep=';', encoding='utf-8')
table.to_csv("table_selecEv.txt", sep=';', encoding='utf-8')
#table.to_csv("/table_selecEvmac.csv", sep='.', encoding='utf-8')

table

###


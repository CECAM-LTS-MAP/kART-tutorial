
# Python program to plot the selected event and available events at each KMCsteps        # 
# form k-ART program.                                                                    #
#                                                                                        #
# How to use it:                                                                         #
# First one need to have the selec_ev.dat file and the folder EVLIST_DIR with all        #
# event_list_conf_* files.
# 
# Script tested in Mac and Linux OSs, with python versions 2.7 and 3.4                   #
# Written By: Mickael Trochet                                                            #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------# #

#----------------------- IMPUT PARAMETERS FOR PLOTTING k-ART DATA -----------------------#
CluterMachine='briaree'     # Cluster connect to.
#CluterMachine='trochetm@briaree.calculquebec.ca' # Cluster connect to.
#SCRACSH='/RQexec/restrepo/FeC/600K/alphaFe1C' # Main dir in the remote machine to look for the files.dat.
SCRACSH='/RQexec/trochetm/March2016/localforce/' # Main dir in the remote machine to look for the files.dat.
DIRHOME=''              # Main dir at Home where subdirectories with simulations are stored.
SRC_SCRIPT = '~/mickael/Documents/python_exe/' 
import sys
import os
import numpy as np
import matplotlib
from cycler import cycler # needed for fig. 9 
try:# If you want Qt5 extra functionalities, you must install library PyQt5 (you can try PyQt4 by changing 5 to 4 below)
      import PyQt5
      matplotlib.use('Qt5Agg')
except Exception as e:
      print('If you want Qt5 extra functionalities install PyQt5. Default backend',matplotlib.get_backend())
import matplotlib.pyplot as plt
import matplotlib.pylab as lab

Plots_dir='Graphics2'        # Subdir where plots will be stored. (/ for linux-mac \for windows) 
fileFormat= 'pdf'           # Choose "png", "eps" or "pdf". Default is png. Supported formats: emf, eps, pdf, png, ps, raw, rgba, svg, 
Rasterized=True             # If a pdf is difficult to open or paste to ppt presentation because it has many points,  
newversion = "new"

#plt.ion()
#----------------- choose version function input acording to python version ------------#
def INPUT(x): 
       return ( raw_input(x) if(sys.version_info[0]==2) else input(x) )

def EVAL_INPUT(x):
       return ( input(x) if(sys.version_info[0]==2) else eval(input(x)))  



def instruction():
   print("***************************************************************")
   print("This python script generates a plot of                      ")
   print("energies barriers of available and selected                 ")
   print("transitions in function of KMCstep.                         ")
   print("To run this script one will need to have in                 ")
   print("the working directory the following files:                  ")
   print("- the selec_ev.dat file produce by kART code                ")
   print("- the EVLIST_DIR folder and event_list_conf_* files.        ")
   print("Then the following command will execute the script.         ")
   print("$ python plot_evlist3.py                                     ")
   print("this command will ask you an integer representing the       ")
   print("maximum number of KMCstep you want to use for the plot.     ")
   print("****************************************************************")
   print("Also there is a 'quick' argument that allow user to give this")
   print("maximum number of KMCstep directely in the command line as ")
   print("follow:")
   print("$ python plot_evlist3.py quick n")
   print("where n = max number of KMCstep desired, to use all available") 
   print("KMCsteps set n to 0 as follow: ")
   print("$ python plot_evlist3.py quick 0")
   sys.exit(1)
   return

if (len(sys.argv) == 1):
   print("For more help please type : python plot_evlist3.py help")
elif (len(sys.argv) == 2):
   instruction()
elif (len(sys.argv) == 3):       
   print("quick run user already set the value of KMCstep max")
###################################################################################################
colorscater = list(['b', 'r', 'g', 'y','c','violet','orange','m','brown','k'])
Atomtype = list(["Si","Li","C","Fe"])
sepTypeAtomID_default = list([0,512,576])
# Change the next parameters according to your needs (small or lagers caracters, size of box, etc).
params = {'figure.figsize'  : [10,7],
          'axes.labelsize'  : 26,
          'axes.titlesize'  : 26,
          'xtick.labelsize' : 22,
          'ytick.labelsize' : 22,
          'xtick.major.pad' : 8,
          'ytick.major.pad' : 8,
          'figure.subplot.left'  : 0.15,
          'figure.subplot.right' : 0.88,
          'figure.subplot.bottom': 0.14,
          #'figure.subplot.top'  : 0.89,  
          'legend.numpoints': 1,
          'legend.fancybox': True,
          'legend.framealpha': 0.1,
          'legend.scatterpoints': 1,
          'axes.linewidth': 1.5,
          'lines.markersize': 10,
          'lines.markeredgewidth': 1.0,
          # Choose pallete color for histograms in fig 9, here 10 different colors (you can add more or change order):
          'axes.prop_cycle' : ( cycler('color', ['b', 'r', 'g', 'y','c','violet','orange','m','brown','k']) ),
          #'lines.linewidth': 2,
          'font.family' : 'sans-serif',
          'font.serif' : 'Arial',
          'savefig.transparent'  : True
          } 


#  Reading the paraterers declare above
plt.rcParams.update(params)
plt.rcParams['savefig.transparent'] = True
# ------------------------- COPY OR REFRESH DATA FROM CLUSTER --------------------------#

cpyFrom = INPUT('\n   *** To "EXIT" at any step press (e) ***\n\nCopy data from '+CluterMachine+'? if yes press (y), if not (enter): ') # only python 2.x, for python 3.x use imput()
if (cpyFrom=='e'): exit(1)
if (cpyFrom == 'y'):
    print("Adress in local machine:")
    os.system('echo "  ==>" $(pwd) ')
    #AdressInRemoteMachine = os.getcwd().replace(os.getenv("HOME")+"/"+DIRHOME, "") # Get actual dir I am but remove $HOME/KMC
    AdressInRemoteMachine = '' 
    CheckAdress = INPUT('\nTarget adress in the remote machine:\n  ==> '+ SCRACSH + AdressInRemoteMachine +
         ' <==.\n\nIf this is incorrect, put the right adress of the dir in remote machine. Else press enter:\n  ==> '
         + SCRACSH)
    if (CheckAdress != ''): AdressInRemoteMachine = CheckAdress
    
    # Import *.dat files from cluster

    os.system("rsync -avrzP "+CluterMachine+":"+ SCRACSH + AdressInRemoteMachine +"/*.dat .")
    # Import event_list_conf_XX.dat
    os.system("rsync --exclude='Mine' -avrzP "+CluterMachine+":"+ SCRACSH + AdressInRemoteMachine +"/EVLIST_DIR .")



#------------------------------- SAVE PLOTS TO A DIRECTORY -----------------------------# 
yes='y'
if (not os.path.exists(Plots_dir)): # check if dir exit, if not create it.
   yes = INPUT('\nTo save the plots in "'+Plots_dir+'" press (y), or only view them (enter): ') 
   if (yes=='e'): exit(1)
   if (yes=='y'): os.makedirs(Plots_dir)
else:
   yes = INPUT('\nWARNING: dir "'+Plots_dir+'" does exist.\nTo save the plots in "'+Plots_dir+'" press (y), or only view them (enter):') 
   if (yes=='e'): exit(1)
   




##########################################################################################################################################################
# Reading Selec_ev.dat file
# column 0      # 1        # 2      # 3        # 4           # 5          # 6        # 7        # 8           # 9 
# CPU time  selcBarrier    KMC    EVENT    SPEC_EVENT    SELEC_ATOM    timestep    SimulT    Basin-ID    Basin-thresh 
print("")
print("Reading Selec_ev.dat file")
print("")

print("# column 0      # 1        # 2      # 3        # 4           # 5          # 6        # 7        # 8           # 9 ")
print("# CPU time  selcBarrier    KMC    EVENT    SPEC_EVENT    SELEC_ATOM    timestep    SimulT    Basin-ID    Basin-thresh ")
print("")
Select=np.loadtxt('selec_ev.dat')

print("Selec_ev.dat file read")
print("Variable Select is set with data in file Selec_ev.dat")
print("")
##########################################################################################################################################################

# For large amount of KMCstep and/or large amount of available events, one can plot only up to a certain amount of KMCsteps.
    
 
if (len(sys.argv) == 1):
   numberofstep=INPUT('Please enter the number of KMCstep you want to read (default value all steps,'+str(int(Select[:,2].max()))+' ):')
   if (numberofstep != ''):
      nconf=int(numberofstep)
   else:
      nconf=int(Select[:,2].max()-1)
elif (len(sys.argv) == 3):   
   if (sys.argv[-1]=='0'):
      nconf=int(Select[:,2].max()-1)
   else:   
      nconf=int(sys.argv[-1])
print("")
print("Number of KMCstep analyse is :",nconf)   
interval = 10
Nlocator = int(nconf/interval)  
##########################################################################################################################################################
print("")
print("Reading event_list_conf files")
print("")
print("# column 0      # 1        # 2      # 3        # 4       # 5          # 6        # 7         # 8        # 9     #10        #11 ")
print("# TypeAtom     AtomId    Init Topo Sad Topo   Fin Topo  eventId     Spec_id     barrier   inv_bar    asy_ener   inisad_dr   inifin_dr ")
print("")
AvailBarrierPerStep = list()
DATA = list()



def read_event_list_conf(oldornew):
    tmp_data= list()
    if (oldornew == "old"):
        init = 0
        final = nconf
    elif (oldornew == "new"):
        init = 1
        final =nconf+1
            
    for i in range(init,final):

           Evlistconf = np.loadtxt('EVLIST_DIR/event_list_conf_'+str(i),usecols=range(12))
           if (np.shape(Evlistconf)==(12,)):  # this means that there is only one event and Evlistconf is a vector not a matrice
               AvailBarrierPerStep.append(1)
               tmp_data.append([i]+list(Evlistconf))
           else:
              AvailBarrierPerStep.append(np.size(Evlistconf[:,5]))
              for j in range(np.size(Evlistconf[:,5])):
                   tmp_data.append([i]+list(Evlistconf[j,:]))
           if (i % 10 == 0):
                print(str(i)+'event_list_conf files read')    
    return tmp_data    

#try:
DATA=read_event_list_conf(newversion)
#except:
#    pass
#try:
#DATA=read_event_list_conf('new')
#except:
#   pass


    
Array_data = np.asarray(DATA)

print("event_list_conf files read")
print("Variable DATA is set with data in files event_list_conf ")
print("but with an extra column (on the left) representing the KMCstep")

# to filter the Atom type from Array data
# this is a list containing as many element as the number of atom type. 

if (np.shape(Array_data)[1] == 12 ):
   print("Default value for separation atom type is :", sepTypeAtomID_default)    
   if (str(sys.argv[-2]) != 'quick'):
      SepTypeAtomID =EVAL_INPUT("Please Type a list containing \n the atom number ID where the atom Type change. \n (i.e [0,402,natoms] for 2 atoms type or [0,402,506,natoms] for 3 atoms type):") 
      print("User input is :", SepTypeAtomID)
   else: 
      print("Default value used")
      SepTypeAtomID = sepTypeAtomID_default

   tmp =list()
   for x in Array_data:
       for enum,i in enumerate(SepTypeAtomID[:-1]):
           #print(enum,x[1])
           if (SepTypeAtomID[enum] < x[1] <= SepTypeAtomID[enum+1]):
              #print("In if " , enum+1)
              tmp.append(enum+1)
              break
   Array_data = np.c_[Array_data[:,0:1],tmp,Array_data[:,1:]]

print("# column 0      # 1        # 2      # 3        # 4       # 5          # 6        # 7        # 8        # 9         # 10   ")
print("# KMCstep     TypeAtom     AtomId     TopoId   eventId  Spec_id     barrier   inv_bar    asy_ener   inisad_dr   inifin_dr ")
print("")

moy             = np.mean(Select[1:nconf+1,1])


def movingaverage(interval, window_size):
    window= np.ones(int(window_size))/float(window_size)
    return np.convolve(interval, window, 'same')


#########   My_plotter def #################
# Arrays: Array_data, Select and AvailBarrierPerStep
# are required for this function.
 
def Avail_vs_select(data1x,data1y,data2x,data2y,data3):
    """
    Parameters
    ---------------
    
    data1x : Array
        The x column from array of data (Matrice) Array_data
    data1y : Array
        The y column from array of data (Matrice) Array_data
        
    data2x : Array
        The x column from array of data (Matrice ) Select
    data2y : Array
        The y column from array of data (Matrice ) Select
      
    data3 : Array
        The vector of data AvailBarrierPerStep
    """
    fig = plt.figure()
    fig.patch.set_alpha(0.0)
    ax1 = fig.add_subplot(111)
    ax1.patch.set_alpha(0.0)
    plt.xlabel("KMCsteps")
    plt.ylabel("Barrier (eV)")

    # set secondary x axis 
    ax2 = ax1.twinx()
    plt.ylabel("# of events")
    ax2.patch.set_alpha(0.0)
    
    ax2.yaxis.label.set_color('blue')
    ax2.spines["right"].set_edgecolor('blue')
    ax2.tick_params(axis='y', colors='blue')

    #ax2.set_xticks(data2x[::Nlocator])
    #ax2.set_xticks(data2x)

    #ax2.set_xticklabels(map(str,data3[::Nlocator]),rotation =60,color ="blue")
    #ax2.set_xticklabels(map(str,data3),rotation =60,color ="blue")
    


    ax1.set_xlim(xmin = 0 ,xmax=nconf-1)
    ax2.set_xlim(xmin = 0 ,xmax=nconf-1)
    ax2.set_ylim(ymin = 0 ,ymax=2*np.max(data3))


    # plot for density of point x axis 
    ax2.plot(data2x,data3, "b.",label="Number of events",alpha=0.5 , rasterized=True)
    #data3_av = movingaverage(data3,10)
    #ax2.plot(data2x,data3_av, "k",alpha=0.5 , rasterized=True)
    # Plot real data.
    ax1.plot(data1x,data1y, "go",label="Available Barrier", alpha=0.5, rasterized=True)
    #ax1.plot(data2x,data2y,"rx",label="Selected Barrier, mean value : %6.2g  eV" %moy,rasterized = True)
    ax1.plot(data2x,data2y,"r.",label="Selected Barrier " %moy,rasterized = True)


    plt.xlim(xmax=nconf+1)
    ax1.set_ylim(ymin=0,ymax=max(data1y)+1.0)

    ax2.set_zorder(-1)
    h1,l1 = ax1.get_legend_handles_labels()
    h2,l2 = ax2.get_legend_handles_labels()
    l= ax1.legend(h1+h2,l1+l2,loc="best")
    l.draggable(True)
    fig.tight_layout()    
    if (yes == 'y'):
       lab.savefig(Plots_dir+'/AvailVsSelect.'+fileFormat, format=fileFormat) #, transparent=True)
    return fig      
 
def Avail_AtomFiltration(data1,data2,data3):
	#    """
	#	Parameters
	#	---------------
    #
	#	data1 : Array
    #    The array of data (Matrice) Array_data
	#	
	#	data2x : Array
    #    The array of data (Matrice ) Select
    #  
	#	data3 : Array
    #    The vector of data AvailBarrierPerStep

	#	"""
        fig = plt.figure()
        fig.patch.set_alpha(0.0)
        ax1 = fig.add_subplot(111)
        ax1.patch.set_alpha(0.0)
        plt.xlabel("KMCsteps")
        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylabel("Barrier (eV)")

        listsetAtomtype = list(set(map(int,data1[:,1])))
        for enum,i in enumerate(listsetAtomtype):
            filter_array = np.asarray(list(filter(lambda x: x[1] == i, data1)))
            plt.scatter(filter_array[:,0],filter_array[:,6],c=colorscater[enum],s= 10*10,alpha = 0, rasterized = True)

        ax2 = ax1.twiny()
        ax2.patch.set_alpha(0.0)
        ax2.set_xticks(data2[0:nconf:Nlocator,2])
        ax2.set_xticklabels(map(str,data3[::Nlocator]),rotation =60,color ="blue")
        ax2.set_xlim(xmax=nconf-1)

        for enum,i in enumerate(listsetAtomtype):
            filter_array = np.asarray(list(filter(lambda x: x[1] == i, data1)))
            plt.scatter(filter_array[:,0],filter_array[:,6],c=colorscater[enum],s= 10*10,alpha = 1, rasterized = True,label="Available Barrier center on %3s" %Atomtype[enum])
            print("atom type", i, " number of atom type", enum)
     
        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylim(ymin=0,ymax=max(data1[:,6])+0.5)
        plt.tight_layout()             
        l = plt.legend(loc='best')
        l.draggable(True)
        return fig      


def Avail_with_thirdAxes(data1,data2,data3,labeldata3):
        fig= plt.figure()
        fig.patch.set_alpha(0.0)
        ax1 = fig.add_subplot(111)
        ax1.patch.set_alpha(0.0)
        
        plt.xlabel("KMCsteps")

        sca=plt.scatter(data1,data2,c=data3,s=10*10,alpha= 1)
        cbar = fig.colorbar(sca)
        cbar.set_label(labeldata3)
        plt.ylabel("Barrier (eV)")

        plt.xlim(xmin=0,xmax=nconf-1)
        plt.ylim(ymin=0,ymax=max(data2)+0.5)
    
        plt.tight_layout()      
        return fig






print("Beggin to plot figure 1 : available barrier and selected barrier vs KMCstep")
print("")

if (newversion == "new"):
   fig1 = Avail_vs_select(Array_data[:,0],Array_data[:,8],Select[1:nconf+1,2],Select[1:nconf+1,1],AvailBarrierPerStep)
else:
   fig1 = Avail_vs_select(Array_data[:,0],Array_data[:,8],Select[0:nconf,2],Select[1:nconf+1,1],AvailBarrierPerStep)

if (yes == 'y'):
   lab.savefig(Plots_dir+'/AvailVsSelect.'+fileFormat, format=fileFormat) #, transparent=True)
  
     
#print("Beggin to plot figure 2 : available barrier vs KMCstep color for center on atom type")
#print("")
#fig2  = Avail_AtomFiltration(Array_data,Select,AvailBarrierPerStep)
#
#if (yes == 'y'):
#   lab.savefig(Plots_dir+'/Avail_AtomFiltration.'+fileFormat, format=fileFormat) #, transparent=True)
#
#   
print("Beggin to plot figure 3 : available barrier vs KMCstep, colorbar Inverse barrier in Energy")
print("")
#
fig3 = Avail_with_thirdAxes(Array_data[:,0],Array_data[:,8],Array_data[:,9],'Inverse Barrier in (eV)')
if (yes == 'y'):
   lab.savefig(Plots_dir+'/AvailWithInvB.'+fileFormat, format=fileFormat) #, transparent=True)
#
#
print("Beggin to plot figure 4 : available barrier vs KMCstep, colorbar asymetry in Energy")
print("")
#
fig4 = Avail_with_thirdAxes(Array_data[:,0],Array_data[:,8],Array_data[:,10],'Asymetry in Energy in (eV)')
if (yes == 'y'):
   lab.savefig(Plots_dir+'/AvailWithAsym.'+fileFormat, format=fileFormat) #, transparent=True)
#
plt.show()
#
#
## If we need to save new plots modified in the opened windows, saving them using this form keeps background transparent,
## if for you is not important, just use the bottom of the windows.
#v = 0
#while True:
#   plotGraph = input('\n  ==> If you want to to save new versions of figures (1-4) type their numbers, else enter:')
#   if (plotGraph.count('e')): exit(1)
#                                                                                                                                                     
#   v = v + 1
#   if (plotGraph.count('1')):
#     
#     fig1.savefig(Plots_dir+'/AvailVsSelect_v'+str(v)+'.'+fileFormat, format=fileFormat)
#   if (plotGraph.count('2')):
#     
#     fig2.savefig(Plots_dir+'/Avail_AtomFiltration_v'+str(v)+'.'+fileFormat, format=fileFormat)
#   if (plotGraph.count('3')):
#     fig3.savefig(Plots_dir+'/AvailWithInvB_v'+str(v)+'.'+fileFormat, format=fileFormat)
#
#   if (plotGraph.count('4')): 
#     fig4.savefig(Plots_dir+'/AvailWithAsym_v'+str(v)+'.'+fileFormat, format=fileFormat)
#   if (plotGraph==''): break
#
#
#
#input("\n       **** \"Press enter to finish.\"  ****     ") 

# coding: utf-8
from __future__ import absolute_import ,print_function
from builtins import input
# Python program to create a csv pivot table where                                       #
# the column are all the different Init Topo in catalogue,                               #  
# the raw are all the different Selected Event in catalogue,                             # 
# and the data print in the pivot                                                        #
# table are the energy barrier in eV with respect to Init and Selected Event             #
# the pivot table is easily readable by Excel and Numbers"                               #
#
# How to use it:                                                                         #
# First one need to have the Selec_ev.dat file and EVLIST_DIR  							 # 
# in the current working directory.         											 #
# and then type : python(2 or 3) tableautransTrue.py 									 #
# Script tested in Mac and Linux OSs, with python versions 2.7 and 3.5                   #
# Written By: Mickael Trochet, In fall 2016                                              #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------#

#----------------------- IMPUT PARAMETERS FOR PLOTTING k-ART DATA -----------------------#
CluterMachine='briaree'     # Cluster connect to.
SCRACSH='/RQexec/trochetm/' # Main dir in the remote machine to look for the files.dat.
#SCRACSH='/RQexec/trochetm/March2016/localforce/' # Main dir in the remote machine to look for the files.dat.
DIRHOME='./'             # Main dir at Home where subdirectories with simulations are stored.
#SRC_SCRIPT = '~/Documents/python_exe/' 



import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
# import packages needed

newversion = "new"
#PATH = "/Network/Servers/sirois.pmc.umontreal.ca/Users/mickael/Documents/Analyse/AnalyseLiSi/August2016/SiLi3/run2/"
PATH = "./"
strcolumns = ["KMC step"]+["TypeId","AtomId","Init Topo","Sad Topo","Fin Topo","eventId","Spec_id","barrier","inv_bar","asy_ener","inisad_dr","inifin_dr"]
#print(strcolumns)


def instruction():
   print("*************************************************************")
   print("This python script generates a csv pivot table where         ")
   print("the column are all the different Init Topo in catalogue,     ")
   print("the raw are all the Selected Event in catalogue,             ")
   print("the data print in the pivot ")
   print("table are the energy barrier with respect to Init Topo,      ") 
   print("Fin Topo and Sad Topo.                                       ")
   print("The energies are in eV.									   ")
   print("the pivot table is easily readable by Excel and Numbers      ")
   print("")
   print("To run this script one will need to have in                  ")
   print("the working directory the following files:                   ")
   print("- the selec_ev.dat file produce by kART code                 ")
   print("- EVLIST_DIR directory produce by kART code                  ")
   print("Then the following command will execute the script.          ")
   print("$ python "+sys.argv[0]+"                                     ")
   print("this command will guide you throughout the script and ask    ")
   print("you to input a series of information regarding you simulation")
   print("*************************************************************")
   sys.exit(1)
   return

if (len(sys.argv) == 1):
   print("For more help please type : python "+sys.argv[0]+" help")
elif (len(sys.argv) == 2):
   instruction()


























# Reading Selec_ev.dat file
# column 0      # 1        # 2      # 3        # 4           # 5          # 6        # 7        # 8           # 9 
# CPU time  selcBarrier    KMC    EVENT    SPEC_EVENT    SELEC_ATOM    timestep    SimulT    Basin-ID    Basin-thresh 
print("")
print("Reading Selec_ev.dat file")
print("")

print("# column 0      # 1        # 2      # 3        # 4           # 5          # 6        # 7        # 8           # 9 ")
print("# CPU time  selcBarrier    KMC    EVENT    SPEC_EVENT    SELEC_ATOM    timestep    SimulT    Basin-ID    Basin-thresh ")
print("")
Select=np.loadtxt(PATH+'selec_ev.dat')

print("Selec_ev.dat file read")
print("Variable Select is set with data in file Selec_ev.dat")
print("")
##########################################################################################################################################################

# For large amount of KMCstep and/or large amount of available events, one can plot only up to a certain amount of KMCsteps.
     
if (len(sys.argv) == 1):
    numberofstep=input('Please enter the number of KMCstep you want to read (default value all steps,'+str(int(Select[:,2].max()))+' ):')
    if (numberofstep != ''):
        nconf=int(numberofstep)
    else:
        nconf=int(Select[:,2].max()-1)
#elif (len(sys.argv) == 3):   
#    if (sys.argv[-1]=='0'):
#		nconf=int(Select[:,2].max()-1)
#    else:   
#        nconf=int(sys.argv[-1])

print("")
print("Number of KMCstep analyse is :",nconf)   
##############################################################################
DATA = list()
def read_event_list_conf(oldornew):
    AvailBarrierPerStep = list()
    tmp_data= list()
	# this if statement is to compile with both version of kART
	# before and after the change of the event_conf_list.
	# old means from 0 to nconf exclude 
	# and ith step is associated to the ith to (i+1)th transition
	# where the new is from 1 to nconf inculde
	# and the ith step is associated to the (i-1)th to ith transition	
    if (oldornew == "old"):
        init = 0
        final = nconf
    elif (oldornew == "new"):
        init = 1
        final =nconf+1
    # MAIN LOOP TO LOAD FILES ONE BY ONE.        
    for i in range(init,final):
            Evlistconf = np.loadtxt(PATH+'EVLIST_DIR/event_list_conf_'+str(i),usecols=range(12))
			# this if statement means that there is only one event and Evlistconf is a vector not a matrice
            if (np.shape(Evlistconf)==(12,)):  
                AvailBarrierPerStep.append(1)
			# BECAREFUL WE ADD A COLUMN WITH THE KMCSTEP AT THE BEGINNING OF THE VARIABLE
                tmp_data.append([i]+list(Evlistconf))
            else:
				# WE NEED TO KNOW HOW MANY LINE (transitions) WE NEED TO READ.
                AvailBarrierPerStep.append(np.size(Evlistconf[:,5]))
                for j in range(np.size(Evlistconf[:,5])):
					# BECAREFUL WE ADD A COLUMN WITH THE KMCSTEP AT THE BEGINNING OF THE VARIABLE
                    tmp_data.append([i]+list(Evlistconf[j,:]))
            if (i % 10 == 0):
                print(str(i)+'event_list_conf files read')    
    return tmp_data    

##############################################################################

# load data from all event_list_conf files  with numpy loadtxt
# by using the function read_event_list_conf
DATA=read_event_list_conf(newversion)
# we now create a data frame from the variable DATA and use the variable strcolumns to assign names to columns. 
df = pd.DataFrame(DATA,columns=strcolumns)

# We create the pivot table 
table = pd.pivot_table(df,values=["barrier"], index=["Fin Topo","Sad Topo"],columns=["Init Topo"],aggfunc=np.mean)

# We save the table into a csv file.
table.to_csv(PATH+"/table_allEv.csv", sep=';', encoding='utf-8')
table.to_csv(PATH+"/table_allEv.txt", sep=';', encoding='utf-8')


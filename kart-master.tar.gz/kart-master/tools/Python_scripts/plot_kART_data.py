# -*- coding: utf-8 -*-
#                                                                                        #
# Python program to plot the results form k-ART program, useful for example for checking #
# the evolution of a summited job as a function of time or KMCstep. It allows download   #
# or refresh data from the cluster. Data is saved in a subdirectory in any format wanted.#
# It is Recommended to have the same path structure in local and remote machines, also   #
# automatic login to the cluster.                                                        #
#                                                                                        #
# How to use it:                                                                         #
# Go the dir you want to dowload (or have) the files, and from a terminal run as:        #
#     $ python /Users/user/plot_kART_data.py                                             #
# or from ipython run as:                                                                #
#     In [1]:  run /Users/user/plot_kART_data.py                                         #
# where /Users/user/ is the dir where this script resides. Realize that after this step  #
# all variables corresponding to the plots done are set in ipython, thus, additional     #
# calculations can be done inside the terminal/interpreter. For physical interpretation  #
# of plots see:                                                                          #
#  Beland et al. Kinetic Activation Relaxation Technique. Phys. Rev. E 84 (2011) 046704  #
#                                                                                        #
# Script tested in Mac and Linux OSs, with python versions 2.7 and 3.4                   #
# Written By: Oscar A. Restrepo and Mickael Trochet                                      #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
# Science Program, Texas A&M at Qatar, Doha, Qatar).                                     #
#----------------------------------------------------------------------------------------# 


#------------------------------------- LIBRARIES USED -----------------------------------#
from __future__ import absolute_import, division, print_function, unicode_literals
from cycler import cycler # needed for fig. 9
import numpy as np
import matplotlib
try:             # If you want Qt5 extra functionalities, you must install library PyQt5. 
   import PyQt5  # If also you can try PyQt4 by changing 5 to 4
   matplotlib.use('Qt5Agg')
except Exception as e:
   print('If you want Qt5 extra functionalities install PyQt5. Default backend',matplotlib.get_backend())
    
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker # to have control of format axis
import matplotlib.pylab as lab
from matplotlib.ticker import FuncFormatter
import os
import sys
from six.moves import input  # to replace raw_input if python2.x
#from subprocess import Popen, PIPE
#----------------------------------------------------------------------------------------# 


#----------------------- IMPUT PARAMETERS FOR PLOTTING k-ART DATA -----------------------#
CluterMachine='briaree'     # Cluster connect to.
#CluterMachine='guillimin'     # Cluster connect to.
#CluterMachine='restrepo@briaree.calculquebec.ca' # Cluster connect to.
#SCRACSH='/RQexec/restrepo/FeC/600K/alphaFe1C' # Main dir in the remote machine to look for the files.dat.
SCRACSH='/RQexec/trochetm/March2016/localforce/' # Main dir in the remote machine to look for the files.dat.
#SCRACSH='/gs/scratch/restrepo/' # Main dir in the remote machine to look for the files.dat.
DIRHOME='KMC/'              # Main dir at Home where subdirectories with simulations are stored.
AtomNames="Si Li"            # Name of atoms/particles, the order must be the same as in Diffusion.dat file.
scaleTimeby='micro'         # Change the scale of time choice: "milli","micro" or "nano", default is "s" (seconds)).
scaleCPUTimeby = 'day'     # change the scale of the CPUtime choice: 'day', 'hour', 'minute', 's'
scaleAXIS='linear'          # log axis scales. Choose: xlog, ylog, xylog or linear
Plots_dir='Graphics'        # Subdir where plots will be stored. (/ for linux-mac \for windows)
fileFormat= 'pdf'           # Choose "png", "eps" or "pdf". Default is png. Supported formats: emf, eps, pdf, png, ps, raw, rgba, svg, svgz.
Rasterized=True             # If a pdf is difficult to open or paste to ppt presentation because it has many points, 
                            # set to True. Default is None meaning the full plot is vectorial. ACCEPTS: [True | False | None]
putTitle="yes"              # if "yes" put title over each plot
sizebinsminE      = 0.001    # Width of bars in top (initial energy) histogram (fig. 9) 10 meV
sizebinsBarrier   = 0.001    # Width of bars in medium (barrier energy) histogram (fig. 9) 10 meV
sizebinsEminF     = 0.001    # Width of bars in bottom (final energy) histogram (fig. 9) 10 meV
binsSpace         = 10      # To control the interval of xaxis for energies: (Emin - binsSpace*sizebinsminE,Emax + binsSpace*sizebinsminE), same for sizebinsBarrier and sizebinsEminF.
ShowNumbersInPlot2 = True   # In fig. 2 show numbers (barrier energies) in plot by clicking in the small box of lef-top corner.
# put input files name acording with KMC.sh, default names:
inputFiles=['Energies.dat', # 0
            'Diffusion.dat',# 1
            'selec_ev.dat', # 2
            'topo_stat.dat',# 3
            'output.dat',   # 4
            'KMC-log.dat'   # 5 iif 4 does not exist. 
           ]
# Change the next parameters according to your needs (small or lagers caracters, size of box, etc).
# for more parameters see: 
# http://matplotlib.org/users/customizing.html
params = {'figure.figsize'       : [10,7],
          'figure.subplot.left'  : 0.15,# control distance of left-axis to plot 
          'figure.subplot.right' : 0.88,# control distance of right-axis to plot 
          'figure.subplot.bottom': 0.14,# control distance of bottom-axis to plot  
          #'figure.subplot.top'  : 0.89,# control distance of top-axis to plot 

	  #'savefig.dpi'         : 100, # figure dots per inch (not for eps or pdf as those are vector format)
	  'savefig.transparent'  : True,# setting that controls whether figures are saved with a
                                        # transparent background by default
          'axes.labelsize'  : 26, 
          'axes.titlesize'  : 26,
          'axes.linewidth'  : 1.5,
          # Choose pallete color for histograms in fig 9, here 10 different colors (you can add more or change order):
          'axes.prop_cycle' : ( cycler('color', ['b', 'r', 'g', 'y','c','violet','orange','m','brown','k']) ),
          #'lines.linewidth': 2,

          'xtick.labelsize' : 22, 
          'ytick.labelsize' : 22,
          'xtick.major.pad' : 8,
          'ytick.major.pad' : 8,
          
          'legend.labelspacing': 0.1, # the vertical space between the legend entries in fraction of fontsize
          'legend.framealpha'  : 0.5,# transparency of the label box
          #'legend.fontsize'    : 22, # size of the legend when plot, you can chage olso using legend(prop={'size':22})
          #'legend.fancybox'    : True,
          #'legend.frameon'     : True,# put/remove frame of the label box
          'font.family' : 'sans-serif',
          'font.serif' : 'Arial'
          }
#---------------------------------------------------------------------------------------# 

plt.ion() # enables interactive mode (allowing intruducing command lines after ploting figure 9)

#----------------- choose version function input acording to python version ------------#
#def INPUT(x): 
#    return ( input=raw_input if(sys.version_info[0]==2) else input(x) )

# ------------------------- COPY OR REFRESH DATA FROM CLUSTER --------------------------#
cpyFrom = input('\n   *** To "EXIT" at any step press (e) ***\n\nCopy data from '+CluterMachine+'? if yes press (y), if not (enter): ')
if (cpyFrom=='e'): exit(1)
if (cpyFrom == 'y'):
    print("Adress in local machine:")
    os.system('echo "  ==>" $(pwd) ')
    AdressInRemoteMachine = os.getcwd().replace(os.getenv("HOME")+"/"+DIRHOME, "") # Get actual dir I am but remove $HOME/KMC
    CheckAdress = input('\nTarget adress in the remote machine:\n  ==> '+ SCRACSH + AdressInRemoteMachine +
			' <==.\n\nIf this is incorrect, put the right adress of the dir in remote machine. Else press enter:\n  ==> '
			+ SCRACSH)
    if (CheckAdress != ''): AdressInRemoteMachine = CheckAdress
    
    # Import *.dat files from cluster, escluding files event_list_conf_XX.dat
    os.system("rsync --exclude='event_*' -avrzP "+CluterMachine+":"+ SCRACSH + AdressInRemoteMachine +"/*.dat .")

# Print INFO file of simulation
if not os.path.isfile(inputFiles[4]): inputFiles[4] = inputFiles[5] # needed after Mickaël changed the name of file.
for line in open(inputFiles[4],'r'): 
    if 'TEMPERATURE' in line: Temp = line.split()[-1].split(".")[0] # last split is to remove decimal after "."
print ( "\nTEMPERATURE:", Temp+"K")

    
#---------------------------------------------------------------------------------------# 

#------------------------------- SAVE PLOTS TO A DIRECTORY -----------------------------# 
yes='y'
if not os.path.exists(Plots_dir): # check if dir exit, if not create it.
    yes = input('\nTo save the plots in "'+Plots_dir+'" press (y), or only view them (enter): ') 
    if (yes=='e'): exit(1)
    if (yes=='y'): os.makedirs(Plots_dir)
else:
   yes = input('\nWARNING: dir "'+Plots_dir+'" does exist.\nTo save the plots in "'+Plots_dir+'" press (y), or only view them (enter): ') 
   if (yes=='e'): exit(1)
   
#----------------------------------------------------------------------------------------# 

#----------- Choosing to plot X axis as a fuction of 'time' or 'KMCstep' ----------------#
ChoosingTimeOrKMC = input('\nTo plot as a function of "KMCstep" press (s), or as a function of "time" (enter): ')
if (ChoosingTimeOrKMC=='e'): exit(1)
XaxisName = 'KMCstep' if (ChoosingTimeOrKMC=='s') else 'time'

#----------- Choosing  units to plot X axis as a fuction of 'time' ----------------------#
timeUnits = input('\nChoose proper units for "time". Type: s, mili, micro, nano, (or enter for using default): ')
if (timeUnits=='e'): exit(1)
if (timeUnits != ''): scaleTimeby = timeUnits


#----------- Choosing  units to plot X axis as a fuction of 'time' ----------------------#
CPUtimeUnits = input('\nChoose proper units for "CPUtime". Type: day, hour, minute, s, (or enter for using default): ')
if (timeUnits=='e'): exit(1)
if (timeUnits != ''): scaleCPUTimeby = CPUtimeUnits

#----------- Choosing to plot using log or linear axis when X = 'time' is chosed --------#
scale_X= 'log' if((scaleAXIS=='xlog' or scaleAXIS =='xylog')and XaxisName=='time' ) else 'linear'
scale_Y= 'log' if((scaleAXIS=='ylog' or scaleAXIS =='xylog')and XaxisName=='time' ) else 'linear' 

#---------------------------- Name of Atom/particles ------------------------------------#
getAtomNames = input('\nType atom/particle names (default values enter):')
if (getAtomNames=='e'): exit(1)
if (getAtomNames != ''): AtomNames = getAtomNames

NameAtom = AtomNames.split()
  
#---------------------------- Choosing wich Graphics to plot ----------------------------# 
plotGraph = input('\nFrom next list choose with graphics to plot:\n'
                  '\n 0 for Time steps vs '+XaxisName+
                  '\n 1 for Squared displacement (Diffusion) vs '+XaxisName+
                  '\n 2 for Total Energy vs '+XaxisName+
                  '\n 3 for Act. energy (Selc. Barrier) vs '+XaxisName+
                  '\n 4 for Topologies searched (CumulTOPO) vs '+XaxisName+
                  '\n 5 for Topologies searched (CumulTOPO) and CPU-time vs '+XaxisName+
                  '\n 6 for Act. energy (Selc. Barrier) and squared displ. vs '+XaxisName+
                  '\n 7 for Energy and simulated time vs KMCstep'
                  '\n 8 for Palette Energies (Old New) and barriers'
                  '\n 9 for histograms of shifted energies to "Ground State (GS)", (i.e. E - Emin), barrier energies, and final energies'
                  '\n\nIntroduce the numbers of plots you want, then enter (or just press enter to plot all):')
if (plotGraph=='e'): exit(1)                      
                      

#---------------------------------------------------------------------------------------# 

# changing to proper time units:
scaleTime = 1e-3 if(scaleTimeby=='milli') else(1e-6 if(scaleTimeby=='micro') else(1e-9 if(scaleTimeby=='nano') else 1))
unitsScale='m' if(scaleTimeby=='milli') else('$\mu$' if(scaleTimeby=='micro') else('n' if(scaleTimeby=='nano') else''))
# changing to proper CPUtime units:
scaleCPUTime = 3600.*24. if(scaleCPUTimeby=='day') else(3600. if(scaleCPUTimeby=='hour') else(60. if(scaleCPUTimeby=='min') else 1))
unitsCPUScale='d' if(scaleCPUTimeby=='day') else('h' if(scaleCPUTimeby=='hour') else('min' if(scaleCPUTimeby=='minute') else's'))
print('scaleCPUTime = ',scaleCPUTime,'and unitsCPUScale=',unitsCPUScale)
# Auto scale for y axis (to evoid overlaping of label box over graphics)
def autoscale_Yaxis_Interval(fig,Yvalue):
  if (scale_Y != 'log'):  # autoscale only works for linear plots, so no used if plots are log scaled 
     yMin = Yvalue.min()
     yMax = Yvalue.max()
     addM = (yMax - yMin)*0.2
     # fig.set_ylim ( top = yMax + addM, emit=True, auto=True)
     fig.set_ylim (yMin - 0.5*addM, yMax + addM)

#------------------------------ CREATING PLOTS WITH MATPLOTLIB -------------------------# 
  
plt.rcParams.update(params)
###############  Read DATA ###################
#  KMCstep, CPU_time, Old_energy, New_energy, barrier, Total_rate, time_step, Simulated_time
#  (0)        (1)      (2)           (3)       (4)         (5)       (6)           (7)
Energies            = np.loadtxt(inputFiles[0])
KMCstep             = Energies[:,0]
CPU_time           	= Energies[:,1]
Old_energy         	= Energies[:,2]
New_energy       	= Energies[:,3]
Barrier             = Energies[:,4]
Total_rate          = Energies[:,5]
time_step           = Energies[:,6]
Simulated_time  	= Energies[:,7]


Emin           = min(Energies[:,2].min(), Energies[:,3].min()) #The lowest Energy value of the two arrays
Old_energynorm = Old_energy - Emin
New_energynorm = New_energy - Emin

OldNewAndBarrier    = Energies[:,2:5]
OldNewAndBarrier[:,0:2] = OldNewAndBarrier[:,0:2]-Emin

# Elapsed_Time, Total_displ, displ_types (Number of species dimension),KMC_step,Event_delr
#  (0)              (1)         (2 to Number of species+1),  Number of species+2, Number of species+3
Diffusion = np.loadtxt(inputFiles[1])
# Elapsed_Time .eqv. to Simulation_time
msd = Diffusion[:,1]
msdPerAtom = Diffusion[:,2:-2]
# KMC_step already assign
Event_dr = Diffusion[:,-1]

# CPU_time, selcBarrier, KMC, EVENT, SPEC_EVENT, SELEC_ATOM, timestep, SimulT, Basin_ID, Basin_thresh
#  (0)         (1)       (2)   (3)      (4)        (5)         (6)     (7)        (8)       (9)
Selec_ev = np.loadtxt(inputFiles[2])

# CPU_time, currTOPO, activeTOPO, newTOPO, searchedTOPO, CumulTOPO, diffTOPO, KMC, SimulT
#  (0)         (1)      (2)        (3)        (4)          (5)           (6)     (7)    (8)        
Topo_stat = np.loadtxt(inputFiles[3])
CumulTOPO = Topo_stat[:,5]


#################  PlotFunctions                         ################
# FIGURES 0,1, 2, 7,8 and 9 use Energies data from inputFiles[0]
# FIGURES 1 and 6 use Diffusion data from inputFiles[1]
# FIGURES 3 and 6 use Selec_ev data from inputFiles[2]
# FIGURES 4 and 5 use Topo_stat data from inputFiles[3]


def Xtimeorstep(arg):
        Xaxis = Simulated_time/scaleTime if (arg == 'time') else KMCstep
        Xlabel = 'time ('+unitsScale+'s)' if (arg =='time') else 'KMC step'
        return Xaxis,Xlabel


def myplotglobal(xdata,ydata,extra_ydata,xlabel,ylabel,label1,label2,title,stringsavelabel,plotnumber):  
      
    fig = plt.figure(plotnumber)
    fig.patch.set_alpha(0.0)
    ax1 = fig.add_subplot(111)
    ax1.patch.set_alpha(0.0)
        

##################   SPECIFIC TO FIG 0 ##################
    if (plotnumber == 0):
            plt.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
            plt.axhline(y=(ydata.mean()), label= label2, color='r',lw=1.5)
##################   SPECIFIC TO FIG 1 ##################
    elif (plotnumber == 1):
              plt.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
              for i in range(len(extra_ydata[0])):
                    plt.plot(xdata,extra_ydata[:,i],'--', label=label2[i], lw=1.5,rasterized=Rasterized)
              #   ***** Calculating Diffusion coefficient at given temperature. ****   #
             # Using Einstein relation D = <|r(t)-r0|^2>/6t, < .. > is the temporal average. 

              D = 0.0
              for i in range(len(ydata)):
                    D = D + ydata[i]*time_step[i]
              print("\n  ==> For Fig. (1), general Diffusion coeff is: D = %10.4e"%(D/Simulated_time.max()**2/6.*1.e-20),"m^2/s")
              # And now, calculating diffusion according to particle types:
              for j in range(len(extra_ydata[0])):
                  D = 0.0
                  for i in range(len(ydata)):
                        D = D + extra_ydata[i,j]*time_step[i]
                  print("\n      Diffusion coeff particles type %2s, is:    D = %10.4e"%(NameAtom[j],D/Simulated_time.max()**2/6.*1.e-20),"m^2/s")
##################   SPECIFIC TO FIG 2 ##################  
    elif (plotnumber == 2):
         if ChoosingTimeOrKMC == 's':
            locallabel1='Old minimum if MRM'
            locallabel2='Saddle point'
            locallabel3='New minimum'
            
            barrier = extra_ydata[:,1]                    
            Sy = Sx = np.array([]) # array for ploting line that connects min and saddle points.
            for i in range(1,len(extra_ydata[:,0])):
                if(abs(ydata[i] - extra_ydata[i-1,0]) < 1e-5):
                    Sx = np.append(Sx,[ xdata[i]-1, xdata[i]-0.5, xdata[i] ])
                    Sy = np.append(Sy,[ Old_energynorm[i], Old_energynorm[i] + barrier[i], New_energynorm[i] ])
                else:
                    Sx = np.append(Sx,[ np.nan, xdata[i]-1, xdata[i]-0.5, xdata[i] ])
                    Sy = np.append(Sy,[ np.nan, Old_energynorm[i], Old_energynorm[i] + barrier[i], New_energynorm[i] ])
                    Total_rate[i] = 0.0 # If ENew(i-1) != EOld(i), it should be zero in Energies.dat, but it seens to be a bug in kART
       
            # mec=markeredgecolor, mfc=markerfacecolor, mew=markeredgewidth
            plt.plot(Sx,Sy,'-', label=label1, lw=1.5,rasterized=Rasterized)
            plt.plot(xdata[Total_rate==.0]-1,Old_energynorm[Total_rate==.0],marker='o',label=locallabel1,linestyle='None',color='r',ms=15,rasterized=Rasterized)
            plt.plot(xdata[1:]-0.5,Old_energynorm[1:]+barrier[1:],marker='x',label=locallabel2, linestyle='None',color='black',ms=15,rasterized=Rasterized)
            plt.plot(xdata[1:], New_energynorm[1:],marker='o',label=locallabel3, linestyle='None',ms=15,rasterized=Rasterized,mfc='None',mec='r')
            #plt.plot(KMCstep[1:]-1,Old_energynorm[1:],marker='o',label=label1, linestyle='None',color='r',ms=15,rasterized=Rasterized)

            plt.xlim(0,xdata[1:].max()+0.2)
            plt.ylim(0,float(Old_energynorm[1:].max() + barrier[1:].max()+0.2))
            print("ylim = ",float(Old_energynorm[1:].max() + barrier[1:].max()+0.2))        
         else:
            plt.plot(xdata[1:],extra_ydata[1:,0:1] - Emin,'-', label=label1, lw=1.5,rasterized=Rasterized)
##################   SPECIFIC TO FIG 3 ##################  
    elif (plotnumber == 3):
		    
        plt.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)			
##################   SPECIFIC TO FIG 4 ##################  
    elif (plotnumber == 4):
		    
        plt.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
##################   SPECIFIC TO FIG 5 ##################  
    elif (plotnumber == 5):
		
		    plt.rcParams['figure.subplot.right'] = 0.82
		    ax2 = ax1.twinx()
		    ax2.patch.set_alpha(0.0)
		    ax1.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
		    ax2.plot(xdata,extra_ydata,'--',label=label2,lw=2, color='r',rasterized=Rasterized)
		    lines1, labels1 = ax1.get_legend_handles_labels()
		    lines2, labels2 = ax2.get_legend_handles_labels()
##################   SPECIFIC TO FIG 6 ##################  
    elif (plotnumber == 6):
            
		    plt.rcParams['figure.subplot.right'] = 0.82
		    ax2 = ax1.twinx()
		    ax2.patch.set_alpha(0.0)
		    ax1.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
		    ax2.plot(xdata,extra_ydata,'--',label=label2,lw=2, color='r',rasterized=Rasterized)
		    lines1, labels1 = ax1.get_legend_handles_labels()
		    lines2, labels2 = ax2.get_legend_handles_labels()
##################   SPECIFIC TO FIG 7 ##################  
    elif (plotnumber == 7):
            
		    plt.rcParams['figure.subplot.right'] = 0.82
		    ax2 = ax1.twinx()
		    ax2.patch.set_alpha(0.0)
		    ax1.plot(xdata,ydata,'-', label= label1,lw=1.5,rasterized=Rasterized)
		    ax2.plot(xdata,extra_ydata,'--',label=label2,lw=2, color='r',rasterized=Rasterized)
		    lines1, labels1 = ax1.get_legend_handles_labels()
		    lines2, labels2 = ax2.get_legend_handles_labels()

##################   FOR ALL GRAPHS    ##################  

    for ax in fig.axes:
        ax.set_xscale(scale_X)
        ax.set_yscale(scale_Y)
    
    try:
        if ax2:
            ax1.set_ylabel(ylabel[0])
            ax1.set_xlabel(xlabel)
            if (plotnumber != 2):
                ax2.set_ylabel(ylabel[1])
                autoscale_Yaxis_Interval(ax1,ydata)
                autoscale_Yaxis_Interval(ax2,extra_ydata)
                
                ax2.legend(lines1 + lines2, labels1 + labels2, loc=2).draggable(True)
            else:
                l = ax1.legend(loc=0)
                l.draggable(True)
    except Exception as e:
        ax1.set_ylabel(ylabel[0])
        ax1.set_xlabel(xlabel)

        if (plotnumber != 2 ): autoscale_Yaxis_Interval(ax1,ydata)
        l=ax1.legend(loc=0)
        l.draggable(True)  
     
    if putTitle=="yes": ax1.set_title(title) 
    fig.tight_layout()

    if (yes == 'y'):
        lab.savefig(Plots_dir+stringsavelabel+XaxisName+'.'+fileFormat, format=fileFormat) #, transparent=True)
    return fig,ax1



##------------------------ 0) plot Time steps vs time or KMC step -----------------------#
if ((plotGraph.count('0'))or(plotGraph=='')):

    f0Xaxis,f0Xlabel = Xtimeorstep(XaxisName)  
    f0xdata = f0Xaxis[1:]
    f0ydata = Energies[1:,6]/scaleTime
    f0ylabel =list([' Time step ('+unitsScale+'s)'])
    f0label1='Time step'       
    f0label2='Mean %5.4f'%(f0ydata.mean())+' '+unitsScale+'s\nStdv  %5.4f'%(f0ydata.std())+' '+unitsScale+'s'
    f0title = 'Time for an event occurs Vs '+XaxisName+", "+Temp+"K"
    f0stringsavelabel = '/TimeStepVs'

    f0,axes0 = myplotglobal(f0xdata,f0ydata,0,f0Xlabel,f0ylabel,f0label1,f0label2,f0title,f0stringsavelabel,0)

##------------------------------  1)  Plot Diffusion  ------------------------------------#
if ((plotGraph.count('1'))or(plotGraph=='')):

    f1Xaxis,f1Xlabel       = Xtimeorstep(XaxisName)  
    f1xdata                = f1Xaxis
    f1ydata                = Diffusion[:,1]
    f1extra_ydata          = Diffusion[:,2:-2]
    f1ylabel               = list(['Squared displacement ($\AA^2$)'])
    f1label1               = 'Total displ. (Total steps %d)'%(Diffusion[:,-2].max()) if (XaxisName=='time') else 'Total displ.\nMax time %7.3f '%(Diffusion[:,0].max()/scaleTime) +unitsScale+'s'
    f1label2 = list()
    for i in range(len(f1extra_ydata[0])):
        f1label2.append("Sqr displ. for %s"%(NameAtom[i]))
    f1title                        = 'Diffusion Vs '+XaxisName+", "+Temp+"K"
    f1stringsavelabel      =  '/DiffusionVs'

    f1,axes1 = myplotglobal(f1xdata,f1ydata,f1extra_ydata,f1Xlabel,f1ylabel,f1label1,f1label2,f1title,f1stringsavelabel,1)

##-------------------------------- 2) plot Energies -----------------------------------#
if ((plotGraph.count('2'))or(plotGraph=='')):
    f2Xaxis,f2Xlabel       = Xtimeorstep(XaxisName)  
    f2xdata                = f2Xaxis
    f2ydata                = Old_energy
    f2extra_ydata          = Energies[:,3:5] # New_energy and barrier column 3 and 4 5 is excluded!
    f2ylabel               = list(['$\delta E$ (eV)'])
    if (XaxisName=='time'):
        f2label1               = '$\delta E=E - E_{Min}$,  $E_{Min}$ %7.3f eV'%(Emin) +'\nTotal steps %d'%(KMCstep.max())
    else:
        f2label1               = '$\delta E=E - E_{Min}$,  $E_{Min}$ %7.3f eV' %(Emin)+ '\nMax time %7.3f '%(Energies[:,7].max()/scaleTime)+unitsScale+'s'
 
    f2label2               = 0

    f2title                = 'Variation of Total Energy $E$ Vs '+XaxisName+", "+Temp+"K"
    f2stringsavelabel      = '/EnergyVs'

    f2,axes2 = myplotglobal(f2xdata,f2ydata,f2extra_ydata,f2Xlabel,f2ylabel,f2label1,f2label2,f2title,f2stringsavelabel,2)
# -------------Put Barrier values into plot by clicking bottom left-top corner----------
    if (ShowNumbersInPlot2):
        from matplotlib.widgets import CheckButtons
        ax2 = plt.axes([0.01, 0.9, 0.08, 0.095])    # parameters small box to clik (position and size).
        check = CheckButtons(ax2, ('Click to\nsee Eb',), (False,))# name of the bottom.
        box=[]
        
        for x,y,E in zip(f2xdata[1:]-0.5,Old_energynorm[1:]+Barrier[1:],Barrier[1:]):
            box.append(axes2.text(x,y,'%.2f'%E, ha='center', va= 'bottom', clip_on=True, visible=False )) #, fontsize=8))
        
        def func(label):
            for i in range(len(box)): box[i].set_visible(not box[i].get_visible())
            plt.draw()
        
        check.on_clicked(func) 

##-------------------------------- 3) plot Selc Event-----------------------------------#
if ((plotGraph.count('3'))or(plotGraph=='')):
    f3Xaxis,f3Xlabel       = Xtimeorstep(XaxisName)  
    f3xdata                = f3Xaxis
    f3ydata                = Barrier
    f3extra_ydata          = 0
    f3ylabel               = list([' Activation energy (eV)'])
    f3label1               = 'Act. energy.\nTotal steps %d'%(KMCstep.max()) if (XaxisName=='time') else 'Act. energy.\nMax time %7.3f '%(Simulated_time.max()/scaleTime) +unitsScale+'s'
    f3label2               = 0
    f3title                = 'Selc Barrier  Vs '+XaxisName+", "+Temp+"K"
    f3stringsavelabel      = '/selcBarrierVsTime'
    f3,axes3 = myplotglobal(f3xdata,f3ydata,f3extra_ydata,f3Xlabel,f3ylabel,f3label1,f3label2,f3title,f3stringsavelabel,3)	

##-------------------------------- 4) Topologies  ---------------------------------------#
if ((plotGraph.count('4'))or(plotGraph=='')):
    f4Xaxis,f4Xlabel       = Xtimeorstep(XaxisName)  
    f4xdata                = f4Xaxis[1:]
    f4ydata                = CumulTOPO
    f4extra_ydata          = 0
    f4ylabel               = list(['Topologies searched'])
    f4label1               = 'Topologies searched.\nTotal steps %d'%(KMCstep.max()) if (XaxisName=='time') else 'Topologies searched.\nMax time %7.3f '%(Simulated_time.max()/scaleTime) +unitsScale+'s'
    f4label2               = 0
    f4title                = 'Topologies searched Vs '+XaxisName+", "+Temp+"K"
    f4stringsavelabel      = '/CumulTOPOVs'
    f4,axes4 = myplotglobal(f4xdata,f4ydata,f4extra_ydata,f4Xlabel,f4ylabel,f4label1,f4label2,f4title,f4stringsavelabel,4)	

##-------------------------------- 5) Topologies encountered ---------------------------#
if ((plotGraph.count('5'))or(plotGraph=='')):
    f5Xaxis,f5Xlabel       = Xtimeorstep(XaxisName)  
    f5xdata                = f5Xaxis[1:]
    f5ydata                = CumulTOPO
    f5extra_ydata          = CPU_time[1:]/scaleCPUTime
    f5ylabel               = list(['Topologies searched','CPU time ('+unitsCPUScale+')'])
    f5label1               = 'Topologies searched. Total steps %d'%(KMCstep.max()) if (XaxisName=='time') else 'Topologies searched. Max time %7.3f '%(Simulated_time.max()/scaleTime) +unitsScale+'s'
    f5label2               = 'CPU time'
    f5title                = 'Topologies Searched and CPU '+XaxisName+", "+Temp+"K"
    f5stringsavelabel      = '/CumulTOPO_CPU_TimeVs'
    f5,axes5 = myplotglobal(f5xdata,f5ydata,f5extra_ydata,f5Xlabel,f5ylabel,f5label1,f5label2,f5title,f5stringsavelabel,5)	

    plt.rcParams.update(params)

#------------- 6) Plot Activation barrier and squared displacement vs time -------------#
if ((plotGraph.count('6'))or(plotGraph=='')):
    f6Xaxis,f6Xlabel       = Xtimeorstep(XaxisName)  
    f6xdata                = f6Xaxis
    f6ydata                = Barrier
    f6extra_ydata          = msd
    f6ylabel               = list(['Activation energy (eV)','Squared displacement ($\AA^2$)'])
    f6label1               = 'Act. energy. Total steps %d'%(KMCstep.max()) if (XaxisName=='time') else 'Act. energy. Max time %7.3f '%(Simulated_time.max()/scaleTime) +unitsScale+'s'
    f6label2               = 'Sqr displ.'
    f6title                = 'Act. energy and squared displ. vs '+XaxisName+", "+Temp+"K"
    f6stringsavelabel      = '/selcBarrier_SquaDispVs'
    f6,axes6 = myplotglobal(f6xdata,f6ydata,f6extra_ydata,f6Xlabel,f6ylabel,f6label1,f6label2,f6title,f6stringsavelabel,6)	


##-------------------- 7) Plot Energy and simulated time vs KMC steps -------------------#
if ((plotGraph.count('7'))or(plotGraph=='')):
    #f7Xaxis,f7Xlabel       = Xtimeorstep(XaxisName)  
    f7xdata                = KMCstep     
    f7Xlabel               ='KMC step'
    f7ydata                = New_energynorm
    f7extra_ydata          = Simulated_time/scaleTime
    f7ylabel               = list(['$\delta E$ (eV)','Simulated time ('+unitsScale+'s)'])
    f7label1               = '$\delta E=E - E_{Min}$,  $E_{Min}$ %7.3f eV'%(Emin)
    f7label2               = 'Simulated time. Max barrier %6.3f eV'%(Barrier.max())
    f7title                = 'Energy $\delta E$ and simulated time vs KMC steps'+", "+Temp+"K"
    f7stringsavelabel       = '/Energy_simulatedTimeVsKMCsteps.'

    f7,axes7 = myplotglobal(f7xdata,f7ydata,f7extra_ydata,f7Xlabel,f7ylabel,f7label1,f7label2,f7title,f7stringsavelabel,7)	







# Addition of two new figures to the script                                              #
# Script tested in Mac and Linux OSs, with python 2.7                                    #
# Written By: Mickaël Trochet.                                                           #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------# 

##-------------------------------- 8) plot palettes Energies (Old, New) and Barrier -----------------------------------#
if ((plotGraph.count('8'))or(plotGraph=='')):
  
  plt.rcParams.update(params)
  
  f8   = plt.figure(8)
  f8.patch.set_alpha(0.0) 
  fig1 = f8.add_subplot(111)
  fig1.patch.set_alpha(0.0)

 
  a1=np.linspace(-0.2,New_energynorm.max()+1,100)
  b1=a1
  
  plt.scatter(Old_energynorm[1:] ,New_energynorm[1:], c=Barrier[1:],s=400, cmap=plt.cm.autumn,rasterized=Rasterized)
  plt.plot(a1,b1,'-.',lw=1,rasterized=Rasterized)

  plt.xlabel('Initial Energy $\delta E$ (eV)')
  plt.ylabel('Final Energy $\delta E$ (eV)')
  cbar=plt.colorbar(shrink=1)
  cbar.set_label('Energy barrier (eV)')
    
  plt.xlim(xmin=-0.2)
  plt.ylim(ymin=-0.2)
     
  plt.grid(True,ls='-.',lw=1)
       
  inset = input('\n  ==> In Fig. (8), do you want an inset for the palette plot? If yes press (y), else (enter) :\n')
  if (inset=='e'): exit(1) 
  
  if (inset=='y'):
      ixlim   = eval(input('please enter the xlimit in the following form (###.### , ###.###):\n')     )
      iylim   = eval(input('please enter the ylimit in the following form (###.### , ###.###):\n')     )
      ixticks = eval(input('please enter the xticks in the following form [###.### , ###.###, etc]:\n')) 
      iyticks = eval(input('please enter the ylimit in the following form [###.### , ###.###, etc]:\n')) 
      a = lab.axes([0.15, 0.62, .3, .3])  
      a.patch.set_alpha(0.0)

      plt.scatter(Old_energynorm[1:] ,New_energynorm[1:], c=Barrier[1:],s=400, cmap=plt.cm.autumn,rasterized=Rasterized)
      plt.plot(a1,b1,'-.',lw=1,rasterized=Rasterized)
      if putTitle=="yes": plt.title('Inset')
      plt.setp(a, xlim=ixlim, ylim=iylim, xticks=ixticks, yticks=iyticks)                                                                     
      plt.grid(True,ls='-.',lw=1)
  
  
  if (yes == 'y'):
     lab.savefig(Plots_dir+'/Palette.'+fileFormat, format=fileFormat) 

    
##--------------------- 9) plot Histograms per configuration (and total)  -------------------------------#
if (plotGraph.count('9')or(plotGraph=='')):
  
  #################### DEFINE FUNCTIONS FOR THIS PLOT ##########################
  # Create 3 arrays with the energies in the interval (Energiesinf, Energiessup)
  def E_interval(Energiesinf,Energiessup,iniconf,barrier,finconf):
      for x in Energies2:
          if x[0]>Energiesinf and x[0]<Energiessup:
               iniconf.append(x[0])
               finconf.append(x[1])
               barrier.append(x[2])
      return  np.size(iniconf)
  
  def to_percent(y, position):
  # Ignore the passed in position. This has the effect of scaling the default
  # tick locations.
      s = str(int(100*y))
  # The percent symbol needs escaping in latex
      if plt.rcParams['text.usetex'] == True:
          return s + r'$\% $'
      else:
          return s + '% '
  
  #############################################################################
  # Do plots for each interval: 
  def Histogramme(plot_number,IntervalE,conf):
     # initialize arrays
     INITIAL         = []
     BARRIER         = []
     FINAL           = []
     U               = []
     ini_confmax     = []
     barrier_confmax = []
     fin_confmax     = []
  
     # Get energies in the interval (IntervalE[0], IntervalE[-1])
     E_interval(IntervalE[0],IntervalE[-1],ini_confmax,barrier_confmax,fin_confmax)
     for i in range(np.size(IntervalE)-1):
         # initialize arrays 
         u,ini_conf,barrier_conf,fin_conf = [],[],[],[]
         
         # Get energies in the subintervals (IntervalE[i], IntervalE[i+1])
         E_interval(IntervalE[i],IntervalE[i+1],ini_conf,barrier_conf,fin_conf)
  
         u = np.ones(np.size(ini_conf)) / float(np.size(ini_confmax)) # weights for each value

         INITIAL.append(ini_conf)
         BARRIER.append(barrier_conf)
         FINAL.append(fin_conf)
         U.append(u)
         
     Ei = min(ini_confmax)  # min and max values of inital energy interval
     Ef = max(ini_confmax)
        
     sub1=plt.subplot(3,1,1) # Distribution de la configuration conf 
     sub1.patch.set_alpha(0.0)

     nbins = np.arange(Ei, Ef + sizebinsminE, sizebinsminE) # it's an array
     #nbins = max(int(max(ini_confmax)/sizebinsminE),10)    # it's a number
     print('bin counts for initial histogram %s:'%(conf), len(nbins)) 
     
     plt.hist(INITIAL, bins=nbins, weights=U, histtype='barstacked', width=sizebinsminE, label ='Total counts %5.0f,'%(np.size(ini_confmax))+' width %5.1f meV)'%(sizebinsminE*1000.0),alpha=0.5)


     # if E interval is smaller than E bin size, reset interval in "x" axis to plot
     if (int((Ef-Ei)/sizebinsminE) < binsSpace): 
        plt.xlim(Ei - binsSpace*sizebinsminE,Ef + binsSpace*sizebinsminE) 
     
     if (not conf.isdigit()): # print title only if conf is different from a number 
        plt.title('%s'%(conf),fontsize=40) 
     
     plt.xlabel('$\delta E$ (eV)')
     plt.ylabel('Frequency ')
     plt.legend(loc='best', fancybox=True, framealpha=0.1).draggable(True) 
     
     formatter = FuncFormatter(to_percent)
     plt.gca().yaxis.set_major_formatter(formatter)
     
     Ei = min(barrier_confmax)   # min and max values of barrier energy interval
     Ef = max(barrier_confmax)

     sub2=plt.subplot(3,1,2) # Distribution des transition possible depuis la conf
     sub2.patch.set_alpha(0.0)
     nbins2 = np.arange(Ei, Ef + sizebinsBarrier, sizebinsBarrier) # it's an array
     
     print("bin counts for barrier histogram %s:"%(conf),len(nbins2))

     plt.hist(BARRIER, bins=nbins2, weights=U, width=sizebinsBarrier, histtype='barstacked', alpha=0.5)                                                                            

     
     if (int((Ef-Ei)/sizebinsBarrier) < binsSpace):
        plt.xlim(Ei - binsSpace*sizebinsBarrier,Ef + binsSpace*sizebinsBarrier) 

     plt.xlabel('Barrier $E$ (eV)')
     plt.ylabel('Frequency ')
     
     formatter = FuncFormatter(to_percent)
     plt.gca().yaxis.set_major_formatter(formatter)    
     
     Ei = min(fin_confmax) # min and max values of final energy interval
     Ef = max(fin_confmax)
  
     sub3=plt.subplot(3,1,3) # Distribution des destinations possible depuis la conf
     sub3.patch.set_alpha(0.0)
     nbins3 = np.arange(Ei, Ef + sizebinsEminF, sizebinsEminF)
     
     
     print("bin counts for final histogram %s:"%(conf), len(nbins3))
     
     plt.hist(FINAL, bins=nbins3, weights=U,  width=sizebinsEminF,histtype='barstacked', alpha=0.5)  
     
     
     if (int((Ef-Ei)/sizebinsEminF) < binsSpace):
        plt.xlim(Ei - binsSpace*sizebinsEminF,Ef + binsSpace*sizebinsEminF) 

     plt.xlabel('Final state $\delta E$ (eV)')
     plt.ylabel('Frequency ')
  
     formatter = FuncFormatter(to_percent)
     plt.gca().yaxis.set_major_formatter(formatter)
  
  
  #############################################################################  

        
  plot_number = 9
  Default_interval  = [0.0,max(OldNewAndBarrier[1:,0]+0.5)] # Default interval from Histo 9

  while True:
     from_step1to2 = input('\nFig(9), do histograms from KMC step1 to KMC step2. Please type the two numbers separated by "," or for using defaults [0,%d], (enter): '%(len(OldNewAndBarrier[1:,0])))  
     if (from_step1to2=='e'): exit(1)
     
     if (from_step1to2==''):
         Energies2 = OldNewAndBarrier               # if "enter" use full data
     else:
         step1 = eval(from_step1to2)[0]
         step2 = eval(from_step1to2)[1]
         Energies2 = OldNewAndBarrier[step1:step2,:] # data is chosen from KMC step1  to step2, given by user

     Input_interval = input('\nSelect the desired energy interval (Energy axis). It can be subdivided up to %2.0f'%(len(params['axes.prop_cycle']))+' different intervals - each with a different color, e.g., (0.0,0.1,0.2,0.3) - allowing knowing final and barrier energies obtained for each particular color interval in the inital energy.\n  ==> Please type the numbers separated by "," (or enter for using full interval: [0.0,%5.2f] eV): '%(max(OldNewAndBarrier[1:,0])))
     if (Input_interval=='e'): exit(1)

     if (Input_interval == ''):
          interval = Default_interval
     else:
          interval = eval(Input_interval)

     titlegraphe = input('\n  ==> Enter a "name" for the configuration (i.e the title or the graphe), if default (enter): ')  
     if (titlegraphe==''): titlegraphe = str(plot_number)

     plt.rcParams.update(params) 
     plt.rcParams['figure.figsize'] = 10,11

     plt.figure(plot_number).patch.set_alpha(0.0)
        
     plt.subplots_adjust(left=0.14, bottom=0.1, right=0.95, top=0.95, wspace=0.2, hspace=0.38) 
      
     Histogramme(plot_number,interval,titlegraphe)
   
     if (yes == 'y')and (interval != []):
        lab.savefig(Plots_dir+'/Histograms_'+titlegraphe+'.'+fileFormat, format=fileFormat) #, transparent=True)

     MoreHistograms = input('\n Do you want another histogram? If yes press (y) if not (enter): ')
     if((MoreHistograms=='')or(MoreHistograms!='y')): break
   
     plot_number=plot_number+1 

  ###########################################################################

plt.show()


# If we need to save new plots modified in the opened windows, saving them using this form keeps background transparent,
# if for you is not important, just use the bottom of the windows.
v = 0
while True:
   plotGraph = input('\n  ==> If you want to to save new versions of figures (0-8) type their numbers, else enter:')
   if (plotGraph.count('e')): exit(1)
   
   v = v + 1
   if (plotGraph.count('0')):
     
     f0.savefig(Plots_dir+'/TimeStepVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('1')):
     
     f1.savefig(Plots_dir+'/DiffusionVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('2')):
     
     f2.savefig(Plots_dir+'/EnergyVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('3')): 
     
     f3.savefig(Plots_dir+'/selcBarrierVsTime'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('4')): 
     
     f4.savefig(Plots_dir+'/CumulTOPOVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('5')): 
     
     f5.savefig(Plots_dir+'/CumulTOPO_CPU_TimeVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('6')): 
     
     f6.savefig(Plots_dir+'/selcBarrier_SquaDispVs'+XaxisName+'_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('7')): 

     f7.savefig(Plots_dir+'/Energy_simulatedTimeVsKMCsteps_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph.count('8')): 
     
     f8.savefig(Plots_dir+'/Palette_v'+str(v)+'.'+fileFormat, format=fileFormat)
   if (plotGraph==''): break



plt.rcParams.update(params)
input("\n       **** \"Press enter to finish.\"  ****     ")

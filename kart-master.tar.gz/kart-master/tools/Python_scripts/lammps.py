# -*- coding: utf-8 -*-

# Copyright (c) Norwegian University of Science and Technology (NTNU) and SINTEF Materials and Chemistry, 2017
# By Jesper Friis
# Edition by Simen Nut Hansen Eliassen and Mickael Trochet 

"""
Module for interfacing ASE Atoms objects with LAMMPS input and output files.

Extracting the atom configuration from LAMMPS input can either be done
by calling read_data() directly:

>>> atoms = read_data('conf.lmp', atom_types='Al,Mg,Si')

or by creating a LammpsInput instance:

>>> lmp = LammpsInput('in.lammps')
>>> atoms = lmp.get_atoms()

Using a LammpsInput instance, it is also easy to read LAMMPS dump files:

>>> dump = lmp.get_dump_xyz('dump10000.xyz')

Writing a LAMMPS input file can be done with:

>>> write_data('conf.lmp', atoms)
"""
from __future__ import print_function

import os
import re
import gzip
import warnings

import numpy as np
import ase

from write_lmp_data import write_lammps_data

'''
There was a problem that read_data did not get the correct length of symbols to obtain number of atoms (atno). Search '# SNHE' to see changes.
'''


class LammpsInput(object):
    """Class using information in a LAMMPS input file to read and write
    LAMMPS data files in different formats to and from ASE Atoms objects.

    Parameters
    ----------
    filename : string
        LAMMPS input file.
    atom_types : None | string | sequence of strings
        A comma-separated string or sequence of atom types in correct order.
        If not given, it will be tried extracted from the input.
    """
    def __init__(self, filename='in.lammps', atom_types=None):
        self.filename = filename
        # atom types
        if atom_types is None:
            self.atom_types = get_atom_types_from_input(filename)
        elif isinstance(atom_types, str):
            self.atom_types = atom_types.split(',')
        else:
            self.atom_types = atom_types
        # Read all LAMMPS commands from file
        # Repeated commands will be converted to lists
        self.commands = {}
        for line in open(filename):
            if '#' in line:
                line = line[:line.index('#')]
            line = line.strip()
            if not line:
                continue
            cmd, val = line.split(None, 1)
            if cmd in self.commands:
                if not isinstance(self.commands[cmd], list):
                    self.commands[cmd] = [self.commands[cmd]]
                self.commands[cmd].append(val)
            else:
                self.commands[cmd] = val
        # Set some defaults
        self.commands.setdefault('atom_style', 'atomic')
        self.commands.setdefault('units', 'lj')
        # Cache
        self._atoms = None

    def __len__(self):
        return len(commands)

    def __getitem__(self, name):
        return self.commands[name]

#    def __getattr__(self, name):
#        return self.commands[name]

#    def __setattr__(self, name, value):
#        warnings.warn('You cannot set LAMMPS input commands via this class')

    def __contains__(self, name):
        return name in self.commands

    atoms = property(lambda self: self.get_atoms(), 
                     doc='Atoms object for LAMMPS input.')

    def get_atoms(self):
        """Returns atoms object for LAMMPS input."""
        if self._atoms is None:
            datafile = os.path.join(
                os.path.dirname(self.filename), self.commands['read_data'])
            self._atoms = read_data(datafile, atom_types=self.atom_types, 
                                    atom_style=self.commands['atom_style'], 
                                    units=self.commands['units'])
        return self._atoms

    def get_dump_xyz(self, filename):
        """Returns atoms object for a LAMMPS dump file in xyz format."""
        input = self.get_atoms()
        return read_dump_xyz(filename, self.atom_types, input.cell)

    def get_dump(self, filename):
        """Returns atoms object for a LAMMPS dump file in custom format."""
        return read_dump(filename, self.atom_types)
    
    def write_data(self, atoms, lmpfile=None, force_skrew=False):
        """Writes `atoms` to lmp file.  If `lmpfile` is None, the file name
        in the "read_data" command is used.
        """
        if lmpfile is None:
            lmpfile = os.path.join(
                os.path.dirname(self.filename), commands['read_data'])
        write_data(lmpfile, atoms, specorder=self.atom_types, 
                   force_screw=force_screw)
        

    
def read_data(filename, atom_types=None, gz=None, atom_style='atomic', 
              units='metal'):
    """Read LAMMPS data file with atomic coordinates and return an Atoms
    object.

    Parameters
    ----------
    filename : string
        Name of data file to read.
    atom_types : None | string | sequence of strings
        A comma-separated string or a sequence of chemical symbols
        corresponding to the atom types.  The default is to read this from the
        first line.
    gz : None | bool
        Whether `filename` is zipped.  The default is to determine this from
        the file name extension (.gz).
    atom_style : "atomic"
        Describes how information is about atoms is stored.  Currently only
        "atomic" is supported.
    units : "metal"
        Describes the units that are used.  Currently only "metal" is
        supported.
    """
    # Data that we actually want to extract
    atno = []      # atom type numbers
    positions = [] # atom positions

    if gz is None:
        gz = filename.endswith('.gz')
    if gz:
        f = gzip.open(filename, 'rb')
    else:
        f = open(filename, 'r')

    section = 'Header'  # the section we are currently reading
    kw = {}             # Dict of defined keywords
    header_keywords = (
        'atoms',    # used
        'bonds',
        'angles',
        'dihedrals',
        'impropers',
        'atom types',  # used
        'bond types',
        'angle types',
        'dihedral types',
        'improper types',
        'extra bond per atom',
        'extra angle per atom',
        'extra dihedral per atom',
        'extra improper per atom',
        'extra special per atom',
        'ellipsoids',
        'lines',
        'triangles',
        'bodies',
        'xlo xhi',   # used
        'ylo yhi',   # used
        'zlo zhi',   # used
        'xy xz yz',  # used
        )

    def getline(f):
        """Help-function returning the next non-blank and non-commented line.
        An empty string is returned at end of file."""
        while True:
            line = f.readline()
            if not line:
                return line
            if '#' in line:
                line = line[:line.index('#')]
            line = line.strip()
            if line:
                return line

    # Read data
    comment = f.readline()  # first line is just a comment
    while True:
        line = getline(f)
        if not line:
            break

        # Read Header
        if section == 'Header':
            found = False
            for keyword in header_keywords:
                if line.endswith(keyword):
                    found = True
                    kw[keyword] = line[:len(line) - len(keyword)]
            if found:
                continue
            section = None  # leave header...
        
        # If not set, assign new section
        if not section:
            section = line

        # Read Atoms
        if section == 'Atoms':
            if atom_style == 'atomic':  # atom_ID, atom_type, x, y, z
                for i in range(int(kw['atoms'])):
                    l = getline(f).split()
                    atno.append(int(l[1]))
                    positions.append([float(v) for v in l[2:5]])
            elif atom_style == 'charge':
                for i in range(int(kw['atoms'])):
                    l = getline(f).split()
                    atno.append(int(l[1]))
                    positions.append([float(v) for v in l[3:6]])
            else:
                raise NotImplementedError(
                    '`atom_style` "%s" is not supported' % atom_style)
            section = None

        # Read Masses (and extract atom_types from them)
        if section == 'Masses':
            atno = []
            masses = []
            for i in range(int(kw['atom types'])):
                l = getline(f).split()
                atno.append(int(l[0]))
                masses.append(float(l[1]))
            if not atom_types:
                M = ase.data.atomic_masses.copy()
                M[np.isnan(M)] = -10000.0  # get rid on nan's
                numbers = [np.abs(M - mass).argmin() for mass in masses]
                symbols = [ase.data.chemical_symbols[n] for n in numbers]
                atom_types = [symbols[n - 1] for n in atno]
            section = None

            
    # Done reading
    if not atom_types:  # get atom_types from header comment
        atom_types = comment.split()
    elif isinstance(atom_types, str):  # support comma-separated string
        atom_types = atom_types.split(',')
    if 'atom types' in kw and len(atom_types) != int(kw['atom types']):
        raise RuntimeError(
            'length of `atom_types`=%r is not %d specified by the '
            '"atom types" keyword' % (atom_types, int(kw['atom types'])))
    symbols = np.array(atom_types)[np.array(atno) - 1]

    xlo, xhi = [float(v) for v in kw['xlo xhi'].split()]
    ylo, yhi = [float(v) for v in kw['ylo yhi'].split()]
    zlo, zhi = [float(v) for v in kw['zlo zhi'].split()]
    if 'xy xz yz' in kw:
        xy, xz, yz = [float(v) for v in kw['xy xz yz'].split()]
    else:
        xy, xz, yz = 0.0, 0.0, 0.0
    cell = np.array([
            (xhi - xlo,          xy,                xz),
            (0.0,         yhi - ylo,                 yz),
            (0.0,               0.0,         zhi - zlo)])

#    atoms = ase.Atoms(symbols=symbols, positions=positions, cell=cell,pbc=True) # SNHE
    atoms = ase.Atoms(positions=positions, cell=cell,         pbc=True)
#    return atoms
    return atoms, atno

    
def read_dump(filename, atom_types):
    """Read LAMMPS dump file.
    """
    raise NotImplementedError


def read_dump_xyz(filename, atom_types, cell):
    """Read LAMMPS xyz-formatted dump file returning an Atoms object.

    Since this file format does not contain information about the cell or
    associate the atom type number with a chemical symbol, you have to provide
    these via the `atom_types` and `cell` arguments.
    
    Example
    -------
    # Read a structure with Al as the first and Cu as the second element
    >>> read_dump_xyz('out50000.xyz', ['Al', 'Cu'], cell=[10., 10., 10.])
    """
    with open(filename, 'r') as f:
        natoms = int(f.readline())
        f.readline()  # skip second line
        dtype = [('atno', 'i8'), ('x', 'f8'), ('y', 'f8'), ('z', 'f8')]
        data = np.loadtxt(f, dtype=dtype)
    if isinstance(atom_types, str):
        atom_types = atom_types.split()
    symbols = np.array(atom_types)[data['atno'] - 1]
    positions = data[['x', 'y', 'z']].view(float).reshape(-1, 3)
    atoms = ase.Atoms(symbols=symbols, positions=positions, cell=cell, 
                      pbc=True)
    return atoms


# Great, Inga already implemented this...
write_data = write_lammps_data



def get_atom_types_from_input(filename):
    """Read the atom types from a LAAMPS imput file."""
    # FIXME - by default, extract the atom types from the potential
    deco = []
    M = ase.data.atomic_masses.copy()
    M[np.isnan(M)] = -10000.0  # get rid on nan's
    with open(filename) as f:
        for line in f:
            line.strip()
            if re.match(r'^mass\s', line):
                masskey, atid, mass = line.split()
                if atid == '*':
                    atid = len(deco) + 1
                atid = int(atid)
                mass = float(mass)
                number = np.abs(M - mass).argmin()
                symbol = ase.data.chemical_symbols[number]
                if abs(M[number] - mass) > 0.4:
                    raise UserWarning(
                        'Atomic mass %d in "%s" differ more than '
                        '%.2f u from the mass of %s' % (
                            atid, filename, np.abs(M[number] - mass), symbol))
                deco.append((atid, symbol))
    deco.sort()
    if [i for i, s in deco] != range(1, len(deco) + 1):
        raise RuntimeError(
            'atom id\'s in "%s" are not continous from 1 to %d' % (
                filename, len(deco) + 1))
    return [s for i, s in deco]


def sortatoms(atoms, order_or_lammpsfile=None):
    """Returns a copy of `atoms` sorted according to `order_or_lamppsfile`.

    Parameters
    ----------
    atoms : Atoms instance
        Atoms instance to write. 
    order_or_lammpsfile : None | sequence of strings | string
        The order of species as a sequence of chemical symbols.
        The default is to sort the chemical symbols alphabetically.
        If a string is provided, it is interpreated as the name of a 
        LAMMPS input file define the order of species.
     """
    if order_or_lammpsfile is None:
        perm = atoms.numbers.argsort(kind='mergesort')
    else:
        if isinstance(order_or_lammpsfile, str):
            order = get_atom_types_from_input(filename)
        else:
            order = order_or_lammpsfile
        if set(order) != set(atoms.get_chemical_symbols()):
            raise ValueError(
                'The species provided with `order_or_lampsfile` %r does '
                'not correspond to the species in `atoms` %r' % (
                    order, set(atoms.get_chemical_symbols())))
        d = dict((k, i) for i, k in enumerate(order))
        deco = [(i, s) for i, s in enumerate(atoms.get_chemical_symbols())]
        deco.sort(key=lambda t: d[t[1]])
        perm = np.array([i for i, s in deco])
    return atoms[perm]



# -*- coding: utf-8 -*-
# Python module to download kART output from remote folder to local machine              # 
#                                                                                        #
# How to use it:                                                                         #
# import the module name in your python script 
# 
# Script tested in Mac and Linux OSs (2017), with python 3.4                             #      
# Written By: Mickael Trochet                                                            #
# Departement de physique and Regroupement Quebecois sur les Materiaux de Pointe (RQMP), # 
# Universite de Montreal, Montreal, QC, Canada,                                          #
#----------------------------------------------------------------------------------------# 

import os

def download_datfile(remotehostname, CWD,string): 
	cpyFrom = input('\n*** To "EXIT" at any step press (e) ***\n\nCopy data from '+remotehostname+'? if yes press (y), if not (enter): ')
	if (cpyFrom=='e'): exit(1)
	if (cpyFrom == 'y'):
		print("Adress in local machine:")
		os.system('echo "  ==>" $(pwd) ')
		CheckAdress = input('\nTarget adress in the remote machine:\n  ==> '+ CWD +	' <==.\n\nIf this is incorrect, put the right adress of the dir in remote machine. Else press enter:\n ==> ' + CWD) # Import *.dat files from cluster, escluding files event_list_conf_XX.dat
		if (CheckAdress == ''):
			print("Downloading from "+remotehostname+':'+CWD+" the following file or folder "+string)     
			os.system("rsync  --exclude='Mine'  -avrzP "+remotehostname+":"+ CWD +string)
		else:
			print("Downloading from "+remotehostname+':'+CWD+" the following file or folder "+string)     
			os.system("rsync  --exclude='Mine' -avrzP "+remotehostname+":"+ CWD+CheckAdress+string)
		# Print INFO file of simulation
		if (string == "/*.dat ."):
			for line in open('KMC-log.dat','r'):
				if 'TEMPERATURE' in line: Temp = line.split()[-1].split(".")[0] # last split is to remove decimal after "."
			print ( "\nTEMPERATURE:", Temp+"K")
		print("Download was completed successfully ")

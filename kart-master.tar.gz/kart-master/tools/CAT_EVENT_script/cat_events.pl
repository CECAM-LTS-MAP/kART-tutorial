#!/opt/local/bin/perl
###########################################################################
# 
# cat_events.sh - concatenates multiple events directories
#
# Universite de Montreal
#
# Copyright Peter Brommer 2010
#
# This shell script concatenates all events (event files AND corresponding
# xyz-files) from multiple directories to the current directory (default)
# 
# Usage: cat_events.sh [-t TARGET_DIR] DIR1 [DIR2] [DIR3] [..]
#
# $Revision$
# $Date$
# $Id$
###########################################################################

use File::Copy;
use Getopt::Std ;
use File::Basename;

sub usage { 
    print "Usage: ".basename($0)." [-t TARGET_DIR ] DIR1 [DIR2] [DIR3] [...] \n" ;
    exit
}

getopts ('t:') || &usage;

if ($opt_t) { 
    ( -d$opt_t ) || die "Target directory $opt_t does not exist\n";
    if ( $opt_t =~ m/\/$/ ) {
	$target=$opt_t ;
    } 
    else {
	$target=$opt_t."/"  ;
    }
}
else {
    $target="./";
}


$ARGC=@ARGV; 
if($ARGC<1) { &usage; }

foreach $dir (@ARGV) {
    $dir .= "/";
    $dir =~ s?//?/?g ;
    if ( -d$dir ) {
	opendir(my $eventdir, $dir) || die ("Cannot open directory $dir");
	while ($file=readdir $eventdir) {
	    # only treat events files
	    if ($file =~ m/^event.+/) {
		$tfile = $file ;
		# does the file already have a suffix? Strip it.
		if ($tfile =~ m/_\d+$/) {
		    $suffix = $1 ;
		    $suffix =~ s/_// ;
		    $tfile =~ s/_\d+$//; 
		} else { $suffix="0"; } 
   		if ( -e $target.$tfile ) {
		    while ( -e $target.$tfile."_".$suffix ) {
			$suffix++;
		    }
		    $tfile = $file."_".$suffix ;
		}
		copy($dir.$file, $target.$tfile ) or die ("Cannot copy file $dir$file");
		#also copy xyz.files
		if ( -e $dir."xyz.".$file ) {
		    copy ($dir."xyz.".$file, $target."xyz.".$tfile)
		}
	    }
	}
	closedir $eventdir
    }
    else {
	print "$dir is not a directory, skipping \n";
    }
    # Creating the Mine file needed by kART to recognize directory
    open(FH,'>',$target."Mine") or die "Can't create file Mine $!";
    close(FH);
}


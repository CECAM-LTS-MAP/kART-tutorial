# Bash script to replace the name of all variables in te code with the respective ones given in KMC.sh
# The new names are all in uppercase, so this makes eassy to identify input variables. 

cp ../*f90 .  # copy files form SRC dir to sub dir
# Aply convention: transforming all imput variables to capital leters (uppercase) 
Arr2=($(awk -F"'" '{if($0~/getenv\(/) a=$2; if($0~/read\(/){split($0,b,")"); print a,toupper(a)}}' ../read_param.f90 ../art_read_parameters.f90|egrep -v "BASIN_GRAPH" ))
index=0
n=1
Arr_LEN=${#Arr2[@]}
while [ "$index" -lt "$Arr_LEN" ]; do
       echo "$n replacing var KMC.sh name ${Arr2[$index]} by upper case name ${Arr2[$((index+1))]}"
       sed -i "s/\<${Arr2[$index]}\>/${Arr2[$((index+1))]}/gI" read_param.f90 art_read_parameters.f90
    let "index += 2"
    let " n++ " 
done


# Replacing var names in code
Arr=($(awk -F"'" '{if($0~/getenv\(/) a=$2; if($0~/read\(/){split($0,b,")"); print b[2],toupper(a)}}' ../read_param.f90 ../art_read_parameters.f90|egrep -v "\(|LOCAL_CUTOFF|restart_conf|AllConf|BASIN_GRAPH" ))
index=0
n=1
Arr_LEN=${#Arr[@]}
while [ "$index" -lt "$Arr_LEN" ]; do
       echo "$n replacing var name ${Arr[$index]} by ${Arr[$((index+1))]}"
       sed -i "s/\<${Arr[$index]}\>/${Arr[$((index+1))]}/gI" *f90 
    let "index += 2"
    let "n++" 
done

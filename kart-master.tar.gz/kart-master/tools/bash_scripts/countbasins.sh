#!/bin/bash 
# Prints basin-step statistics. Optional argument is offset between steps
# in sortieproc and
# and 
gawk -voffset=$1 '/KMC/ {stepno = offset+$4} 
/event executed with success in basin/ {print stepno,1,$7} 
/no basin/ || /left basin/ {print stepno,0,0}' sortieproc.0 
This program will read a local events.uft file and convert it to a directory called 
EVENT_DIR containing 2 txt files per event. On will be a xyz file used for vizualization
and another containing information about the physics and the topologies asssociated with it.

Just compile the file kART_uft2txt.f90 and run the program in a directory where the events.uft
file is located.

UPDATE: If no arguments are given on the command line, the program will convert all
the events present in the events.uft file. To convert a single event, write the
eventID after the program name and only that event will be converted (if
present). 


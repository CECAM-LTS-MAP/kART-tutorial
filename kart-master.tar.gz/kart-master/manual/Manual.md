[[_TOC_]]

# Download the source code

The source code is now available through `https://gitlab.com`. To obtain
the code, please create an account and contact Normand Mousseau or
another administrator to gain access.

If you want to create a local git repo named `kart` in a directory named
, follow these steps:

      % cd $KART_DIR
      % git clone https://gitlab.com/groupe_mousseau/kart.git kart
            *  Enter your gitlab username when asked
            *  Enter your gitlab password when asked 
      % cd kart; git log --oneline --decorate --name-status

The first line of the output of step 3 (test) should look like this:

      8c880bf (HEAD -> master, origin/master, origin/HEAD) Add saddle_push object in dependencies

k-ART can also be used with the LAMMPS library. For that LAMMPS must be
downloaded and compiled as a library separately before compiling k-ART
(<http://lammps.sandia.gov>). **Note that, as of March 22, 2021, kART is interfaced with LAMMPS code of September 2020 and later only (older version of LAMMPS will not work).**

More information on how to use `gitlab` is available in the `wiki` page
of the k-ART application on `https://gitlab.com`.

# Testing rapidly with Docker

Docker (https://docs.docker.com/compose/install/) is an environment,
available for Windows, Mac and Linux that allows sandboxing
applications. Christopher Ostrouchov porter k-ART to docker, greatly
facilitating first tests of k-kART for new users.

After you install `docker` on your computer, execute the following
commands to download an image of k-ART:

      % docker login registry.gitlab.com. [You will need to provide username and password]
      % docker pull registry.gitlab.com/groupe_mousseau/kart:master

You can now see the image in the list of docker images:

      % docker images

To run k-ART, for instance on the -vac-lammps@ example:

      % docker run -it registry.gitlab.com/groupe_mousseau/kart:master
      % cd EXAMPLES/Si-vac-lammps
      % mpirun -np 4 ./KMC.sh 

Here again, more information on how to use `docker` is available in the
`wiki` page of the k-ART application on `https://gitlab.com`.

# Compiling the code

Since `docker` is not a very fast environment, you will need to compile
the code to run real applications. The basic package contains code in
fortran 95 and C (for the `NAUTY` part). It compiles with standard
compilers such as gnu (gfortan and C/C++) and Intel. It simply requires
the `lapack` and `blas` libraries.

It can be compiled with or without MPI (use the option `-DMPI_VERSION`
to use MPI)

There are a number of makefile.arch definitions provided in the MAKE
folder. A few particularly useful are

Linux/Intel :

:   `make intel` (with MPI) (not tested recently)

IBM/Linux/Intel (UdeM):

:   `make briaree` (with MPI) (last time tested 23 June 2015)

IBM/Linux/Lammps (UdeM) :

:   `make briareelammps` (with MPI) (last time tested 23 June 2015)

IBM/Linux/Intel (McGill) :

:   `make guillimin` (with MPI) (last time tested 23 June 2015)

IBM/Linux//Lammps (McGill) :

:   `make guilliminlammps` (with MPI) (last time tested 23 June 2015)

Mac/Intel :

:   `make mac` (serial) (not tested recently)

Mac/Gnu :

:   `make mac_gfort` (serial) (not tested recently)

Mac/MPI :

:   `make mac_mpi` (with MPI and intel) (last time tested 13
    August 2014)

Mac/Lammps/MPI:

:   `make maclammps_mpi` (with MPI,intel and lammps) (last time tested
    13 August 2014)

If they do not work, try adjusting the libraries.

## Building on mac OS X (10.9.4) with Intel compiler, Lammps and Openmpi

To build kART on a mac, with the lammps library, users do need to
install a version of Openmpi (1.6.5 and 1.8.1 tested) and a version of
FFTW (FFTW3 tested).

### Openmpi installation

First of all, for more details, we recommend to have a look at this two
webpages :

<http://www.open-mpi.org/faq/?category=building> section 15\
<https://software.intel.com/en-us/articles/performance-tools-for-software-developers-building-open-mpi-with-the-intel-compilers#10>

Download the openmpi version that you desire on their webpage. Untar,
unzip the file, (the command should be *tar -xf
openmpi-\*.\*.\*.tar.gz*). Once it is done, go into the folder
openmpi-1.8.1 and then type the following command :\
*./configure --prefix= (Installation location) CC=icc CXX=icpc F77=ifort
FC=ifort*.

We highly recommend that you create a specific and unique path for the
installation of openmpi before typing the configure command because your
machine may already have a version of it (for example
*/usr/MPI/intel/openmpi/number_version/*) and interference may occur
between installation.

After the configuration command and if everything went well just type
*make all install*. The two previous command produce a lot of scene
output and can take about 20 mins to be done, be patient !

Now the installation is done but it is not over yet, you have to set the
PATH for the bin directory and the library directory this way :\
*export PATH=(installation_directory)/bin:\$PATH*\
*export
DYLD_LYBRARY_PATH=(installation_directory)/lib:\$DYLD_LYBRARY_PATH*

You can add this two lines in your $\sim/.profile$ or $\sim/.bashrc$ to
set them as a default path.

### FFTW installation

Download the FFTW version that you desire on their webpage. Untar, unzip
the file. Once it's done go to the folder fftw and then type the
following command :\
*./configure --prefix= (Intallation location)*. Once again we highly
recommend that you create a specific installation directory (for exemple
*/usr/FFTW/*). After the configuration type *make* and then *make
install*.

Now the installation is done but it is not over yet, you have to set the
PATH for the bin directory and the library directory this way :\
*export PATH=(installation_directory)/bin:\$PATH*\
*export
DYLD_LYBRARY_PATH=(installation_directory)/lib:\$DYLD_LYBRARY_PATH*

### kART and Lammps Makefiles

For LAMMPS, make sure that you compile all the libraries and load the
needed packages. The architecture that you might want to use is
*mac_mpi* but you also need to modify it by setting the path for the mpi
and fftw that you have just created.

For kART, the architecture `maclammps_mpi` is already setup. However,
you will need to verify the `bin`, `include` and `lib` directory for
these softwares : `openmpi`, `fftw`, `mkl` and `Lammps`.

One more warning: when building on Mac OSX using intel compiler, one
will probably need to source the file `mklvars.sh` with the option
intel64 (especially if the compilation succeeds but not the execution of
the code).

## Using with LAMMPS {#sub:using_with_lammps}

k-ART can be compiled with the LAMMPS library, giving it access to a
wide range of efficiently programmed forcefields. k-ART includes a
modified version of the fortran interface to the library as the original
one has some limitations.

For this, download the latest version of LAMMPS :
<http://lammps.sandia.gov>

LAMMPS can be compiled with `cmake` or `make`. We provide below a brief list of commands. Please refer to LAMMPS' manual for all details.  

### CMake

####  Build LAMMPS as a library

    cd lammps                # change to the LAMMPS distribution directory
    mkdir build; cd build    # create and use a build directory
    cmake ../cmake           # configuration reading CMake scripts from ../cmake
    cmake --build .          # compilation (or type "make")


#####   Load all the packages from LAMMPS that you need before.
For example, you might want to load the `MANYBODY` and the `MEAM` Section_packages

##### Define the nature of the library used. 

By defaults, lammps build a static library. It is often preferable to used a shared library. If you include the `MPI` option, then the cmake will be compile with :  

    # Build the options
    cmake ../cmake -D BUILD_MPI=yes -D BUILD_SHARED_LIBS=yes -D PKG_MANYBODY=yes -D PKG_MEAM=yes
    cmake -- build .     # compilation


### Make version

1.  Build LAMMPS as a Library,

    a)  Load all the packages from LAMMPS that you need before
        compilation. (for example, the package
        [manybody]{style="color: red"} is needed for using tersoff and
        sw potential) you can find the list of all the available
        packages by typing *make package-status* in the src directory of
        LAMMPS or check the list on their web site
        (<http://lammps.sandia.gov/doc/Section_packages.html>)

    b)  Now Compile LAMMPS as a library by entering :\
        `% make makelib`\
        `% make -f Makefile.lib foo` for old version of LAMMPS\
        `% make mode=lib foo` for newest version of LAMMPS\
        (where foo is the architecture makefile name, for further
        details check the section 2.5 of their web page,
        <http://lammps.sandia.gov/doc/Section_start.html#start_5>)

    c)  You should have now a file named *liblammps_foo.a* in the src
        folder. You can move it to the source code directory of kART or
        update the path to the library in the k-ART Makefile.

2.  To compile k-ART with the lammps library, you need to use the
    `-DLAMMPS_VERSION` flag and set the path to the src folder of your
    lammps distribution (see the *briareelammps* option as an example).

### Second level of parallelization {#double para}

k-ART is now able to use two level of parallelization. the first one is
about distributing ARTnouveau search throughout a specific group of
submaster, and the second level is about computing force throughtout
each group of workers associated to a specific submaster. The
implementation is done in such a way that one has to define the
following variable.

    setenv   NTRAVAILLEUR     k 

With *k* is the number of workers that will compute forces. Be careful
of the value that you might want to use because the number of submaster
is calculated base on the number of worker and the number of cores
asked. If this division is not a integer the code will stop.

## Building on briaree (IBM/Linux/Intel) {#briaree}

Connection to the `briaree` server is very straightforward using the SSH
protocol. The following information may be useful. You can define this
information into a file called `config` into the `.ssh` directory that
is automatically created in your home directory:

      Host briaree
         Hostname briaree.calculquebec.ca
         Port 22

You can then login with:

`% ssh briaree`

One should have an account on compute Canada to be allowed to use the
resources of `briaree`. For further information, please visit
<https://www.computecanada.ca>.

To build k-ART on the briaree cluster (UdeM), without the lammps
library, just go in the SRC folder and type `make briaree`. This should
create the file `KMCART_correctmap_briaree` and move it to your binary
directory (default is bin in the home directory, can be changed with the
BINDIR variable in the Makefile).

To compile k-ART with the *lammps* library, you first need to create the
*lammps* library file. Follow the instructions below to create it and
then use the LAMMPSPATH variable in the makefile under the briareelammps
flag to define its path. You can then compile by typing the command:

`% make briareelammps`.

1.  If working on a cluster, load all the necessary modules used during
    compilation (intel-compilers for example) and the MPI modules if the
    parallel version is being compiled (recommended).

2.  Make the necessary modifications to the Makefile.

3.  For example, on unix (briaree), we are using the following modules
    :\
    - *intel-compilers/12.0.4.191*\
    - *MPI/Intel/openmpi/1.6.2*\
    - And if lammps version *FFTW/3.3*

## Building on guillimin (IBM/Linux/intel)

As in the preceding subsection, connection on guillimin is made via
these informations :

      Host briaree
         Hostname guillimin.hpc.mcgill.ca
         Port 22

and login with:

`% ssh guillimin`

To build k-ART on the guillimin cluster (McGill), with or without the
*lammps* library, we refer to the same procedure as in subsection
[3.3](#briaree){reference-type="ref" reference="briaree"}. One just
needs to substitute the keyword briaree for the keyword guillimin..
Also, one needs to load the appropriate modules used in the guillimin
cluster.

As an example, we are using the following modules :\
- *ifort_icc/15.0*\
- *openmpi/1.8.3-intel*\
- *FFTW/3.3-openmpi-intel*\
- *MKL/11.2*.

# Executing k-ART

For the first run we'll need a minimum number of files. Others can be
added with various parameters described below.

1.  *KMC.sh* script initializes ***all the input parameters*** and
    launches the k-ART executable.

2.  *initial.conf* which contains the system's initial configuration
    (atomic positions)

3.  To launch k-ART on cluster computers using a job management system,
    a script is needed (as an example, we give a *jobfile.sh* file) to
    launch the simulation (serial or MPI versions). In this file you set
    up the number of processors needed and launch the *KMC.sh* script.

To use k-ART with LAMMPS supported version you will also need:

1.  *in.lammps* which describes the physical parameters used by the
    lammps instance (i.e. box size, potential used).

2.  *Si.sw* This is the value of the parameter of the SW potential. You
    can use any of the potential in the potential directory in lammps
    directory but make sure that the potential you want to use require
    to load new package from lammps and also modify the in.lammps by
    include the new pair style. Also, some potential may require a
    library file in addition to the parameter file. In particular, this
    is the case for the MEAM and ReaxFF potentials. For further
    information, refer to the lammps website.

In the directory `EXAMPLES`, you will find a number of examples -- with
and without lammps -- on which you can execute k-ART. Most represent a
single vacancy in a box of 511-atom Stillinger-Weber crystalline
silicon. There is also a test with Si-H, an alloy.

In most directories, you will find a launch file (`KMC.sh`) that can be
used in serial (type in terminal):

       ./KMC.sh

and in parallel simulations:

       mpirun -np 12 KMC.sh

## Changing the script from csh to bash 

If *csh* or a *csh*-compatible shell is not installed in your cluster
machine (or you don't want to use it), you don't need to write an
auxiliary file with *export* command of *bash*. In your *jobfile.sh*,
simply change change

      mpiexec ./KMC.sh

by

      eval $(awk '{if($1=="setenv"){$1="export";$2=$2"="$3;$3="";sub(/#.*/,"");print}}' KMC.sh)
      mpiexec ~/bin/KMCART_exec

The first line should replace KMC "*setenv csh*\" stile by "*export
bash*\" (*awk* creates the new script and 'eval\" export the awk output
to bash). The second line corresponds to the executable in `KMC.sh`. It
strongly depends on the system installed to submit the jobs into the
cluster machine. For example this is another version for parallel
simulations:

     eval $(awk '{if($1=="setenv"){$1="export";$2=$2"="$3;$3="";sub(/#.*/,"");print}}' KMC.sh)
     mpirun -np 4 ../../SRC/${EXE}

On personal computers go to directory with the input and in the terminal
copy-paste the fist line and type the second one according to your
executable path. More details about the examples are given in the
`ReadMe` file in `EXAMPLES` directory.

# Output

There are a number of files created during the execution of k-ART.
Details on the content of each file is given at the end of this manual.
Here is a simple description.

1.  provides a global summary of all simulation details, including
    parameters, code version, the date of the compilation and a number
    of used in the simulation as well as the basic simulation time as a
    function of event.

2.  `Sortieproc.xx` files are the log files for each core running the
    simulation (labelled from 0 to N-1, where N is the number of cores
    being used). These give explicit details about each step of the
    simulation. The MASTER is always labelled 0 (sortieproc.0) and all
    other cores are WORKERS.

3.  Output files where data for further analysis have a `.dat`
    extension:

    1.  `Energies.dat` lets you see the number of KMC step, CPU times,
        simulated times, activated barrier executed. It is contains the
        basic information about the evolution;

    2.  `Diffusion.dat` provides information on the mean squares
        displacement with the initial configuration as a reference;

    3.  `selec_ev.dat` provides information on the event chosen by the
        code at each KMC step.

    4.  `Gen_ev.dat` and `Spec_ev.dat` give respectively information on
        creation of generics and specifics events.

4.  Files `Topologies` and `topos.list` are a exhaustive list of all the
    the topology keys observed during the simulation.

5.  `allconf`s give us the possibility to visualize the spatial
    evolution atoms of the system during the
    simulation.(`allconf_defect` for example let us visualize only atoms
    in a noncristaline topology)

6.  Multiple `event_list_conf_x.dat` files provide a list of all the
    topologies and events present in configuration x.

7.  Finally, `events.uft` is an unformatted fortran file listing all the
    event of the simulation and the folder `EVENT_DIR` which describe a
    readable equivalent of `events.uft`

# Rerun a previous simulation

You can use results from a previous simulation in two ways: launching a
new simulation using an already computed catalogue or continuing a
previously stopped simulation.

## Using a previously computed catalog {#sub:using_a_previously_computed_catalog}

It is always possible to continue a previous simulation once you have a
completed event catalogue. For this, you need two files:

`event.utf` and `topos.list`

It is also necessary to modify the following parameter in the
environment file.

        setenv  RESTART_IMPORT   .true.

## Continuing a previous simulation {#sub:continuing_a_previous_simulation}

To pursue a run, the following files are needed :

::: {.center}
  ---------------- -- --------------
   `initial.conf`      `topos.list`
    `this_conf`        `events.utf`
  ---------------- -- --------------
:::

Other files will be appended so they can be left in the directory. It is
suggested, to avoid problems, to simply copy all files into a new
directory and launch from it.

In any case, the following parameters also need to be set to true in the
environment file:

        setenv  RESTART_IMPORT   .true.
        setenv  RESTART_KMC      .true.

# Units {#sec:units}

Units are, in principle, defined by the forcefield. k-ART, per se, is
takes the forces and updates the positions accordingly.

However, most parameters provided initially for convergence to saddle
points and minimization are optimized for energies in eV and
displacements in Å. It is therefore simpler, but not essential, to use
these units. At the moment, it only takes `kcal2ev`, but it is
straightforward to expand this.

A command is provided to convert energy units to eV :

      # Converts the energy units provided by the force code into a desired value for ART
      setenv UNITS_CONVERSION      metal 

# User guide

This section offers simple explanations for the most important
parameters defined in the `KMC.sh` file.

## Launching k-ART simulation {#sub:launching_k_art_simulation}

Before launching a k-ART simulation, it is necessary to determine the
length of the simulation, either in number of steps (`NBRE_KMC_STEPS` )
or in total time spent (`TOTAL_TIME`). The simulation will stop when the
first of these two occurrences is met. Default values for these two
quantities are large and it is recommended to fix at least one of the
two.

It is also necessary to set the `TEMPERATURE`. It is defined in Kelvin
(considering that internal energy units are in eV). There is no default
value and it must be set.

    setenv NBRE_KMC_STEPS   100   # Max number of KMC steps to be executed (def: 50 000)
    setenv TOTAL_TIME       1.0   # Maximum simulation time in seconds (def: 20 s)

    setenv TEMPERATURE      600.0 # Simulated temperature in kelvin (no def)

    setenv ELAPSED_TIME     0.0   # Elapsed time before first KMC step 
                                  # (will be added to the sim. time) 

Repeating the simulations, specially to find a bug, might be necessary.
For this, it is preferable to start with the same seed for the random
number generator. It can be fixed with the following command. When not
defined, it is extracted from the computer clock.

    setenv Random_seed  -1103   # Random number generator see (use only when debugging)

## Describing the simulated system {#sub:describing_the_simulated_system}

The description of the simulated system includes, of course, its size,
number of species, box type and the force field used to describe it.

### Details of the system: atomic types and active/inactive species

    setenv NUMBER_ATOMS      1018    # Total number of atoms 
    setenv NSPECIES          2       # NUmber of atomic species (default: 2)
    setenv ATOMIC_SYMBOLS  "Fe C:active Ni:inactive" # Atomic symbols of atoms used in the  
                                                     # simulation, they must be given in
                                                     # the same order than in the potential.

    setenv ATOMIC_TYPE_FILE   'Atomic_types'  # List of atomic types (read at start of sim) 
                                              # (def: Atomic_types)

We can set the atomic symbols using the the string `ATOMIC_SYMBOLS`. It
is set as a list with the names of each atomic symbol. Also we can say
if each atom type is *active* or *inactive*, that is, if to launch for
researching of events on it or not. We can type for example: "Fe\" (or
"Fe:active\", although by default all elements are active, so this is
not necessary) and if inactive: "Fe:inactive\". As another example, in
Si-H, the H could be declared *inactive* such topologies are never
centered on it as the relevant moves involve Si rebonding.
`ATOMIC_SYMBOLS`\" can be set to a string of a Maximum of 30 atomic
symbols.

If the list becomes large we can use the file *Atomic_types* which also
contains the name of the atomic species as well as whether they are
*active* or *inactive*. If neither of these variables are set, default
values are used. If both are used, the *Atomic_types* is used. Comments
can also added to this file by starting the line with \#. The format of
the *Atomic_types* file is the following (see the `Si-H` directory in
`EXAMPLES`):

      # Atomic name,       state (launch for search of events on it if active)
       Si active
       H  inactive

### Maintaining different subgroups of the same element as active or inactive

In some cases, it is useful to select as active only a subset of all
atoms of the same species. To do so, simply give different names to the
various subsets of the same element. For example, with three regions for
a block of silicon. In `KMC.sh` write:

      setenv NSPECIES              3     # The number of different atom types (default: 2)
      setenv ATOMIC_SYMBOLS        "Si Sit:inactive Sib:inactive"

For `lammps`, you will need to modify the potential. For example, for
Silicon:

      pair_style sw
      pair_coeff * * Si.sw Si Si Si

and define the masses

      1 28.0855
      2 28.0855
      3 28.0855

### Soft or strict activity

By default, the code uses so-called "soft activity", i.e. no event are
launched from *inactive* species but events can be recentered around
these atoms.

Setting `SOFT_ACTIVITY` to `.false.`, no event can be centered on
*inactive* atomic species, even if the initial deformation was made on
an *active* atom. This, however, can create problems when, for example,
the displacement of the interesting species involves the motion of
inactive species on the same scale. This setting can be made by
inserting the following into KMC.sh:

**Note: This option biases the kinetics and must be used carefully.**

A system might use both soft and strict activity for different atom
types. For example, if a big systems has many atoms that never will be
moved by events thoughout the whole simulation, these atoms can be
declared strictly inactive to not analyze their topologies and therefore
speed up the simulation's initialization time. If also certain atoms
won't yield relevant events, they should be declared softly inactive.\
This can be achieved by not using the `SOFT_ACTIVITY` option and having
an *Atomic_types* file as follows:

      # Atomic name,       state (launch for search of events on it if active)
       Si active
       H  inactive
       C  strictlyinactive

Now, C behaves as if under the option `SOFT_ACTIVITY .false.`, H as if
`SOFT_ACTIVITY` was `.true.`, and Si is active.

The keyword "strictlyinactive" does not work in `ATOMIC_SYMBOLS` yet.
This should be implemented in the future and, for better consistency,
the option `SOFT_ACTIVITY` should probably be removed.

### Box size and boundary conditions

Currently, k-ART allows orthorombic as well as triclinic boxes with
periodic conditions in all directions. The box size is defined in length
units and should be the full box size.

For a cubic box, simply use `SIMULATION_BOX`. For other boxes, it is
necessary to specify the box length for each direction separately. When
simulating a surface, for example, simply use a very large `Z_BOX`

    setenv SIMULATION_BOX    29.0638147  # Size of the simulation box (x, y and z)

or

    setenv  X_BOX  28.02    # Simulation box size in the x dimension
    setenv  Y_BOX  14.17    # Simulation box size in the y dimension
    setenv  Z_BOX  68.45    # Simulation box size in the z dimension

These parameters may also be defined in the k-ART input configuration
file. For a parallelipedic box, only one line is needed after the energy
line. The terms represent, respectively, the size of the box in the x, y
and z directions.

    total energy:        -2213.34826631256
         21.7200000000000     21.72000000000     21.7200000000000

However, when simulating a triclinic box, three lines are needed. The
triclinic parameters matrix is defined following the LAMMPS formalism.
The documentation can be found on the
[](http://lammps.sandia.gov/doc/Section_howto.html#triclinic-non-orthogonal-simulation-boxes)

    total energy :     -2213.34826631256
         21.7200000000000     1.000000000000     2.00000000000000
         0.00000000000000     21.72000000000     3.00000000000000
         0.00000000000000     0.000000000000     21.7200000000000

When using lammps (ENERGY_CALC set to LAM), these parameters are not
needed as the box size is already defined in the input of Lammps; so you
can safely comment these lines. If they are defined they will be
ignored. You may use the following format to input the boxe size to
LAMMPS in the LAMMPS input configuration file. For an orthorombic box,
the three lines after the number of atomic types line are needed. For a
triclinic box, the four lines, including the xy, xz and yz term, are
needed.

    511 atoms
    1    atom types
    0.0 21.72 xlo xhi
    0.0 21.72 ylo yhi
    0.0 21.72 zlo zhi
    1.0 0.0 0.0 xy xz yz

## Choice of forcefield/neighbour lists {#sub:choice_of_forcefield}

A few potentials are directly implemented in k-ART

1.  Stillinger-Weber with the original parameters (SWP) or the modified
    ones by Vink *et al.* for simulating amorphous silicon (SWA);

2.  The EDIP potential, still for silicon (EDP);

3.  The MEAM potential, implemented by Noël Jackse for Si/Au (MEA)

4.  The EAM potential used for simple metals (EAM).

5.  A mixture of modified Stillinger-Weber potential coupled with a
    Slater-Buckingham for H-H interactions. This is not great for H
    diffusion (SIH) (see Ref. [@mousseau90]).

Of those, only Stillinger-Weber is program both with a global and local
calculation of forces.

When those forcefields are not sufficient, it is possible to turn to
LAMMPS to access its vast set of forcefields. To do so, one has to
select the `LAM` option for `ENERGY_CALC` and to provide the appropriate
*LAMMPS* input file.

LAMMPS works in a number of different energy and length units. Even
though k-ART does not formally care, all default parameters are defined
for eV/Å set of units. If the potential is in kcal, it is possible to
change it directly at the k-ART level. Other options can be implemented
but are not at the moment.

        System                      Potential                  Command   Neighbours
  ------------------ ---------------------------------------- --------- ------------
       silicon                   Stillinger-Weber                SWP     TTL or PAR
                                   Modified SW                   SWA     TTL or PAR
                                       EDIP                      EDP        TTL
        metals                         EAM                       EAM        TTL
      Si/metals                        MEAM                      MEA        TTL
   silicon/hydrogen   Stillinger-Weber and Slater-Buckingham     SIH        TTL
       generic                        Lammps                     LAM        TTL

pt

    setenv ENERGY_CALC        SIH     # choose between EDP, SWP, SWA, SIH or LAM (Lammps)
    setenv FORCE_CALC         TTL     # choose TTL (total force) or PAR (partial force)

    setenv INPUT_LAMMPS_FILE  'in.lammps'  # LAMMPS input file when ENERGY_TYPE = LAM 

    setenv UNITS_CONVERSION  metal    # Converts the energy and distance units 
                                      # to ensure eV and Angstrom in kART

When using an internal potential, it is also necessary to parametrize
the neighboring list. These options are dependent on the type of
forcefield (global or local). Except for Stillinger-Weber, it is
therefore necessary to select : `TTL` or `VER`.

    setenv UPDATE_VER_NEIB   TTL      # TTL for total force or PAR for partial force
    setenv NEIB_CALC         ALL      # ALL or VER
    setenv UPDATE_TOPO       TTL      # TTL or PAR

    setenv PAR_DISP_THRESH2  0.00001  #max displacement squared which triggers an update of
                                      # neighbor list with VER (default: 0.00001)

## Managing output: options and file names {#sub:managing_output}

## Restarting {#sub:restarting}

It is possible to restart and extend a simulation. This simulation can
start from the last point, using the catalogue already computed or
reconstruct one if there are problems with the one at hand.

It is also possible to start a *new* simulation using a previously
calculated catalog. In this case, one has only to start with
`RESTART_IMPORT` set to `.true.`

By default, all these options are set to `.false.`

In particularly large or complex systems building the initial catalog
can be expensive. Moreover, if the simulation is interrupted during the
construction of the catalog kART will have to restart it from nothing.
To have the possibility to build the catalog in multiple runs the
following parameter in the environment file must be set to true (in the
initial run).

        setenv  SAVE_SEARCH_LIST      .true.

This will write the formatted text file `search_list.txt`. To resume
building the catalog in a subsequent run the following parameter must be
set to true in the environment file:

        setenv RESUME_BUILD_CATALOG   .true.

## Basin parameters {#sub:basin_parameters}

KMC methods are limited in time by the lowest-energy barrier available
at any time. When this low-energy leads to a state with a significantly
lower energy, it belongs to the kinetics of the systems. However, these
low-energy barriers often connect non-diffusive states of similar
energy, i.e., states that do not lead to the structural evolution of the
system. Such states are called *flickers* and represent the bane of KMC
simulations.

In kinetic ART, we handle both types of events specifically.

### Low-energy barrier events

Very low-energy barriers leading to lower-energy states could be handled
directly, without going through a KMC choice. Indeed, these barriers
typically involve time scales of 10$^{-10}$ to 10$^{-13}$ s and so do
not influence the time scale for the problem typically studied with
k-ART. There is therefore no impact in applying them directly. The
advantage would be that doing so decreases considerably the cost of
handling these low barriers, allowing us to focus on the kinetics of
interest.

**Further improvements: very low-energy barriers.**

At the moment, the whole catalog of generic events is constructed before
applying a move to the lowest energy barrier (i.e., below the threshold
for real KMC). In some disordered systems, it could be preferable to
perform the moves as these low barriers are met and to update the
catalog only when no new very low-energy barrier are found.

This is yet another modification that we are planning for k-ART in the
near future.

### Flickers

There are many ways to handle these flickers. In k-ART, we use the
autoconstructing basin mean-rate method (bac-MRM), a modified version of
the mean-rate method proposed by Puchala *et al.*. [@puchala]. It is
described in some details in Ref. [@beland2011].

    setenv OSCILL_TREAT    BMRM    # choose between BMRM, TABU or NON
    setenv MIN_SIG_BARRIER  0.1    # Max height of dir. and inv. barrier for an event 
                                   # to be considered inside a basin
    setenv BASIN_LOCAL     .false. # If true, local basins are used (default: false)
    setenv BASIN_RADIUS    10.0    # If using local basin, radius of a local move 

We have also implemented a *TABU* algorithm. However, for many systems,
this algorithm biases significantly the kinetics and we do not really
recommend it. A description of the method can be found in
Ref. [@vocks2005; @chubynsky2006].

The following environment parameter define its use.

    setenv OSCILL_TREAT   TABU       # choose between BMRM, TABU or NON
    setenv FLICKER_DIR   'FLICKERS'  # Directory where the TABU event files are stored
    setenv EVENTS_MEMORY   100       # Number of stored event TABU (default: 100)
    setenv BASIN_MEMORY    10        # Number of stored basins for TABU (default: 10)

### Manually adding basin events

In some cases, it is helpful to add events with high energy barriers to
a basin. For example, it can happen that a system flickers between two
states connected by a large $\Delta E$ because any other event has
significantly higher barriers. Treating this transition as a basin
solves this. When using BMRM, it is possible to load a file with the
default name `Event_basin` and the following structure:

       #  initial         saddle       final 
          1247195         80279       1247195  
       ...

The file name can be changed with

    setenv EVENT_BASIN_FILE       Event_basin # File that is read for additional basin events

Using this file means that events will be basin events that have energy
barriers below `MIN_SIG_BARRIER` or topologies from the list or both.
The reverse event to any list entry will automatically be considered.

### Basin auto analysis

Because it can be tedious to manually add events to the event basin
file, there is the basin auto analysis. Its parameters are

    setenv BAA_STEPS          3       # Number of steps analysed (default 0)
    setenv BAA_RADIUS         0.3     # Radius for atom to move in, in angstrom (default 0.3)
    setenv BAA_MONITORED    100       # Particle to be monitored for the analysis
                                      # (default NUMBER_ATOMS, i.e. the last atom)

The method remembers the last $N=$ `BAA_STEPS` positions of the atom
with identifier `BAA_MONITORED` and if all of these positions lie within
a sphere with radius `BAA_RADIUS`, the event last executed will be added
to the `EVENT_BASIN_FILE` file. If the parameter `BAA_STEPS` is not
given or identical to 0, the basin auto analysis is disabled.

## Topological identification of local geometries

K-ART relies on the assumption that we can identify the local geometry
around each atom in the system by looking at the topology. K-ART works
by generating the connectivity graph of a cluster of atoms centered on
the target atom. While k-ART has functions to deal when this one-to-one
correspondence between geometry and topology breaks down, it is
important to choose well the parameters used to construct the
connectivity graph. A topology label is associated with each
connectivity graph to identify it.

Two file names can be defined for the outfile statistics regarding
topologies. These files are not used for restarting.

      setenv TOPOLOGY_FILE  'Topologies'      # Store info about topologies 
      setenv TOPO_STAT_FILE 'topos.list'      # Store statistics about topologies 

### Defining graph size: `MAX_TOPO_CUTOFF`

The three parameters used defining the graph size are:

`MAX_TOPO_CUTOFF`, `TOPO_RADIUS` and `MAX_NODES_GRAPH`.

`MAX_TOPO_CUTOFF` defines the maximum distance for which 2 atoms are
considered connected. This value is the same for all atom types. A good
value of `MAX_TOPO_CUTOFF` usually can be found by looking at the radial
distribution function (RDF) of the system. The value should generally be
between the 1st and 2nd peaks. It is important that minute variations in
bond length do not affect the connectedness of two neighboring atoms. In
fact, this is good because the program will be able to identify the same
structures even if the actual bond lengths vary slightly. It is easier
to find this value in crystalline systems since the RDF has well defined
peaks. It is more difficult in amorphous systems, where there is no
clear separation between the peaks. Even so, choosing a value where the
RDF is a minimum between the 1st and 2nd peaks was found to be optimal.

In the case where k-ART cannot recover the geometry from a topology
label, it does what we call splitting the topology. In this case, the
original topology label is called the primary label and we associated
with it secondary labels by changing the cut-off used to connect atoms.
The parameter `MIN_TOPO_CUTOFF` determines the smallest cut-off value
used. Each time the topology is split, the cut-off will be reduced from
its original `MAX_TOPO_CUTOFF` by a distance of

(`MAX_TOPO_CUTOFF`-`MIN_TOPO_CUTOFF`)/10

and a new topology label is calculated. This is done until a different
topology label is found. The value of `MIN_TOPO_CUTOFF` should not
ideally be smaller that the minimum bonding distance observed but small
enough so that the connectivity distance changes enough to find new
topology labels.

### Improvement for alloys: Multiple `MAX_TOPO_CUTOFF`

You may also define multiple cutoff distances between atoms for
multi-atomic crystals.

In this case, these may be defined directly with both the
`MAX_TOPO_CUTOFF` and `MIN_TOPO_CUTOFF` in the environment file:

    setenv MAX_TOPO_CUTOFF       "2.0 3.2 2.5 2.7 2.9 3.1"
    setenv MIN_TOPO_CUTOFF       "1.8 2.9 2.1 2.5 2.6 2.7"

The cutoffs can also be placed in a separate file defined by the
environment variable `TOPO_CUTOFF_FILE`. If this variable exist, it
supersedes the `MAX_TOPO_CUTOFF` and `MIN_TOPO_CUTOFF` variable. In the
file, the first line represents the `MAX_TOPO_CUTOFF` values and the
second the `MIN_TOPO_CUTOFF` ones:

    "2.0 3.2 2.5 2.7 2.9 3.1"
    "1.8 2.9 2.1 2.5 2.6 2.7"

For a crystal with two atom types, the format is 1-1, 1-2, 2-2 cutoff
lengths. For a crystal with three atom types, as shown in the above
examples, the format is 1-1, 1-2, 1-3, 2-2, 2-3, 3-3 cutoff length. The
same logic applies for crystals with more atomic types. Note that with
both methods the cutoffs lengths must be defined between quotation
marks.

### Defining graph size: `TOPO_RADIUS`

The second important parameter is `TOPO_RADIUS`, which defines the
radius of the sphere centered on the target atom that is used to include
neighboring atoms in the graph. The larger the sphere, the more atoms
are included and the more complex the graph is. A too small value will
result in a graph that does not properly correlates with the local
geometry. A too large value will result in clusters that are too
specific and include atoms situated far away that do not affect the
transition states centered on the target atom. We find that in *c*-Si
and *a*-Si, a value of 6 Angstroms works well. Note that as the volume
of this sphere increases, so does the probability of having atoms near
the edge of the sphere. These atoms' positions can fluctuate in and out
of the surface and change the number of atoms in the graph, resulting a
multiple changes in the topology. Again, the program will work but will
be less efficient because for each new topology, a new series of
(redundant in this case) event searches are launched.

      setenv   TOPO_RADIUS      6.0   # by default, set to 6 Angst.
      setenv   MAX_TOPO_CUTOFF  2.8   # maximum length cutoff
      setenv   MIN_TOPO_CUTOFF  2.2   # Also sets a minimum distance

### Further improvements for alloys: `MAX_NODES_GRAPH`

The cut-off defining the limits of a graph used in the topological
classification is not ideal for an alloy. In this case, particularly
when the atomic size varies greatly, it would be preferable to use a
fixed number of atoms around the center.

This is possible with the command `MAX_NODES_GRAPH`, which imposes a
maximum number of nodes (atoms) to the graphical analysis. To use this
command, you first must set a cut-off size for `TOPO_RADIUS` that
corresponds to the correct size of a cluster containing only your
biggest atom (which would have the lowest number of atoms for a given
radius).

You can then use `MAX_NODES_GRAPH` to impose a maximum number of nodes
(atoms) for the graph.

      setenv   MAX_NODES_GRAPH  42

To optimize these parameters, it is best to first run kART on a system
with only the largest species and to identify the size of the graph
corresponding to `TOPO_RADIUS`. Look, for this, into the `sortieproc.0`,
which gives the cluster size (number of nodes) for the largest atoms.

    Fetching topology label for atom:      1( cluster size:  45)
     Topology has changed :       0-->  617416
     Assigning topoId      617416 to atom           1

Here, for example, setting `MAX_NODES_GRAPH` to 45 would ensure that
most clusters have a similar size, facilitating classification and
cataloguing

### The special case of random alloys: `UNIQUE_CRYST_STRUCT`

In the case of an alloy whose atoms are randomly distributed on the
lattice sites, without any short or long range order (solid solutions
for example), the crystallinity should not depend on the atom types but
only on the positions of the atoms. The default calculations in kART are
not performed this way but one can decide to make the crystallinity
check on atomic positions only by setting:

        setenv   UNIQUE_CRYST_STRUCT = .true.

By doing so, even if the topologies id found by kART do not correspond
to the `CRYST_TOPOID` given as a parameter, if they are structurally
equivalent they will be considered as crystalline and will be ignored.

### Leaving some topologies aside.

K-ART's performance is proportional to the number of different
topologies in the system and not necessarily with the number of atoms.
However, to avoid spending time on environments where no event is
expected, such as perfectly crystalline regions, it is possible to
remove these events from the catalog.

One way to do this is to include the file `Topo_ignore` in the
simulation directory. This file should contain the topology labels (one
per line) associated with region to be ignored.

The previous solution is applicable to neglect any type of topologies.
To avoid spending times on barely non-crystalline environments (i.e.
those with a defect at the edge), it is also possible to set, in the
environment file, up to five crystalline topologies along with a small
cutoff for ignoring them. Either or both of them can be left out if not
needed.

The use of many crystalline topologies is useful in the case of an
ordered compound, for example.

To get this label, it is necessary to run k-ART on a perfect crystal,
for example, with `TOPO_RADIUS` set to the same value of
`CRYST_TOPO_RADIUS`. Run for some seconds, and from *sortiproc.0* go to
line "`Listing topologies in system`\", and get the number (if system is
not perfect crystal, the most repeated number is the `CRYST_TOPOID`).
IMPORTANT: After this, reset `TOPO_RADIUS` to its previous value and
check that the crystalline topology is already removed by rerunning.
Then, in *sortiproc.0* at the end of "`Listing topologies in system`\",
look for "`topo has no events x`\". Verify that the number $x$
corresponds indeed to the crystalline topology (realize that $x$ is
different to the number set in `CRYST_TOPOID` as `TOPO_RADIUS` is
reset).

Note that all new topology labels are written in the *topos.list* and
Topologies files. The file *topo_stat.dat* keeps track of the statistics
associated with topology labels per KMC step.

### Leaving specific events aside

In some cases it is good idea to ignore some problematic events. There
are two ways to do this.

If an undesired events (sometimes an error) has popped in the catalog,
then it might be useful to remove it. This is achieved by creating a
filed called `Event_remove` that contains the list of all undesired
events. It has the following structure.

      # Event id (one per line)
        330236
        576443
        ...
        576443

where the numbers can be found, for example, in the `event_list_xx`
files.

Because it removes the events from a previously constructed catalog, it
needs the file .utf@ in order to work. If there is no previous catalog,
the code will crash.

Now, it is also possible prevent given events to be stored in the
catalog. Because the events ids are not uniquely defined, it is then
necessary to define the events in terms of their topological identifier
at the initial, the saddle and the final states. To allow for further
distinction (for example, a rare, but unrealistic events that involves a
jump to the second neighbour site but through the same saddle point), it
is also necessary to define a minimum displacement threshold. Any event
involving the same topologies but with a smaller displacement will not
be ignored.

The default file name is `Event_ignore` and has the following structure

       #  initial         saddle       final      min_dr
          1247195         80279       1247195      0.0
       ...

For both files, comments can be added to that file using the character
`#` at the beginning of line.

## Activated Event generation

For each topology label found, k-ART launches a series of ART nouveau
searches to find all the activated events. The events associated with a
topology label are called **generic** events. K-ART assumes that all the
atoms sharing the same topology label have the same **generic** events.
While the actual values of the activated energy and displacements can
change slightly atom to atom, they all have them.

The important non-ART nouveau parameters for the **generic** event
generation are `SEARCH_FREQUENCY` and `USE_LOG_SEARCH`. These control
how many event searches are launched per topology. If `USE_LOG_SEARCH`
is false, then this number is simply `SEARCH_FREQUENCY`. If
`USE_LOG_SEARCH` is set to `true` (default value), then the number of
searches launched are a function of how many times we have seen this
topology before. The number of searches is calculated every turn and is
equal to

$$\label{log_searches}
 max(SEARCH\_FREQ \times (1 + \log_{10} (COUNTS)) - ATTEMPTS, 0)
%SEARCH\_FREQ \times (1 + \log_{10} (COUNTS)) - ATTEMPTS
%a = b$$

where $COUNTS$ is the number of times the topology has been seen and
$ATTEMPTS$ is the previous number of event searches launched. This
logarithmic search function is used so that topologies seen more often
are searched more. Moreover, topologies are also searched multiple times
during a simulation (and not just when first found), albeit less and
less often.

All **generic** events found are written to a binary file called
*events.uft* by default. This file can be reused to restart a simulation
or to start a new one. The topology file *topos.list* also needs to be
provided. If the parameter `USE_TXT_EVENTFILE` is set to true, a folder
called *EVENT_DIR* will also be created and a text version of the event
files will be created during the simulation. Note that in the TOOLS
directory, the program *kART_uft2txt.f90* is provided. This stand-alone
program can convert an *events.uft* file to text format for
visualization purposes (see the *READ_ME.txt* file).

### Generic events  {#ssub:generic_evenst_}

Generic events are stored in the catalog. They are used to construct, at
every step, the specific events that are put in the KMC tree.

Every time a new topology is found, a search is launched to associate
generic events with this topology. The number of searches is defined by
`SEARCH_FREQUENCY`.

As a topology is found more often, new searches are made to minimize the
probability of having missed an important barrier. This is done on a
logarithmic scale, i.e., the number of addition searches is given by the
logarithm of a topology's occurrence multiplied by `SEARCH_FREQUENCY`.

### Specific events

When arriving in a new minimum, k-ART first updates its list of
topologies and completes the list of generic events.

All generic events contributing to 99.99 % of the rate (or defined by
xxx) are reconstructed for specific configurations, with the saddle
points fully relaxed. This ensures that elastic and geometric effects
are fully taken into account

A number of environment variables relate to the reconstruction and
relaxation of specific events. In general, the default values can be
set.

However, for topologies with high symmetries (e.g. relaxed interstitial
in a crystalline environment), there can be problems with the mapping of
the events onto the system. For $n$-fold symmetry, the chances of
correct mapping are $1/n$. If in the sortieproc.0 file there is "Mapping
\... failed", it can help to increase the parameter `REFINE_ATTEMPTS` to
for example $N = 50$, reducing the overall probability of mapping
failure $(1-1/n)^N \ll 1$. Increasing `REFINE_ATTEMPTS` comes at almost
no cost.

### Event analysis  {#ssub:event_analysis_}

## Using local forces for accelerating simulations of large systems

Because events are intrinsically local, it is not necessary to compute
the force on all atoms to generate generic events when the box is
sufficiently large, since these will be further refined, taking full
account of the complete system, when relevant.

In this case, kART can therefore compute forces only on a limited subset
of atoms, independently of system size, which can considerably
accelerated the generation of a catalog and even the relaxation of
specific events as described below.

In the next subsection, we describe the parameters associated with this
option. In the following one, its implementation.

### Selecting parameters

The option `LOCAL_FORCE` determines the use of local force. By default,
this option is turned down.

When this option is , the global simulation box is cut into cells of
width defined by `CELL_LENGTH`. The same length is used in all
directions, irrespective of the box size. In general, as explained below
this length should be of the order or larger than the potential cut-off.

The second option, `REGION_WIDTH`, defines the number of cells included
in the local region on *each side* of the central cell. For example, if
`REGION_WIDTH` is set to 2, the total length of the local region for
force calculations is 5 cells (2 on each side plus the central cell).

This allow the selection of a *spherical* region around the central atom
defined with a first *inner* region with a radius of ( 2\*REGION_WIDTH
-1)/2 followed by an *outer* shell of width REGION_WIDTH to
(2\*REGION_WIDTH+1)/2.

Since, the local region is set-up with open boundary conditions, as
shown in Fig. [\[fig:local\]](#fig:local){reference-type="ref"
reference="fig:local"}, forces on the atoms in the outer shell cannot be
used. This is why, only atoms in the inner sphere are considered for
activation and relaxation. This explains why it is recommended that the
`CELL_LENGTH` be at least as long as the potential cut-off (or, at
least, sufficiently large to ensure that the local-region's boundary
does not affect the results.

If `REGION_WIDTH` is set to 2, as per default, this means that the inner
core, where atoms can move with local forces, is 3 cells large. When
elastic deformation is more long range, it might be necessary to
increase the region width.

Adapt these parameters if the saddle points found with local force are
systematically lost during the final global force convergence.

To check that what these parameters do, the outputs show the number of
atoms in the local region : `nat_inner`, `nat_outer` and
`nat_local = nat_inner + nat_outer` are printed every time a local
region is defined.

Similarly, the convergence to saddle point for specific events indicates
whether local or global forces are used, allowing a check on the
validity of the local region.

If there is little change between saddle points found after local and
global convergence, or if you do not need high accuracy on the saddle
point, you might disable global convergence at the saddle (global
convergence is still used at the final minimum). In this case, set
`GLOBAL_CONVERGENCE` to .false.@

[\[fig:local\]]{#fig:local label="fig:local"}

For large box, it might be difficult to converge the eigenvalue and
eigenvector surrouding a local deformation because of the way the
initial random vector in the Lanczos calculation is set up. To
circumvent this problem it might be useful to set `LOCAL_LANCOS` to
true. In this case, global forces are systematically used, but the
initial deformation for construction the Lanczos matrix is done on a
local region defined by the same parameters ass for `LOCAL_FORCE`.

### Implementation

When set-up, local forces are used for finding all generic events. In
LAMMPS, the local region is positionned in the same box as for the full
system and atoms are not recentered. Periodic boundary conditions
determined by the large box are used to ensure the continuity of the
local region, allowing the algorithm to work even when there are
surfaces and interfaces in the original box.

Convergence of specific events is also first done with local forces,
once the local force is below threshold, convergence is relaunched with
global forces, using the eigenvector obtained with local forces as seed.

## Breaking the kinetics : approach to get specific results

Kinetic ART implements a number of approach that break the correct
kinetics but allow to generate specific desired events. While, these
cases, the kinetics and the sequence of events may be wrong, it can
provide useful information difficult to obtain otherwise.

The following options are possible:

### Active/inactive species

### Additional conditions

### Remove detailed balance

### Direction pathway

# Generating events : ART part {#sec:generating_events_art_part}

## Activated Event generation: ART-nouveau

ART nouveau parameters (more).

EVENT analysis

## Refining low barrier events

To take into account the elastic deformations present in the system,
k-ART refines events with small activation barriers (and large
associated rates) on each atom sharing the same initial topology. The
program insures that at least the low barrier events with a cumulative
rate compromising 99.99% of the total rate are refined. These refined
events are associated with a specific atom and are called SPECIFIC
events. Each SPECIFIC event replaces the original GENERIC event.

The parameters

# Using LAMMPS

It is necessary to have

`atom_modify map array`

# Detailed content of output files {#sec:detailed_content_of_output_files}

1.  Files *event_list_conf\_$n$* located in the *EVLIST_DIR* provides a
    exhaustive overview of the available transition of the simulation
    that leads to the KMC step $n$ for the local minimum $n-1$. It
    counts 11 columns

    (1) TypeId : Atomic type (be careful type does not mean chemical
        element i.e. Si1 Si2 are to different type of Si).

    (2) AtomId: Id of the Atom.

    (3) TopoId: Topology of the local initial minimum.

    (4) EventId : Generic Event Id.

    (5) Spec_id: Specific Event Id.

    (6) barrier: Refine or reconverge or clone energy barrier (in eV)
        see last logical column.

    (7) inv_bar: Refine or reconverge or clone energy of inverse barrier
        (in eV) see last logical column.

    (8) asy_ener: Difference between barrier and inv_barrier

    (9) inisad_dr: displacement between saddle and initial
        configuration.

    (10) inifin_dr: displacement between final and initial
         configuration.

    (11) noname logical: if true means the event was refined or
         reconverged otherwise it was cloned.

```{=html}
<!-- -->
```
1.  The file *Energies.dat* provides a general overview of the evolution
    of the simulation. It counts 8 columns with each row providing the
    information for each minimum of energy $E_{Min}^n$ reached at step
    $n$):

    (1) Number of KMC step $n$.

    (2) CPU time.

    (3) Old minimum Energy $E_{Min}^{n-1}$.

    (4) New minimum energy $E_{Min}^n$.

    (5) Activation Energy or Energy barrier (or saddle energy minus the
        energy of the initial minimum) that is selected by kART from the
        list of all available events from this configuration, i.e.,
        $E^n_a=E^n_{Sad}-E_{Min}^{n-1}$.

    (6) Total rate sum of all the transition rates $\sum_i r_i$ that are
        extracted from the activation energy base on the transition
        state theory $r_i = \tau_0 e^{-E ^i_a/k_BT}$, at each step $n$.
        If a value of 0.0 is found, it means that the mean rate method
        (MRM) has been used for leaving a basin (in this case, the
        minimum energy shown in column 3 will not correspond to the
        value of column 4 at the previous step because internal dynamics
        in a basin is lost).

    (7) Time step (e.g., $\Delta t=-\ln \mu/ \sum_i r_i$, where $\mu$ is
        a random number in the interval $(0,1)$).

    (8) Simulated time (it is the accumulative sum of the previous time
        steps).

    (9) Selec Ev, id of the generic event selected for transition.

    (10) Init Topo, id of the initial topology.

    (11) Sad Topo, id of the saddle topology.

    (12) Fin Topo, id of the final topology.

2.  The file *Diffusion.dat* gives the information on the mean squares
    displacement with respect to the the initial configuration. It is
    displayed info on 4 columns:

    (1) Elapsed Time, time step $t_n$.

    (2) Sqr Displ, total square displacement,
        $\hbox{{\it SD}}(t_n)=\sum_{i=1}^N  \left(r_i(t_n)-r_i(0)\right)^2$,
        of $N$ atoms at $t_n$. If several atoms, the column is splitted
        into several subcolumns where the first is the Total *SD* of the
        system, the second is *SD* of the atoms of type 1, third is the
        *SD* of atoms of type 2, etc (the type order is the same as in
        the input file with the coord).

    (3) KMC step, is the step $n$.

    (4) Event delr, sum of the displacement from initial, $r^{ini}$, to
        final position, $r^{final}$, of the atoms that moved during the
        transition, that is, delr
        $=\sqrt{\sum_{i=1}^N  (r_i^{final}-r_i^{ini})^2}$. The sum
        usually corresponds to the displacement of the atom that moves
        most during the step; as the others remain at their initial
        positions (for example, if an interstitial, this value
        approximately corresponds to the displacement of the
        interstitial).

3.  The file *selec_ev.dat* gives us information on the event chosen by
    the code at each KMC step.\

    (1) CPU time: real time used to get that step.

    (2) selcBarrier: activation energy or energy barrier, that is
        $E^n_a=E^n_{Sad}-E_{Min}^{n-1}$.

    (3) KMC: number of KMC step $n$.

    (4) EVENT: the generic event selected during the step (same number
        found in file *Energies.dat* ).

    (5) SPEC_EVENT: the generic event executed during the step. For
        example, if the generic EVENT selected is 887554, there is a
        subset of specific events from which one is executed, for
        instance, the number 9 thus we identify it as 887554_9. In
        contrast to generic events, specific events take into account
        local deformations and stresses of the particular configuration
        at that KMC step (see section
        [9](#sec:generating_events_art_part){reference-type="ref"
        reference="sec:generating_events_art_part"}).

    (6) SELEC_ATOM: main atom over the event is executed. It is the atom
        that advances most during the step.

    (7) timestep: as before $\Delta t=-\ln \mu/ \sum_i r_i$, where $\mu$
        is a random number in the interval $(0,1)$.

    (8) SimulT: (Simulated time), it is the accumulative sum of the
        previous time steps.

    (9) Basin ID: The basin ID indicates to thing if we are in a BMRM
        bassin (value $\ne0$) or not (value $0$). the non-value where we
        are in a BMRM bassin increment according to the number of
        different bassin visited. if this value as the same value for
        several following step this means that we are still in the same
        BMRM bassin.

    (10) Basin thresh: maximum height of barrier and inverse barrier for
         an event to be considered inside a basin used in the step as
         set by `MIN_SIG_BARRIER`.

4.  Files *Gen_ev.dat* give us information on creation of generics
    events. To avoid ambiguity, if one read the line at the $i^{th}$
    KMCstep this line represents the statistic about the transition from
    $i^{th}-1$ to $i^{th}$. It has the following information:

    (1) KMC: number of KMC step $n$.

    (2) Number of Generic event search: this is the total amount of ARTn
        search per KMC steps.

    (3) Number of saddle attempts: this is the total number of saddle
        attempts (for each ARTn search there is 10 independent attempts
        to find a saddle point) this column includes the failed and
        succeed attempts. Again per KMC steps.

    (4) Number of saddle found: the is the total number of saddle found
        per KMC steps.

    (5) Generic event found Excluding inverse event: count all
        successful generation of Generic events

    (6) Generic event found Including inverse event: count all
        successful generation of Generic events except the inverse
        Generic event.

    (7) New Generic event found Excluding inverse event: only count the
        one that are not in catalogue.

    (8) New Generic event found Including inverse event: only count the
        one that are not in catalogue.

    (9) Tot GenEv Incl InvEv: Total number of distinct Generic event in
        catalogue.

    (10) Force eval: this is the number of force evaluations for ARTn
         part of the code per KMC steps.

5.  The file *Spec_ev.dat* give us information on creation of specifics
    events.To avoid ambiguity, if one read the line at the $i^{th}$
    KMCstep this line represents the statistic about the transition from
    $(i-1)^{th}$ to $i^{th}$. It has the following information:

    (1) KMC: number of KMC step $n$.

    (2) \# GenEv to Consider: This is the number of Generic event to
        refine into Specific be careful this does not count the
        multiplicity of atoms sharing this Generic event.

    (3) \# of SpecEv to Refine: This is the number of Specific event to
        refine a saddle point contrary to the previous one this does
        count the multiplicity of atoms since it is a Spec event.

    (4) \# of SpecEv to Reconverge: This is the number of Specific event
        to reconverge a saddle point we do reconvergence of SpecEv when
        a previous SpecEv exists in the actual configuration.

    (5) \# of SpecEv to be Cloned: this is the number of event that
        should be cloned.

    (6) Spec Ev found: this is the number of Spec event found.

    (7) New Spec Ev: this is the number of new spec event found.

    (8) Tot SpecEv: this is the total number of distinct Specific event
        in catalogue.

    (9) Thres cloning: this is the energy barrier threshold at which we
        start cloning Generic events.

    (10) Ev Cloned: this is the number of cloned events

    (11) Tot Ev: this is the total number of available events that leads
         to the KMC step $n$.

6.  Files *Topologies* and *topos.list* are a exhaustive list of all the
    the topology keys observed during the simulation. Accordingly to the
    NAUTY the file *Topologies* basically shows:

    (1) topo_labels: topology label or hash key.

    (2) id1, id2, id3: the integers we use as input to a hash function
        to generate a unique topology number (hash key).

    (3) topo cutoff: it is the length-cutoff used by default to link two
        atoms (see input parameters for topology in KMC.sh file).

7.  The file *topo_stat.dat* has information about topologies at each
    step. It gives the following data:

    (1) CPU time.

    (2) currTOPO: is the current total number of topologies in the
        system. Equivalent to "known_tc\" variable in code and in
        sortiproc.0 file, it only increases if the variable `STATISTICS`
        is set to True.

    (3) activeTOPO: number of topologies that are active in the system
        (equivalent to variable "active_tc\" in sortiproc.0 file and in
        the code, it only increases if the variable `STATISTICS` is set
        to True).

    (4) newTOPO: the number of new topologies found at each step. The
        name of the variable in the code is "new_tc\" and only increases
        if the variable `STATISTICS` is set to True.

    (5) searchedTOPO: number of topologies total (all steps). The name
        of variable in the code is "searched_tc\" and only increases if
        the variable STATISTICS is set to True.

    (6) CumulTOPO: total number of topologies found in the simulation.
        The name of variable in the code is "cumul_tc\" and only
        increases if the variable `STATISTICS` is set to True.

    (7) diffTOPO: number of difficult topologies found during the step.

    (8) KMC: step.

    (9) SimulT: total time.

8.  *allconf* files give us the possibility to visualize the spatial
    evolution atoms of the system during the simulation. This file is
    given in XYZ format that can be visualized using for example, VMD,
    OVITO, VESTA, Rasmol, etc, programs. (*allconf_defect* for example
    let us visualize only atoms in a no-cristaline topology)

9.  Multiple *event_list_conf_n.dat* files are found in the dir
    EVLIST_DIR. Each file gives a list of the topologies and events
    found at each step that is used to create the catalog for choosing
    the next step (for example, *event_list_conf_8.dat* has the list
    used to choose the step 8, an other way to say it is that it has a
    list that leads from step 7 to 8). Each file gives the following
    data:

    (1) AtomId: id of the atom.

    (2) TopoId: id of corresponding topology of the AtomId.

    (3) EventId: id of one of the events associated to the the topology
        TopoId.

    (4) Spec_id: id for the specific event, which is used mostly for
        debugging or recovering detailed history of the kinetics. If
        Spec_id $= 1$ it is a generic event otherwise it is a specific
        event.

    (5) Barrier: barrier energy, $E_a=E_{sad}-E_{ini}$, corresponding to
        EventId.

    (6) Inv_bar: inverse barrier $E_i=E_{sad}-E_{final}$.

    (7) Asy_ener: final minus initial minimum energies:
        $E_{final}-E_{ini}$.

    (8) Inisad_dr: displacement from initial to saddle position of the
        atoms that moved most during the event finding, that is
        $\sqrt{\sum_{i=1}^N  (r_i^{sad}-r_i^{ini})^2}$.

    (9) Inifin_dr: same value as "Event delr\" in *Diffusion.dat* or
        displacement from initial to final position of the atoms that
        moved most during the event finding, that is
        $\sqrt{\sum_{i=1}^N  (r_i^{final}-r_i^{ini})^2}$.

10. File *events.uft*, is a unformatted fortran file listing all the
    events of the simulation contained in the folder *EVENT_DIR* (this
    folder contains the same information as *events.uft*, but human
    readable and given in different files). *events.uft* is useful for
    importing the list of events when we want to continue a previous
    simulation.

11. File *topos.list* has technical details of topologies of the system.
    Data is printed in two lines, the first has 6 fields: field one is
    the unique topology label or "hash key\" created from a set of three
    topology indexes given by NAUTY (fields from two to four); the field
    five is the `MAX_TOPO_CUTOFF` and the field six is a flag (`T` or
    `F`), for identifying a topology as a difficult or not. The second
    line has five fields: the first is
    this_topo%count,this_topo%attempts,this_topo%failed_attempts,
    this_topo%ncluster, this_topo%primary_topo_id [ \....STILL REMAINS
    TO EXPLAIN \....]{style="color: red"}

12. File *output.dat* prints a list of parameters and their setting
    values for the particular simulation. This file should be self
    explicative.

13. This file *KMC_log.txt* is a global resume of all the detail
    (physics parameters but also the version number of the code used
    even the date of the compilation) used in a simulation.

14. Finally, *sortieproc.n* files are the log files for each core
    running the simulation (labelled from 0 to N-1, where N is the
    number of cores being used). These give explicit details about each
    step of the simulation. The MASTER is always labelled 0
    (sortieproc.0) and all other cores are SLAVES.

# Tuning the parameters for a particular system {#sec:Tuning the parameters for a particular system}

The default parameters in kART are presented only to give a guide of
that simulation is working. For production the input parameters have to
be tuned according to the particular system in order to reduce the
number of force computations by event found. To understand how to reduce
them (see *evalf* below), we do a first test/run and analyze the output
files *sortiproc.n* (this output is not printed by default, so you have
to set the logical variable `PRINT_DETAILS` to true). Below, we split
the analysis in two steps.

*Leaving the basin*, is the first analysis to do before finding the
saddle point. To understand how to reduce the number of force
computations we analyse the variable *kter*, which counters the number
of iterations for leaving the basing. How often the data is printed is
controlled by the variable `KPRINT`. As before *delr* gives the sum of
the maximum displacement at each step. Here a fragment from one of the
files *sortiproc.n*:

myVerb 1) Number of displaced atoms initially: 15 2) kter: 0 Energy:
-4119.350998 e-val: 0.5654E+00 delr: 0.109793 3) kter: 1 Energy:
-4119.286709 e-val: 0.5081E+00 delr: 0.207569 4) kter: 2 Energy:
-4119.123240 e-val: 0.5070E+00 delr: 0.303452 5) kter: 3 Energy:
-4118.871215 e-val: 0.5062E+00 delr: 0.397573 6) kter: 4 Energy:
-4118.540492 e-val: 0.5054E+00 delr: 0.490058 7) kter: 5 Energy:
-4118.139916 e-val: 0.5063E+00 delr: 0.581018 8) kter: 6 Energy:
-4117.676847 e-val: 0.4374E+00 delr: 0.670523 9) kter: 7 Energy:
-4117.156694 e-val: -0.7176E-01 delr: 0.758666 10) kter: 8 Energy:
-4116.584468 e-val: -0.4431E+00 delr: 0.845545 11) kter: 9 Energy:
-4115.965492 e-val: -0.1025E+01 delr: 0.931182

Leaving the basin can be accelerated by setting `INCREMENT_SIZE` or
`MIN_NUMBER_KSTEPS`. Increasing the former gives larger steps while the
latter reduces the number of forces computed per *kter* step. That is,
we know that we are out of basin when the eigenvalue (e-val) becomes
negative, therefore, the computation of lanczos can be avoided during
the first steps while the eigenvalue is positive. For example from the
lines above we could set `MIN_NUMBER_KSTEPS` to 8, so during the first 6
steps (2 is rested always), lanczos routine will not be called avoiding
the computation of additional 16$\times6=96$ force calls (as per step we
compute 16 forces if `NUMBER_LANCZOS_VECTORS` is set to 15, plus 3 more
for perpendicular relaxation using the FIRE algorithm. The goal of this
relaxation is to avoid collisions).

Variables `CHECK_LANCZOS_STAB` and `NBRE_POINTS_LANCZOS` have been added
to check eigenvalues stability which is obtained by numerical derivative
in the Lanczos scheme. `CHECK_LANCZOS_STAB` will check the eigenvalues
stability for a defined value of `NUMBER_LANCZOS_VECTORS` and
`NBRE_POINTS_LANCZOS` and for a range of $1 \times 10^{-1}$ to
$1 \times 10^{-7}$ for the step size of the numerical derivative (which
override the `LANCZOS_STEP` variable during the test.
`NBRE_POINTS_LANCZOS` is the numerical method used to compute numerical
derivative. if it is set to 1 then kART will perform a Newton's
difference quotient $\frac{f(x+h)-f(x)}{h}$ . Also, if it is set to 2
then kART will perform a more accurate approximation which is the
symmetric difference quotient $\frac{f(x+h)-f(x)}{h}$ .

Warning, if `INCREMENT_SIZE` or `MIN_NUMBER_KSTEPS` are large the
displacement in the initial direction can be aggressive, ignoring small
saddle points and conducting some events to unphysical saddle points. If
`MIN_NUMBER_KSTEPS` is too large, for *kter* smaller than
`MIN_NUMBER_KSTEPS` the eigenvalue is not evaluated and the system
continues moving in a fixed initial direction that may converge to a
saddle point that is not directly connected to the actual local minimum.
We point out that the ideal is to follow the eigenstate as soon as the
eigenvalue reaches the negative threshold (to jump to *iter* loop, see
below) and not to follow the initial deformation.

The previous analysis is strongly depending of the potential type used
and the complexity of the system. For potentials like ReaxFF or complex
systems care must be taken. It is important realize the complexity of
the system under study and to set `INCREMENT_SIZE` and
`MIN_NUMBER_KSTEPS` according. Analyzing one event is not enough,
severals have to be seen to fix these parameters.

*Convergence to the saddle point*, this is the second analysis and it is
a critical issue because it is in this part that most of the
computational resources are used computing forces. To find a successful
event we use a research of the word 'TRUE\". For example, the linux
command `grep -c TRUE sortiproc.*` will give the number of succesful
events for each *sortiproc.n* file (to see the number of unsuccessful
events try 'FALSE\"). Here a fragment from one of these successful
events from one file *sortiproc.n*:

myVerb 1) iter: 2 ener: -4114.6438 fpar: -2.537541 fperp: 7.234678
e-val: -0.2564E+01 delr: 1.3753 npart: 18 evalf: 474 2) iter: 4 ener:
-4118.3530 fpar: -0.350070 fperp: 1.257846 e-val: -0.7674E+01 delr:
0.9207 npart: 6 evalf: 550 3) iter: 6 ener: -4118.5167 fpar: -0.012303
fperp: 0.275681 e-val: -0.5006E+01 delr: 0.8725 npart: 5 evalf: 614 4)
iter: 8 ener: -4118.5300 fpar: -0.002114 fperp: 0.116685 e-val:
-0.4234E+01 delr: 0.8696 npart: 5 evalf: 678 5) iter: 10 ener:
-4118.5334 fpar: -0.000549 fperp: 0.068056 e-val: -0.3966E+01 delr:
0.8697 npart: 5 evalf: 742 6) iter: 12 ener: -4118.5347 fpar: -0.000140
fperp: 0.045462 e-val: -0.3903E+01 delr: 0.8704 npart: 5 evalf: 806 7)
iter: 14 ener: -4118.5354 fpar: -0.000033 fperp: 0.032623 e-val:
-0.3905E+01 delr: 0.8711 npart: 5 evalf: 870 8) iter: 16 ener:
-4118.5357 fpar: -0.000008 fperp: 0.024442 e-val: -0.3923E+01 delr:
0.8718 npart: 5 evalf: 934 9) iter: 18 ener: -4118.5359 fpar: -0.000011
fperp: 0.018805 e-val: -0.3935E+01 delr: 0.8724 npart: 5 evalf: 998 10)
iter: 20 ener: -4118.5360 fpar: -0.000003 fperp: 0.014709 e-val:
-0.3931E+01 delr: 0.8729 npart: 5 evalf: 1062 11) iter: 22 ener:
-4118.5361 fpar: -0.000002 fperp: 0.011623 e-val: -0.3929E+01 delr:
0.8733 npart: 5 evalf: 1126 12) iter: 24 ener: -4118.5361 fpar:
-0.000001 fperp: 0.009943 e-val: -0.3932E+01 delr: 0.8736 npart: 5
evalf: 1186 13) current energy -4118.53611 14) Finding saddle, success
TRUE: ret 20024 15) Mincounter is : 19 and scounter is 19 16)
Configuration stored in file sad19 17) Initial-SADDLE displacement
(npart): 0.87357227 ( 5) 18) dot product between displacement and
projection: 9.34331E-01 19) Pushing with length: 8.735722842777609E-002
20) We now minimise to new minimum 21) initial energy : TTL
-4118.55312094169 22) Total energy M: -4119.3487 P: 0.006125 fnorm:
0.167860 fmax: 0.075157 vnorm: 0.001339 dt: 0.059487 23) FIRE:
Minimization successful 24) fnrm: 0.00029416 ,fmax: 0.00498449 ,iter: 78
25) FINAL energy -4119.35149889 26) Initial-FINAL displacement (
1.68820790 ( 5) Evalf: 3515 27) Atom that moved to the most to SADDLE: 1
5 28) Event recentered around atom 1 color: C active: T 1 T 29) worker
1) returned for atom: 1 and barrier 0.8154

*iter*: counter of iterations after leaving the basing. How often the
data is printed is controlled by the variable `IPRINT` (in this case is
every 2 iterations).

*e-val*: eigenvalue. When converging to a saddle point the eigenvalue
should be stable, that is, no larger variations should be observed. This
parameter must to converge to the lowest eigenvalue of the hessian
matrix evaluated at the saddle point as well as its respective
eigenvalue.

*fperp* and *fpar*: perpendicular and parallel components of the force.
Realize that *fpar* converges quadratically to zero while *fperp* does
it linearly [@Cances2009]. Therefore the convergence is dominated by
*fpar*, i.e, the system converges when *fpar* is less than certain
threshold defined by the variable `FINE_EXIT_FORCE_THRESHOLD`.

*ener*: convergence to energy of the saddle point.

*evalf*: number of force evaluations.

*npart*: number of particles that move most after certain distance
threshold (`DISPLACEMENT_THRESHOLD`, by default is 0.1 Å).

From this example we can see that with a `FINE_EXIT_FORCE_THRESHOLD` of
0.117, the energy converges with 6 significant digits after *iter* $=8$,
while 24 iterations are required for a convergence with 8 digits if a
`FINE_EXIT_FORCE_THRESHOLD` is set to 0.01 (the value set in this
example, as the code stops when *fperp* $=0.009943<0.01$). Of course 24
steps are OK, but for some systems the number of steps can become very
large. Therefore it is important to see the convergence of the energy
and the force in order to avoid unnecessary force calculations.

On the other hand, it is important also to see how many steps in average
are needed to reach saddle points. If *iter* becomes to large, it means
that maybe the initial deformation is not good. In this case it should
be better to stop the convergence by setting a maximum number of
iteration and restart with a different deformation (this is less costly
than to do for example 1000 *iter* steps to find only one saddle point).
The maximum number of *iter* steps is fixed by the variable
`MAX_ITER_ACTIVATION`.

For each topology several attempts/trials are done for finding a saddle.
From line 12 we see that 1186 force calls have been done for TRUE saddle
finding (energy barrier of 0.8154 eV, see line 29), but from line 26 we
see that the real cost is 3515 force calls, as several previous attempts
are done with FALSE result (plus small number of forces computed for the
minimization to the new minimum). Thus the efficiency not only depends
on the number of forces computed by attempt, but also of the number of
fail attempts for certain topology. How to reduce these FALSE attempts
is still a challenge. The maximum number of attempts is set by the
variable `MAX_TRIALS_TO_CONVERGE` (by default is 10).

[OTHER TIPS FOR OPTIMIZATIONS \.....]{style="color: red"}

# Handling errors

The code can stop for several reasons. Here some of the most common
errors messages and how to solve them:

**Message**: "*no message*\", the code stops immediately or hanged (no
k-ART calculations). This is mainly due to a bad configuration of the
lammps parameters. Check the "*in.lammps*\" file: right path to
potential file, etc; you should use log.lammps instruction to print the
lammps output (be careful this produces a huge file. You might not want
to use it after debugging).

**Message**: "*the tree is empty: this should never happen*\". This
message means that no events are found for any topology of the current
state, in other words no saddles have been found for the existing
topologies. Several issues may cause this to happen, all are related to
bad optimization parameters. Then check if system is able to leave the
basin or check the number of iterations used by *kter* and *iter*, or if
`INCREMENT_SIZE` is too large, or etc (see section
 [12](#sec:Tuning the parameters for a particular system){reference-type="ref"
reference="sec:Tuning the parameters for a particular system"}).

[ \....STILL REMAINS TO EXPLAIN MESSAGES BELLOW
\....]{style="color: red"}

**Message**: "*inv_atm_lbl = 0!!!!!'* \" from file and line:
analyze_events.f90-594-

**Message**: "*master_atm_lb/l = 0!!!!!'* \" from file and line:
analyze_events.f90-1068-

**Message**: "*ERROR: master_topology pointer for atom ', atm_lbl,' is
not associated.'* \" from file and line: analyze_events.f90-1099-

**Message**: "*master_atm_lbl = 0!!!!!'* \" from file and line:
analyze_events.f90-1392-

**Message**: "*there is a problem rehashing the generic event event
though it is new'* \" from file and line: analyze_events.f90-1768-

**Message**: "*we will stop now!!!!!'* \" from file and line:
analyze_events.f90:2008:

**Message**: "*Use old update_topos'* \" from file and line:
basin_mrm.f90-508-

**Message**: "*Error opening basin graph file',BASIN_GRAPH* \" from file
and line: basin_mrm.f90-543-

**Message**: "*old:', old_topoid, ' new:', topoid* \" from file and
line: basin_mrm.f90-2010-

**Message**: "*choose ALL or VER'* \" from file and line:
Bazant.f90-724-

**Message**: "*Error:: I am Blocked - Tree is damaged'* \" from file and
line: Btree.f90-96-

**Message**: " *there should a PROBLEM event is not supposed to be in
tree'* \" from file and line: Btree.f90-174-

**Message**: "*choose ALL or VER'* \" from file and line:
calcfo_Fe.f90-244-

**Message**: "*choose ALL or VER'* \" from file and line:
calcfo_Fe.f90-878-

**Message**: "*ERROR: Cannot create local lmp pointer if lammps is
parallelised'* \" from file and line: calcfo_lammps.f90-101-

**Message**: "*pos is not allocated for rank : ', rank* \" from file and
line: calcfo_lammps.f90-274-

**Message**: "*num: ', num, ' NUMBER_ATOMS: ', NUMBER_ATOMS* \" from
file and line: calcfo_lammps.f90-295-

**Message**: "*pos is not allocated for rank : ', rank* \" from file and
line: calcfo_lammps.f90-391-

**Message**: "*num: ', num, ' nat_local:', nat_local* \" from file and
line: calcfo_lammps.f90-422-

**Message**: "*Your choice of potential is not set up for local force
calculations, please change this choice and restart'*\" from file and
line: calcforce.f90-127-

**Message**: "*The potential radius is bigger than the topo radius,
program will stop'* \" from file and line: calcforce.f90:186:

**Message**: "*Your choice of potential is not set up for local force
calculations, please change this choice and restart'*\" from file and
line: calcforce.f90-217-

**Message**: "*choose ALL or VER'* \" from file and line:
calcfo_si.f90-129-

**Message**: "*choose ALL or VER'* \" from file and line:
calcfo_si.f90-336-

**Message**: "*choose ALL or VER'* \" from file and line:
calcfo_si.f90-549-

**Message**: "*the program should stop'* \" from file and line:
calcfo_sih.f90:728:

**Message**: "*be careful the tail is not specified '* \" from file and
line: class_Btree.f90-270-

**Message**: " *error !!! node cannot be inserted, exiting the tree '*
\" from file and line: class_Btree.f90-293-

**Message**: "*current barrier higher than basin, we* \" from file and
line: event_histo.f90-256-

**Message**: "*But found a total of ', count, 'atoms with that
topology.'* \" from file and line: event_histo.f90-330-

**Message**: "*we moved to state', cur_state(cur_basin), ', but were
unsucessful.'* \" from file and line: execute_event.f90-162-

**Message**: "*we moved to state', cur_state(cur_basin), ', but were
unsucessful.'* \" from file and line: execute_event.f90-255-

**Message**: "*we moved to state', cur_state(cur_basin), ',but were
unsucessful.'* \" from file and line: execute_event.f90-416-

**Message**: "*Moving back to state', basin_orig* \" from file and line:
execute_event.f90-418-

**Message**: "*Local basin revert is not implemented at this time'* \"
from file and line: execute_event.f90-427-

**Message**: "*we moved to state', cur_state(cur_basin), ', but were
unsucessful.'* \" from file and line: execute_event.f90-450-

**Message**: "*ERROR!, event initial topo not in present configuration'*
\" from file and line: findEvents.f90-185-

**Message**: "*ERROR! eventId has an illegal value', eventId* \" from
file and line: findEvents.f90-225-

**Message**: "*ERROR: Trying to send a refine or clone job with the
non-clone interface'* \" from file and line: findEvents.f90-1059-

**Message**: "*Trying to send a non-refine task through the clone
interface'* \" from file and line: findEvents.f90-1085-

**Message**: "*ERROR!, event's initial topo not found in current
configuration'* \" from file and line: findEvents.f90-1283-

**Message**: "*ERROR! eventId has illegal value', eventId* \" from file
and line: findEvents.f90-1320-

**Message**: " *Illegal MPI communication tag' ,tag* \" from file and
line: findEvents.f90-1839-

**Message**: "*Impossible to read the file ', RESTART_CONF, ' does not
exist'* \" from file and line: initialize_KMC.f90-329-

**Message**: "*Impossible to read the file ', INI_FILE_NAME, ' does not
exist'* \" from file and line: initialize_KMC.f90-338-

**Message**: "*Cannot restart, directory ', trim(EVENTS_DIR),' not
found'* \" from file and line: initialize_KMC.f90-425-

**Message**: "*Error: atomic types must be between 1 and 6'* \" from
file and line: initialize_KMC.f90-728-

**Message**: "*Argument energy not given '* \" from file and line:
initialize_KMC.f90-933-

**Message**: "*File ', TMPFILENAME, 'not found '* \" from file and line:
initialize_KMC.f90-937-

**Message**: "*File ', TMPFILENAME, 'not found ', 'and argument energy
not given '* \" from file and line: initialize_KMC.f90-941-

**Message**: "*Problems removing ',trim(filename),', stopping'* \" from
file and line: initialize_KMC.f90:1244:

**Message**: "*The program will end now'* \" from file and line:
initialize_KMC.f90-1482-

**Message**: "*Linked sec_topo', readid,' to ', primary_topo_id* \" from
file and line: initialize_KMC.f90-1696-

**Message**: "*count=', count* \" from file and line:
List_manip.f90-364-

**Message**: "*check sec topos again', Mtopoid, StopoId* \" from file
and line: List_manip.f90:1333:

**Message**: "*Stop file ',STOP_FILE,' found, not starting simulation'*
\" from file and line: main_KART.f90:134:

**Message**: "*Remove stop file before restarting.'* \" from file and
line: main_KART.f90:135:

**Message**: "*The program was not able to fully minimize the
configuration'* \" from file and line: main_KART.f90-241-

**Message**: " *exiting'* \" from file and line: main_KART.f90-388-

**Message**: "*event forbiden should not be in tree'* \" from file and
line: main_KART.f90-456-

**Message**: "*Stop file ',STOP_FILE,' found, exiting'* \" from file and
line: main_KART.f90:669:

**Message**: "*Stop file ',STOP_FILE,' found, exiting'* \" from file and
line: main_KART.f90:672:

**Message**: "*Stop file', STOP_FILE, ' found'* \" from file and line:
main_KART.f90:675:

**Message**: "*Will stop when basin is exited'* \" from file and line:
main_KART.f90:676:

**Message**: "*Also sendind termination signal to lammps worker
according to is ARTn master', taskindex* \" from file and line:
main_KART.f90-744-

**Message**: "*should be a problem with this topology' ,
this_topo%topo_label* \" from file and line: mapping_module.f90-139-

**Message**: "*cannot proceed: choose fin or sad '* \" from file and
line: mapping_module.f90-262-

**Message**: "*exiting '* \" from file and line: mapping_module.f90-680-

**Message**: "*cannot proceed: choose fin or sad '* \" from file and
line: mapping_module.f90-756-

**Message**: "*Correspondance from event to refconfig cluster not OK'*
\" from file and line: mapping_module.f90-922-

**Message**: "*ERROR: secondary topology should not be splitted'* \"
from file and line: mapping_operations.f90-59-

**Message**: "*Giving up'* \" from file and line:
mapping_operations.f90-81-

**Message**: "*Giving up'* \" from file and line:
mapping_operations.f90-141-

**Message**: "*Giving up'* \" from file and line:
mapping_operations.f90-183-

**Message**: "*Not able to further split that topology. Giving up.'* \"
from file and line: mapping_operations.f90-323-

**Message**: "*this_topo%topo_label is different to topoId'* \" from
file and line: mapping_operations.f90-572-

**Message**: "*topoId send is null exit the routine'* \" from file and
line: mapping_operations.f90-580-

**Message**: "*REMOVING secondary topo:',tmp_topo%topo_label ,'for
primary topo :', this_topo%topo_label* \" from file and line:
mapping_operations.f90-623-

**Message**: " *choose: SW, SWA, EDP, EAM, LAM \.... '* \" from file and
line: read_param.f90-44-

**Message**: "*ERROR, INPUT_LAMMPS_FILE missing and default 'in.lammps'
not present.'* \" from file and line: read_param.f90-55-

**Message**: "*ERROR, INPUT_LAMMPS_FILE with name ', dummy,' is
missing.'* \" from file and line: read_param.f90-65-

**Message**: "*Error: number of atoms is not defined : NUMBER_ATOMS'* \"
from file and line: read_param.f90-91-

**Message**: "*The number of elements in 'ATOMIC_SYMBOLS' is different
to NTYPES. The program will stop.'* \" from file and line:
read_param.f90:113:

**Message**: "*Error: please define SIMULATION_BOX or X_BOX, Y_BOX,
Z_BOX in Ang'* \" from file and line: read_param.f90-137-

**Message**: "*Error: please define TOPO_RADIUS in Ang'* \" from file
and line: read_param.f90-169-

**Message**: "*Error: please define MAX_TOPO_CUTOFF in Ang '* \" from
file and line: read_param.f90-210-

**Message**: "*Error: variable TEMPERATURE is not defined (Kelvin)'* \"
from file and line: read_param.f90-342-

**Message**: "*ERROR: MAX_SPEC_EV_NBRE must be a non-null positive
integer'* \" from file and line: read_param.f90-643-

**Message**: "*Must be between 0 and 1'* \" from file and line:
read_param.f90-776-

**Message**: " *choose: TTL, PAR '* \" from file and line:
read_param.f90-799-

**Message**: "*Error: please define LATTICE_CONSTANT '* \" from file and
line: read_param.f90-821-

**Message**: "*or use none as argument'* \" from file and line:
read_param.f90-852-

**Message**: "*Error: OSCILL_TREAT=BMRM requires
TYPE_EVENT_UPDATE=SPEC'* \" from file and line: read_param.f90-1020-

**Message**: "*Error : only global or local type of events are accepted
- provided: ', TYPE_OF_EVENTS* \" from file and line:
read_param.f90-1194-

**Message**: "*Error: RADIUS_INITIAL_DEFORMATION must be defined when
TYPE_OF_EVENTS is local'* \" from file and line: read_param.f90-1204-

**Message**: "*Error : No eigenvalue threshold provided
(EIGENVALUE_THRESHOLD)'* \" from file and line: read_param.f90-1266-

**Message**: "*Eigenvalue increasing - stop activation'* \" from file
and line: saddle_converge.f90:94:

**Message**: "*Eigenvalue increasing - stop activation'* \" from file
and line: saddle_converge.f90:95:

**Message**: "*ERROR:, atom n_cluster is zero', atom_label,
All_atoms(atom_label)%n_cluster* \" from file and line:
set_topos.f90-100-

**Message**: "*Error, topo', this_topo%topo_label,' has multiplicity of
0'* \" from file and line: utils.f90-396-

**Message**: "*Error, topo', this_topo%topo_label,' has no particles in
list'* \" from file and line: utils.f90-418-

**Message**: "*ARTn_ranksize is not a integer, we will stop now.'* \"
from file and line: Vars.f90:545:

**Message**: "*ARTn_ranksize not equal to rank_size, we will stop'* \"
from file and line: Vars.f90:558:

**Message**: "*there is a error in the type of double parallelisation '*
\" from file and line: Vars.f90-759-

**Message**: "*HINT: Make sure you set the variable NTRAVAILLEUR in the
KMC.sh, and that the number of core',* \" from file and line:
Vars.f90-761-

**Message**: " *select a valid flag for UPDATE_VER_NEIB TTL or PAR '* \"
from file and line: Verlet_neighbour.f90-449-

**Message**:

**Message**:

**Message**:

**Message**:

100

N. Mousseau and L.J Lewis, *Computer models for amorphous silicon
hydrides*, Phys. Rev. B **41**, (1990) 3702-3707.

H. Vocks, M.V. Chubynsky, G.T. Barkema and N. Mousseau, *Activated
sampling in complex materials at finite temperature: the
properly-obeying-probability activation-relaxation technique*, J. Chem.
Phys. **123**, 244707:1-10 (2005).

M.V. Chubynsky, H. Vocks, G.T. Barkema and N.Mousseau, *Exploiting
memory in event-based simulations*, J. Non. Cryst. Solid **352**,
4424-4429 (2006).

B. Puchala, M. L. Falk and K. Garikipati, *An energy basin finding
algorithm for kinetic Monte Carlo acceleration*, J. Chem. Phys. **132**,
134104 (2010).

F. El-Mellouhi, N. Mousseau and L. J. Lewis, *The Kinetic
Activation-Relaxation Technique: A Powerful Off-lattice On-the-fly
Kinetic Monte Carlo Algorithm*, Phys. Rev. B. **78**, 153202 (2008).

M.-C. Marinica, F. Willaime and N. Mousseau, *Energy landscape of small
clusters of self-interstitial dumbbells in iron*, Phys. Rev. B **83**,
094119, (2011).

J.-F. Joly, L. K. Béland, P. Brommer, F. El-Mellouhi and N. Mousseau,
*Optimization of the Kinetic Activation-Relaxation Technique, an
off-lattice and self-learning kinetic Monte-Carlo method*, Journal of
Physics: Conference Series Series **341**, 012007 (2012).

L. K. Béland, P. Brommer, F. El-Mellouhi, J.-F. Joly and N. Mousseau,
*The Kinetic Activation Relaxation Technique*, Phys. Rev. E **84**,
046704 (2011).

E. Machado-Charry, L. K. Béland, D. Caliste, L. Genovese, N. Mousseau
and P. Pochet, *Optimized energy landscape exploration using the ab
initio based ART-nouveau*, J. Chem Phys. **135**, 034102 (2011).

N. Mousseau, L. K. Béland, P. Brommer, J.-F. Joly, F. El-Mellouhi, E.
Machado-Charry, P. Pochet et M.-C. Marinica, *The Activation-Relaxation
Technique: ART nouveau and kinetic ART*, J. Atom., Mol. and Opt. Phys.
**2012**, 925278 (2012).

P. Brommer and N. Mousseau, *Comment on "Mechanism of Void Nucleation
and Growth in bcc Fe: Atomistic Simulations at Experimental Time
Scales"*, Phys. Rev. Lett. **108**, 219601 (2012)

J.-F. Joly, L. K. Béland, P. Brommer and N. Mousseau, *Contribution of
vacancies to relaxation in amorphous materials: A kinetic
activation-relaxation technique study*, Phys. Rev. B **87**, 144204
(2013)

L.K. Béland, Y. Anahory, D. Smeets, M. Guihard, P. Brommer, J.-F. Joly,
J.-C. Pothier, L. J. Lewis, N. Mousseau and F. Schiettekatte, *Replenish
and relax: explaining logarithmic annealing in disordered materials*,
Phys. Rev. Lett. **111**, 105502 (2013).

L. K. Béland and N. Mousseau, *Relaxation of ion-bombarded silicon
studied with the kinetic Activation-Relaxation Technique*, Phys. Rev. B.
**88**, 214201 (2013).

M. Trochet, L.K. Béland, J-F Joly P. Brommer and N. Mousseau, *Diffusion
of point defects in crystalline silicon using the kinetic
activation-relaxation technique method*, Phys. Rev. B. **91**, 224106
(2015).

O.A. Restrepo, N. Mousseau,F. El-Mellouhi, O. Bouhali, M. Trochet and C.
S. Becquart, *Diffusion properties of Fe-C systems studied by using
kinetic activation-relaxation technique* , Comput. Mat. Sc. **112**,
96-106 (2016).

N. Mousseau, L.K. Béland, P. Brommer, J-F Joly, G. K. N'Tsouaglo, O.A.
Restrepo and M. Trochet,, *Following atomistic kinetics on experimental
timescales with the kinetic Activation-Relaxation Technique*, Comput.
Mat. Sc. **100**, 111-123 (2015).

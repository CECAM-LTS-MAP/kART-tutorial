/*****************************************************************************
*  $Revision$
*  $Date$
*  $Id$
******************************************************************************/

/* for 64-bit integers: #define rng_conv 5.421010862427522e-20 */
/* for 32-bit integers: #define rng_conv 2.3283064365387e-10   */

#define rng_conv 2.3283064365387e-10

#define rngmit (rng_conv*(rng_ia[rng_p=rng_mod[rng_p]] += rng_ia[rng_pp=rng_mod[rng_pp]]))
#define rngmitint (rng_ia[rng_p=rng_mod[rng_p]] += rng_ia[rng_pp=rng_mod[rng_pp]])

extern unsigned long int rng_ia[55];
extern int rng_p, rng_pp;
extern int rng_mod[55];

void  rngseed(unsigned long int s);

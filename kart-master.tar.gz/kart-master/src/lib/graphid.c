/*subroutine sent by Richard Vink*/
/*Modified by Fedwa El-Mellouhi 2007-2008*/
/*****************************************************************************
*  $Revision$
*  $Date$
*  $Id$
******************************************************************************/


#include <stdio.h>

#define NCLMAX  512		/* max nbre of atoms ina a cluster */
#define WORDSIZE        32
#define MAXN            NCLMAX

#include "nauty.h"
#include "naututil.h"

void graphid_(id1, id2, id3, cl_s, cl, lab)


     int  *id1, *id2, *id3;
     int cl_s;
     int cl[NCLMAX][NCLMAX]; //was [NLCMAX][100] because max_nei = 100
     nvector lab[MAXN];
{
  int   i, j, nj, m, zseed, n;
  graph g[MAXN * MAXM], canong[MAXN * MAXM];
  nvector ptn[MAXN], orbits[MAXN];
  static DEFAULTOPTIONS(options);
  statsblk(stats);
  setword workspace[50 * MAXM];
  set  *row, *gp;
  boolean digraph, prompt, edit;

  options.writeautoms = FALSE;
  options.writemarkers = FALSE;
  options.defaultptn = TRUE;
  options.getcanon = TRUE;
  options.cartesian = FALSE;
  digraph = TRUE;
  prompt = TRUE;
  edit = FALSE;

  /* Load graph */

  m = MAXM;
  for (i = 0; i < cl_s; i++) {
    row = GRAPHROW(g, i, m);
    EMPTYSET(row, m);
    for (nj = 1; nj <= cl[i][0]; nj++) {
      j = cl[i][nj];
      ADDELEMENT(row, j);
    }
  }


  /* Call nauty */

  nauty(g, lab, ptn, NILSET, orbits, &options, &stats, workspace, 50 * MAXM,
	m, cl_s, canong);

/*  for (i = 0; i < MAXN; ++i) printf(" %d", lab[i]);
    printf("\n");

  for(i=0;i<MAXN*MAXM;i++) {
       printf(" %d",canong[i]);
    }
       printf("\n");
*/
  zseed = cl_s;
  for (i = 0, gp = canong; i < cl_s; i++, gp += m)
    zseed = sethash(gp, cl_s, zseed, 321);
  *id1 = zseed;

  for (i = 0, gp = canong; i < cl_s; i++, gp += m)
    zseed = sethash(gp, cl_s, zseed, 3109);
  *id2 = zseed;

  for (i = 0, gp = canong; i < cl_s; i++, gp += m)
    zseed = sethash(gp, cl_s, zseed, 4317);
  *id3 = zseed;
}

/******************************************************************************
*
* random_init.c -- initialize lagged fibonacci rng
* 
* Copyright 2009-2010 Peter Brommer, Universite de Montreal
* Inspired by Numerical Recipes Ranq1
******************************************************************************/


/******************************************************************************
* $Revision$
* $Date$
* $Id$
******************************************************************************/

#define RECIMAXINT 5.42101086242752217E-20
#define FACTOR 2685821657736338717LL

/****************************
 *
 * _random_init - Arguments:
 *      1. vector= vector of floats to be filled with 0..1 values
 *      2. length= length of vector
 *      3. seed = if seed < 0, initialize random_init with seed*/

void random_init2_(double *vector, int *length, int *seed)
{
  static unsigned long long v = 4101842887655102017LL;
  unsigned long long w;
  int   i;
  int   len;

  if (*seed < 0) {
    v ^= -*seed;
    v ^= v >> 21;
    v ^= v << 35;
    v ^= v >> 4;
    v *= FACTOR;
  }
  len = *length;
  for (i = 0; i < len; i++) {
    v ^= v >> 21;
    v ^= v << 35;
    v ^= v >> 4;
    w = v * FACTOR;
    vector[i] = w * RECIMAXINT;
  }
}

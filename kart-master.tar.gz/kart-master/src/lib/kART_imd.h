/******************************************************************************
*
* kART_imd.h --  Compiler Flags for IMD integration
*
******************************************************************************/

/******************************************************************************
* $Revision$
* $Date$
******************************************************************************/
/* List of defines for IMD integration */
#define PAIR
#define EAM2
#define NVE
#define NBL


#include "imd.h"
#include "potaccess.h"

/* EXTERN struct conf_info { */
/*   int k_natoms, k_cell_nbr, *k_ncells; */
/*   real *k_box; */
/* }; */

/* EXTERN struct config { */
/*   int *k_types; */
/*   real *k_pos; */
/* }; */
EXTERN long nat INIT(0);

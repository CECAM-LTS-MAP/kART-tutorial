/*****************************************************************************
*  $Revision$
*  $Date$
*  $Id$
******************************************************************************/

/* Runtime parameters */

#define NATOMS	20000
#define CONFIG	"current.txt"
#define SKIP	10
#define MAXCL	50
#define MAXPER	0.04

#define VECSIZE (2*NATOMS)

/* Divide the sample into L2 cubes */

#define L	15
#define L2	(L*L)

/* Maximum number of atoms allowed on hotlist */

#define MAXHOT	1000

/* Maximum clustersize we expect to find */

#define NCLMAX	100

/* Number of samples to take in one sweep */

#define NSAMPLE	30000

/* Large prime for hash table */

#define TABLESIZE       1299709

/* Constants we use */

#define PI	3.141592

/* Globals we use */

extern int N;
extern int nn[NATOMS][3];
extern double pos[VECSIZE], BOX;

extern int hotid[L2], nhot[L2];
extern int hotlist[L2][MAXHOT];

extern long nec;

extern int index[NATOMS];
extern int stack[NATOMS];
extern double stackdr[NATOMS];

extern int cl[NCLMAX][4];

struct element {
  int   id1, id2, id3;
  long  teller;
  struct element *next;
};

extern struct element *myhash[TABLESIZE];

extern double count();

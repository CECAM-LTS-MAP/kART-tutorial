
/******************************************************************************
*
* imd_interface.c -- interface/frontend for IMD subroutines in kART
* 
* Copyright 2009-2010 Peter Brommer, Universite de Montreal
* IMD Copyright 1996-2009 Institute for Theoretical and Applied Physics,
* University of Stuttgart, D-70550 Stuttgart
*
******************************************************************************/

/******************************************************************************
* $Revision$
* $Date$
* $Id$
******************************************************************************/

/******************************************************************************
 * 
 * In this file, Parameters that would be read from IMD config file are set,
 * and the potential tables are initialised.
 *
 ******************************************************************************/

/* For all purposes in kART, this is the MAIN imd routine     */
#define MAIN
/* List of defines for IMD integration */

#include "kART_imd.h"

/* Use Mendelev iron potential */

/* #include "fe_mend_2.h"		 */

/* Use tabulated EAM potential */
#include "tab_pot.h"

typedef enum ParamType {
  PARAM_STR, PARAM_STRPTR,
  PARAM_INT, PARAM_INT_COPY,
  PARAM_INTEGER, PARAM_INTEGER_COPY,
  PARAM_REAL, PARAM_REAL_COPY
} PARAMTYPE;

static int getparam(char *param_name, void *param, PARAMTYPE ptype,
		    int pnum_min, int pnum_max);

void init_potential_eam_(int *k_natoms, int *k_ntypes, int *rank)
{
  char  msg[1024];
  int   i, j, k, cur;
  real  prevr;

  /* set myrank */
  myrank = *rank;

  /* import kART variables */
  nat = *k_natoms;

  /* set constants */
#ifdef NTYPES
  ntypes = NTYPES;
#else
  ntypes = *k_ntypes;
#endif
    
  ntypepairs = ntypes * (ntypes + 1) / 2;

  /* allocate some arrays */
  if ((num_sort = (long *)calloc(ntypes, sizeof(long))) == NULL)
    error("cannot allocate memory for num_sort\n");
  if ((num_vsort = (long *)calloc(ntypes, sizeof(long))) == NULL)
    error("cannot allocate memory for num_vsort\n");


#ifdef ACKLAND
  ack_use_eam = 1;
  debug_potential = 1;
  have_pre_pot = 1;


  /* Flag for using predefined eam potentials, minimal and maximal density */
  for (i = 0; i < ntypes; i++) {
    use_eam_predef[i] = 1;
    eam_embed_min[i] = 0.;
    eam_embed_max[i] = 100.;
  }

  /* Screening parameters */
  ack_Z = (real *)malloc(ntypes * sizeof(real));
  ack_r1 = (real *)malloc(ntypepairs * sizeof(real));
  ack_r2 = (real *)malloc(ntypepairs * sizeof(real));
  if ((NULL == ack_Z) || (NULL == ack_r1) || (NULL == ack_r2))
    error("cannot allocate ackland parameters Z, r1, r2");
  /* read from makro */
  sprintf(msg, ACK_Z);
  strtok(msg, " =\t\r\n");
  getparam("ack_Z", ack_Z, PARAM_REAL, ntypes, ntypes);
  sprintf(msg, ACK_R1);
  strtok(msg, " =\t\r\n");
  getparam("ack_r1", ack_r1, PARAM_REAL, ntypes, ntypes);
  sprintf(msg, ACK_R2);
  strtok(msg, " =\t\r\n");
  getparam("ack_r2", ack_r2, PARAM_REAL, ntypes, ntypes);

  ack_ipol_B = (real *)malloc(4 * ntypepairs * sizeof(real));
  if ((NULL == ack_ipol_B))
    error("cannot allocate intermediate interpolation params");
  sprintf(msg, ACK_IPOL_B);
  strtok(msg, " =\t\r\n");
  getparam("ack_ipol_B", ack_ipol_B, PARAM_REAL, 4 * ntypepairs,
	   4 * ntypepairs);

  /* Number of splines */
  ack_n_splc_p = (int *)malloc(ntypepairs * sizeof(int));
  ack_n_splc_t = (int *)malloc(ntypes * sizeof(int));
  if ((NULL == ack_n_splc_p) || (NULL == ack_n_splc_t))
    error("cannot allocate table of ackland spline coefficient numbers");

  sprintf(msg, ACK_N_SPLC_P);
  strtok(msg, " =\t\r\n");
  getparam("ack_n_splc_p", ack_n_splc_p, PARAM_INT, ntypes, ntypes);
  sprintf(msg, ACK_N_SPLC_T);
  strtok(msg, " =\t\r\n");
  getparam("ack_n_splc_t", ack_n_splc_t, PARAM_INT, ntypes, ntypes);

  for (i = 0; i < ntypepairs; i++)
    ack_nmax_p = MAX(ack_nmax_p, ack_n_splc_p[i]);
  for (i = 0; i < ntypes; i++)
    ack_nmax_t = MAX(ack_nmax_t, ack_n_splc_t[i]);

  /* Spline tables */
  ack_splc_p = (real *)malloc(ntypepairs * ack_nmax_p * sizeof(real));
  ack_splr_p = (real *)malloc(ntypepairs * ack_nmax_p * sizeof(real));
  ack_splc_t = (real *)malloc(ntypes * ack_nmax_t * sizeof(real));
  ack_splr_t = (real *)malloc(ntypes * ack_nmax_t * sizeof(real));
  if ((NULL == ack_splc_p) || (NULL == ack_splc_t) ||
      (NULL == ack_splr_p) || (NULL == ack_splr_t))
    error("cannot allocate table of ackland splines");

  sprintf(msg, ACK_SPLC_P);
  strtok(msg, " =\t\r\n");
  getparam("ack_splc_p", ack_splc_p, PARAM_REAL, ntypepairs * ack_nmax_p,
	   ntypepairs * ack_nmax_p);
  sprintf(msg, ACK_SPLR_P);
  strtok(msg, " =\t\r\n");
  getparam("ack_splr_p", ack_splr_p, PARAM_REAL, ntypepairs * ack_nmax_p,
	   ntypepairs * ack_nmax_p);
  sprintf(msg, ACK_SPLC_T);
  strtok(msg, " =\t\r\n");
  getparam("ack_splc_t", ack_splc_t, PARAM_REAL, ntypes * ack_nmax_t,
	   ntypes * ack_nmax_t);
  sprintf(msg, ACK_SPLR_T);
  strtok(msg, " =\t\r\n");
  getparam("ack_splr_t", ack_splr_t, PARAM_REAL, ntypes * ack_nmax_t,
	   ntypes * ack_nmax_t);

  /* Embedding parameter */
  ack_embed = (real *)malloc(ntypes * sizeof(real));
  if (NULL == ack_embed)
    error("cannot allocate ackland embedding parameter");

  sprintf(msg, ACK_EMBED);
  strtok(msg, " =\t\r\n");
  getparam("ack_embed", ack_embed, PARAM_REAL, ntypes, ntypes);


  /* Find maximal spline radius -> rcut */
  for (i = 0; i < ntypepairs; i++) {
    prevr = 0.;
    for (j = 0; j < ack_n_splc_p[i]; j++) {
      cur = i * ack_nmax_p + j;
      if (prevr > ack_splr_p[cur])
	error("Ackland splines must be sorted with ascending r.");
      prevr = ack_splr_p[cur];
    }
  }
#elif defined(EAMTAB)
  debug_potential = 1;
  
  /* EAM2:Filename for the tabulated core-core potential (r^2) */
  sprintf(msg, PAIRPOT);
  strtok(msg, " =\t\r\n");
  getparam("core_potential_file",potfilename,PARAM_STR,1,255);
  have_potfile = 1;
  /* EAM2:Filename for the tabulated embedding energy(rho_h) */
  sprintf(msg, EMBEDFN);
  strtok(msg, " =\t\r\n");
  getparam("embedding_energy_file",eam2_emb_E_filename,PARAM_STR,1,255);
      /* EAM2:Filename for the tabulated atomic electron density(r_ij^2) */
  sprintf(msg, TRANSFN);
  strtok(msg, " =\t\r\n");
  getparam("atomic_e-density_file",eam2_at_rho_filename,PARAM_STR,1,255);

#endif	/* Potential type */
  /* Now we are ready */
  setup_potentials();

  /* Other stuff */
  nbl_margin = 0.0;

  return;
}



void calcforce_eam_(real *k_box, int *k_types, real *k_pos, real *tmp_force,
		    real *pot_energy)
{
  int   i, k, count_atom, to_cpu;
  real  tmp;
  vektor pos;
  ivektor cellc;
  cell *input;
  minicell *to;
  /* Init constants */
  nactive = 0;
  natoms = 0;
  have_valid_nbl = 0;
  for (i = 0; i < ntypes; i++) {
    num_sort[i] = 0;
    num_vsort[i] = 0;
  }
  /* Does the box change? If not, we can just put that in
   * the init_potential function */

  /* orthorombic box */
  box_x.x = k_box[0];
  box_y.y = k_box[1];
  box_z.z = k_box[2];
  /* others are 0 */
  box_x.y = box_x.z = 0.0;
  box_y.x = box_y.z = 0.0;
  box_z.x = box_z.y = 0.0;

  /* Make box */
  make_box();
  /* and initialize cells */
  init_cells();

  /* Put atoms in structure */
  input = (cell *) malloc(sizeof(cell));
  if (NULL == input)
    error("Cannot allocate input cell.");
  input->n_max = 0;
  alloc_cell(input, 1);
  natoms = 0;

  for (i = 0; i < nat; i++) {
    input->n = 1;
    NUMMER(input, 0) = natoms;
    SORTE(input, 0) = MOD(k_types[natoms]-1, ntypes);
    VSORTE(input, 0) = (k_types[natoms]-1) % ntypes;
    MASSE(input, 0) = 1;	/* unimportant */
    /* Positions */
    pos.x = k_pos[natoms];
    pos.y = k_pos[nat + natoms];
    pos.z = k_pos[2 * nat + natoms];
    pos = back_into_box(pos);
#ifdef DDEBUG
    tmp = SPROD(pos, pos);
    if (!(isnormal(tmp))) {
      warning("WTF is happening here?");
      printf("%ld %f %f %f %f\n", natoms, pos.x, pos.y, pos.z, tmp);
    }
#endif
    ORT(input, 0, X) = pos.x;
    ORT(input, 0, Y) = pos.y;
    ORT(input, 0, Z) = pos.z;

    /* set forces to 0 */
    KRAFT(input, 0, X) = 0.;
    KRAFT(input, 0, Y) = 0.;
    KRAFT(input, 0, Z) = 0.;

    /* determine destination cell */
    cellc = cell_coord(pos.x, pos.y, pos.z);
    to_cpu = 0;
    count_atom = 0;

    /* Account for buffer cells */
    cellc = local_cell_coord(cellc);

    /* and put it there */
    to = PTR_VV(cell_array, cellc, cell_dim);
    INSERT_ATOM(to, input, 0);
    count_atom = 1;
    if (count_atom) {
      natoms++;
      nactive += DIM;
      num_sort[SORTE(input, 0)]++;
      num_vsort[VSORTE(input, 0)]++;
    }
  }
  alloc_cell(input, 0);		/* no longer used */
  free(input);

  /* Now do the calc */
  calc_forces(0);
  /* and write back the results */
  for (k = 0; k < ncells; k++) {
    cell *p = CELLPTR(k);
    for (i = 0; i < p->n; i++) {
      tmp_force[NUMMER(p, i)] = KRAFT(p, i, X);
      tmp_force[nat + NUMMER(p, i)] = KRAFT(p, i, Y);
      tmp_force[2 * nat + NUMMER(p, i)] = KRAFT(p, i, Z);
#ifdef DDEBUG
      tmp = SQR(tmp_force[NUMMER(p, i)]) +
	SQR(tmp_force[nat + NUMMER(p, i)]) +
	SQR(tmp_force[2 * nat + NUMMER(p, i)]);
      if (!(isnormal(tmp))) {
	warning("WTF is happening here?");
	printf("%d %f %f %f %f %f %f %f\n", NUMMER(p, i), tmp,
	       ORT(p, i, X), ORT(p, i, Y), ORT(p, i, Z),
	       KRAFT(p, i, X), KRAFT(p, i, Y), KRAFT(p, i, Z));
      }
#endif

    }
  }
  *pot_energy = tot_pot_energy;
  /* and free all cells */
  for (k = 0; k < nallcells; k++) {
    cell *p = cell_array + k;
    alloc_cell(p, 0);
  }
  free(cell_array);
  cell_array = NULL;
}

void setup_mpi_topology(void)
{
  if (NULL == cpu_ranks)
    cpu_ranks = (int *)calloc(1, sizeof(int));
  else
    cpu_ranks[0] = 0;
  if (NULL == cpu_ranks)
    error("cannot allocate cpu_ranks");
}

void fix_cells(void)
{
  return;
};

/******************************************************************************
*
*  local_cell_coord computes the local cell coordinates of a position
*
******************************************************************************/

ivektor local_cell_coord(ivektor global_coord)
{
  ivektor cellc;

  cellc.x = global_coord.x - my_coord.x * (cell_dim.x - 2) + 1;
  cellc.y = global_coord.y - my_coord.y * (cell_dim.y - 2) + 1;
  cellc.z = global_coord.z - my_coord.z * (cell_dim.z - 2) + 1;

  return cellc;
}


/******************************************************************************
* code taken from
* IMD -- The ITAP Molecular Dynamics Program
*
* Copyright 1996-2008 Institute for Theoretical and Applied Physics,
* University of Stuttgart, D-70550 Stuttgart
* imd_param.c 
* Revision: 1.301 
* Date: 2009/12/21 14:54:36 
*
******************************************************************************/

/*****************************************************************************
*
* Parameter aus Zeile auslesen / get parameter from line
*
*****************************************************************************/

/* Parameter:
   param_name ... Parametername (fuer Fehlermeldungen)
   param ........ Adresse der Variable fuer den Parameter
   ptype ........ Parametertyp
                  folgende Werte sind zulaessig:
                  PARAM_STR : String, deklariert als char[]
                  PARAM_STRPTR : String, deklariert als Zeiger auf char*
                  PARAM_INT : Integer-Wert(e)
                  PARAM_INT_COPY : Integer-Wert(e), kopierend
                  PARAM_REAL : Real-Wert(e)
                  PARAM_REAL_COPY : Real-Wert(e), kopierend
                  
   pnum_min ..... Minimale Anzahl der einzulesenden Werte
                  (Falls weniger Werte gelesen werden koennen als verlangt,
                  wird ein Fehler gemeldet).
   pnum_max ..... Maximale Anzahl der einzulesenden Werte
                  (Die nicht kopierenden Routinen lesen hoechstens
                  pnum_max Werte aus der uebergebenen Zeile ein,
                  weitere Werte werden ignoriert. Falls weniger als
                  pnum_max Werte vorhanden sind, wird das Lesen
                  abgebrochen, es wird kein Fehler gemeldet,
                  wenn mindestens pnum_min Werte abgesaettigt wurden.
                  Die kopierenden Routinen melden ebenfalls keinen
                  Fehler, wenn mindestens pnum_min Werte abgesaettigt
                  wurden. Falls weniger als pnum_max Werte vorhanden sind,
                  werden die restlichen Werte mit Kopien des zuletzt gelesenen
                  Werts aufgefuellt. 

  Resultat:
  nichtkopierende Routinen: Die Anzahl der gelesenen Werte wird zurueckgegeben.
  kopierende Routinen: Die Anzahl der tatsaechlich gelesenen Werte wird
                       zurueckgegeben. Resultat = pnum_max - Anzahl der Kopien
*/

static int getparam(char *param_name, void *param, PARAMTYPE ptype,
		    int pnum_min, int pnum_max)
{
  static char errmsg[256];
  char *str;
  int   i;
  int   numread;
  int   curline = 0;

  numread = 0;
  if (ptype == PARAM_STR) {
    str = strtok(NULL, " =\t\r\n");
    if (str == NULL) {
      sprintf(errmsg, "parameter for %s missing in line %u\nstring expected",
	      param_name, curline);
      error(errmsg);
    } else
      strncpy((char *)param, str, pnum_max);
    numread++;
  } else if (ptype == PARAM_STRPTR) {
    str = strtok(NULL, " =\t\r\n");
    if (str == NULL) {
      sprintf(errmsg, "parameter for %s missing in line %u\nstring expected",
	      param_name, curline);
      error(errmsg);
    } else
      *((char **)param) = strdup(str);
    numread++;
  } else if (ptype == PARAM_INT) {
    for (i = 0; i < pnum_min; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str == NULL) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "integer vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      } else
	((int *)param)[i] = atoi(str);
      numread++;
    }
    for (i = pnum_min; i < pnum_max; i++) {
      if ((str = strtok(NULL, " =\t\r\n")) != NULL) {
	((int *)param)[i] = atoi(str);
	numread++;
      } else
	break;
    }
  } else if (ptype == PARAM_INT_COPY) {
    int   ival = 0;
    for (i = 0; i < pnum_max; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str != NULL) {
	ival = atoi(str);
	numread++;		/* return number of parameters actually read */
      } else if (i < pnum_min) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "integer vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      }
      ((int *)param)[i] = ival;
    }
  } else if (ptype == PARAM_INTEGER) {
    for (i = 0; i < pnum_min; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str == NULL) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "integer vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      } else
	((integer *) param)[i] = atoi(str);
      numread++;
    }
    for (i = pnum_min; i < pnum_max; i++) {
      if ((str = strtok(NULL, " =\t\r\n")) != NULL) {
	((integer *) param)[i] = atoi(str);
	numread++;
      } else
	break;
    }
  } else if (ptype == PARAM_INTEGER_COPY) {
    int   ival = 0;
    for (i = 0; i < pnum_max; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str != NULL) {
	ival = atoi(str);
	numread++;		/* return number of parameters actually read */
      } else if (i < pnum_min) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "integer vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      }
      ((integer *) param)[i] = (integer) ival;
    }
  } else if (ptype == PARAM_REAL) {
    for (i = 0; i < pnum_min; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str == NULL) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "real vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      } else
	((real *)param)[i] = atof(str);
      numread++;
    }
    for (i = pnum_min; i < pnum_max; i++) {
      if ((str = strtok(NULL, " =\t\r\n")) != NULL) {
	((real *)param)[i] = atof(str);
	numread++;
      } else
	break;
    }
  } else if (ptype == PARAM_REAL_COPY) {
    real  rval = 0;
    for (i = 0; i < pnum_max; i++) {
      str = strtok(NULL, " =\t\r\n");
      if (str != NULL) {
	rval = atof(str);
	numread++;		/* return number of parameters actually read */
      } else if (i < pnum_min) {
	sprintf(errmsg, "parameter for %s missing in line %u\n",
		param_name, curline);
	sprintf(errmsg + strlen(errmsg), "real vector of dim %u expected",
		(unsigned)pnum_min);
	error(errmsg);
      }
      ((real *)param)[i] = rval;
    }
  }
  return numread;
}				/* getparam */

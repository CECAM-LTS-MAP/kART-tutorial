
/******************************************************************************
 * 
 * Potential 2 for Fe given by Mendelev et al., 
 *                             Phil. Mag. 83 (35), 3977-3994, 2003
******************************************************************************/

/******************************************************************************
*
* fe_mend_2.h 
*
******************************************************************************/

/******************************************************************************
* $Revision$
* $Date$
******************************************************************************/
/* This is an Ackland potential */
#define ACKLAND

/* Number of atom types */
#define NTYPES        1

/* Core charges */
#define ACK_Z        "ack_Z 26"	/* Fe: Z=26 */

/* r1, r2 separating core, intermediate, outer region */

#define ACK_R1        "ack_r1 1.00"
#define ACK_R2        "ack_r2 2.00"

/* Parameters B of intermediate polynomial */

#define ACK_IPOL_B    "ack_ipol_B 6.4265260576348 \
                        1.7900488524286 \
                       -4.5108316729807 \
                        1.0866199373306"

/* Splines of outer region pair potential */
#define ACK_N_SPLC_P "ack_n_splc_p 13"	/* number of splines */

/* First the coefficients */
#define ACK_SPLC_P "ack_splc_p -24.028204854115 \
      11.300691696477		       \
      5.3144495820462		       \
      -4.6659532856049		       \
      5.9637758529194		       \
      -1.7710262006061		       \
      0.85913830768731		       \
      -2.1845362968261		       \
      2.6424377007466		       \
      -1.0358345370208		       \
      0.33548264951582		       \
      -0.046448582149334	       \
      -0.0070294963048689 "
/* Then the corresponding radii */
#define ACK_SPLR_P  "ack_splr_p 2.2 2.3 2.4 2.5 2.6 2.7 \
      2.8 3.0 3.3 3.7 4.2 4.7 5.3 "

/* Splines for the transfer function */
#define ACK_N_SPLC_T  "ack_n_splc_t 3 "	/* number of splines */
/* Coefficients */
#define ACK_SPLC_T "ack_splc_t 11.686859407970 \
      -0.014710740098830	      \
      0.47193527075943"
/* radii */
#define ACK_SPLR_T "ack_splr_t 2.4 3.2 4.2"

/* Embedding parameter */
#define ACK_EMBED "ack_embed -0.00035387096579929"

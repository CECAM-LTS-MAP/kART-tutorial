
/******************************************************************************
 * 
 * Potential 2 for Fe given by Mendelev et al., 
 *                             Phil. Mag. 83 (35), 3977-3994, 2003
******************************************************************************/

/******************************************************************************
*
* fe_mend_2.h 
*
******************************************************************************/

/******************************************************************************
* $Revision$
* $Date$
******************************************************************************/
/* This is a tabulated EAM potential */
#define EAMTAB

/* This is an EAM2 potential */
#define EAM2

/* Number of atom types not defined*/
#undef NTYPES 

/* Potential Files */
/* Pair potential */
#define PAIRPOT "core_potential_file eampot_phi.imd.pt"
/* Embedding function */
#define EMBEDFN "embedding_energy_file eampot_F.imd.pt"
/* Transfer function */
#define TRANSFN "atomic_e-density_file eampot_rho.imd.pt"




